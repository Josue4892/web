<?php

date_default_timezone_set('America/Lima');

define('DB_HOST', 'localhost');
define('DB_PORT', '3307');           // 🔴 CAMBIAR AQUÍ: '3306' para XAMPP estándar, '3307' para MAMP/otros
define('DB_NAME', 'farmacia_db');
define('DB_USER', 'root');
define('DB_PASS', '');               // Cambiar si tienes contraseña en MySQL
define('DB_CHARSET', 'utf8mb4');


function detectarPuerto() {
    $puertos = ['3306', '3307', '8889']; 
    
    foreach ($puertos as $puerto) {
        try {
            $dsn = "mysql:host=localhost;port=$puerto;dbname=information_schema";
            $test = new PDO($dsn, 'root', '');
            return $puerto; 
        } catch (Exception $e) {
            continue; 
        }
    }
    return '3306'; 
}


class Database {
    private $host = DB_HOST;
    private $port = DB_PORT;
    private $db_name = DB_NAME;
    private $username = DB_USER;
    private $password = DB_PASS;
    private $charset = DB_CHARSET;
    public $conn;

    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";charset=" . $this->charset;
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $this->conn->exec("SET time_zone = '-05:00'");
            

            
        } catch(PDOException $exception) {
            echo "❌ Error de conexión en puerto " . $this->port . ": " . $exception->getMessage();
            echo "<br>💡 Verifica que MySQL esté corriendo en el puerto " . $this->port;
        }
        
        return $this->conn;
    }

    // Función para ejecutar consultas SELECT
    public function select($query, $params = []) {
        try {
            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Error en SELECT: " . $e->getMessage());
            return false;
        }
    }

    // Función para ejecutar consultas INSERT, UPDATE, DELETE
    public function execute($query, $params = []) {
        try {
            $stmt = $this->conn->prepare($query);
            return $stmt->execute($params);
        } catch(PDOException $e) {
            error_log("Error en EXECUTE: " . $e->getMessage());
            return false;
        }
    }

    // Obtener el último ID insertado
    public function lastInsertId() {
        return $this->conn->lastInsertId();
    }

    // Cerrar conexión
    public function closeConnection() {
        $this->conn = null;
    }
}

// Función global para obtener conexión rápida
function conectarDB() {
    $database = new Database();
    return $database->getConnection();
}

// Verificar si la conexión funciona
function verificarConexion() {
    $db = new Database();
    $conn = $db->getConnection();
    
    if ($conn) {
        return true;
    } else {
        return false;
    }
}

// ========================================
// FUNCIÓN PARA OBTENER FECHA/HORA ACTUAL
// ========================================
function fechaHoraActual($formato = 'Y-m-d H:i:s') {
    return date($formato);
}

function fechaActual($formato = 'Y-m-d') {
    return date($formato);
}

function horaActual($formato = 'H:i:s') {
    return date($formato);
}

?>