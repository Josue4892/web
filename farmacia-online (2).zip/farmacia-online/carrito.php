    <?php
    $titulo_pagina = "Mi Carrito de Compras";
    include 'includes/header.php';
echo '<script>document.body.classList.add("carrito-page");</script>';
    if (!estaLogueado()) {
        redirigirConMensaje('login_viejo.php', 'Debes iniciar sesión para ver tu carrito', 'warning');
    }

    $usuario = obtenerUsuarioActual();
    $config = cargarConfiguracion();
    ?>

    <div class="container py-5">
        <div class="row">
            <div class="col-12 mb-4">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="catalogo.php">Productos</a></li>
                        <li class="breadcrumb-item active">Mi Carrito</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white border-bottom">
                        <div class="d-flex align-items-center justify-content-between">
                            <h4 class="mb-0">
                                <i class="fas fa-shopping-cart text-success me-2"></i>
                                Mi Carrito de Compras
                            </h4>
                            <button class="btn btn-outline-danger btn-sm" onclick="vaciarCarrito()">
                                <i class="fas fa-trash me-1"></i>Vaciar Carrito
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="carrito-contenido">
                            <div class="text-center py-5" id="carrito-vacio">
                                <i class="fas fa-shopping-cart fa-4x text-muted mb-3"></i>
                                <h5 class="text-muted">Tu carrito está vacío</h5>
                                <p class="text-muted mb-4">Explora nuestros productos y añade algunos a tu carrito</p>
                                <a href="catalogo.php" class="btn btn-success">
                                    <i class="fas fa-pills me-2"></i>Ver Productos
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between">
                    <a href="catalogo.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Seguir Comprando
                    </a>
                    <button class="btn btn-success" onclick="mostrarCheckout()" id="btn-checkout" style="display: none;">
                        <i class="fas fa-credit-card me-2"></i>Proceder al Pago
                    </button>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card border-0 shadow-sm sticky-top" style="top: 100px;">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-calculator me-2"></i>Resumen del Pedido
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Productos (<span id="total-items">0</span>):</span>
                            <span id="subtotal-carrito">S/ 0.00</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Delivery:</span>
                            <span class="text-success">Gratis</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-3">
                            <strong>Total:</strong>
                            <strong class="text-success" id="total-carrito">S/ 0.00</strong>
                        </div>

                        <div class="bg-light p-3 rounded mb-3">
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-truck text-success me-2"></i>
                                <small>Delivery gratis en toda Lima</small>
                            </div>
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-shield-alt text-success me-2"></i>
                                <small>Compra 100% segura</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <i class="fas fa-undo text-success me-2"></i>
                                <small>30 días para devoluciones</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="checkoutModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-credit-card me-2"></i>Finalizar Compra
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="form-checkout">
                    <div class="modal-body">
                        <div class="row mb-4">
                            <div class="col-12">
                                <h6 class="fw-bold text-success mb-3">
                                    <i class="fas fa-user me-2"></i>Información Personal
                                </h6>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nombre Completo *</label>
                                <input type="text" class="form-control" name="nombre_completo" 
                                    value="<?php echo $usuario['nombre']; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Teléfono *</label>
                                <input type="tel" class="form-control" name="telefono" 
                                    placeholder="999888777" maxlength="9" required>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-12">
                                <h6 class="fw-bold text-success mb-3">
                                    <i class="fas fa-map-marker-alt me-2"></i>Dirección de Entrega
                                </h6>
                            </div>
                            <div class="col-md-8 mb-3">
                                <label class="form-label">Dirección Completa *</label>
                                <input type="text" class="form-control" name="direccion" 
                                    placeholder="Av. Ejemplo 123, Departamento 4B" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Distrito *</label>
                                <select class="form-select" name="distrito" required>
                                    <option value="">Seleccionar...</option>
                                    <option value="San Isidro">San Isidro</option>
                                    <option value="Miraflores">Miraflores</option>
                                    <option value="Surco">Surco</option>
                                    <option value="La Molina">La Molina</option>
                                    <option value="Barranco">Barranco</option>
                                    <option value="San Borja">San Borja</option>
                                    <option value="Otro">Otro distrito</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-12">
                                <h6 class="fw-bold text-success mb-3">
                                    <i class="fas fa-credit-card me-2"></i>Método de Pago
                                </h6>
                            </div>
                            <div class="col-12">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="metodo_pago" 
                                        value="Efectivo" id="pago_efectivo" checked>
                                    <label class="form-check-label" for="pago_efectivo">
                                        <i class="fas fa-money-bill me-2"></i>Efectivo
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="metodo_pago" 
                                        value="Yape/Plin" id="pago_digital">
                                    <label class="form-check-label" for="pago_digital">
                                        <i class="fas fa-mobile-alt me-2"></i>Yape/Plin
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="metodo_pago" 
                                        value="Tarjeta" id="pago_tarjeta">
                                    <label class="form-check-label" for="pago_tarjeta">
                                        <i class="fas fa-credit-card me-2"></i>Tarjeta
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-12">
                                <label class="form-label">Comentarios Adicionales</label>
                                <textarea class="form-control" name="comentarios" rows="3" 
                                        placeholder="Instrucciones especiales para la entrega..."></textarea>
                            </div>
                        </div>

                        <div class="bg-light p-3 rounded">
                            <h6 class="fw-bold mb-2">Resumen Final</h6>
                            <div class="d-flex justify-content-between">
                                <span>Total a Pagar:</span>
                                <strong class="text-success" id="total-final-checkout">S/ 0.00</strong>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times me-2"></i>Cancelar
                        </button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-check me-2"></i>Confirmar Pedido
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>