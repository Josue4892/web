<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🧪 Test de WhatsApp - Diagnóstico</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
    .test-section { background: white; padding: 20px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #007bff; }
    .success { border-left-color: #28a745; background: #d4edda; }
    .error { border-left-color: #dc3545; background: #f8d7da; }
    .warning { border-left-color: #ffc107; background: #fff3cd; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 4px; overflow-x: auto; }
    .btn { background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; display: inline-block; margin: 5px; }
</style>";

// Verificar si se incluyen los archivos necesarios
echo "<div class='test-section'>";
echo "<h2>1. 📁 Verificación de Archivos</h2>";

$archivos_requeridos = [
    'includes/functions.php',
    'libreria/tcpdf.php'
];

foreach ($archivos_requeridos as $archivo) {
    if (file_exists($archivo)) {
        echo "✅ <strong>$archivo</strong> existe<br>";
    } else {
        echo "❌ <strong>$archivo</strong> NO encontrado<br>";
    }
}
echo "</div>";

// Intentar incluir functions.php
echo "<div class='test-section'>";
echo "<h2>2. 🔧 Carga de Funciones</h2>";
try {
    if (file_exists('includes/functions.php')) {
        require_once 'includes/functions.php';
        echo "✅ functions.php cargado correctamente<br>";
        
        // Verificar funciones críticas
        $funciones_criticas = [
            'cargarConfiguracion',
            'estaLogueado',
            'obtenerUsuarioActual',
            'formatearPrecio',
            'sanitizar'
        ];
        
        foreach ($funciones_criticas as $funcion) {
            if (function_exists($funcion)) {
                echo "✅ Función <code>$funcion()</code> disponible<br>";
            } else {
                echo "❌ Función <code>$funcion()</code> NO encontrada<br>";
            }
        }
    } else {
        echo "❌ No se puede cargar functions.php";
    }
} catch (Exception $e) {
    echo "❌ Error cargando functions.php: " . $e->getMessage();
}
echo "</div>";

// Test de configuración
echo "<div class='test-section'>";
echo "<h2>3. ⚙️ Test de Configuración</h2>";
try {
    if (function_exists('cargarConfiguracion')) {
        $config = cargarConfiguracion();
        echo "✅ Configuración cargada<br>";
        echo "<pre>";
        print_r($config['farmacia'] ?? 'No hay configuración de farmacia');
        echo "</pre>";
    } else {
        echo "❌ Función cargarConfiguracion() no disponible";
    }
} catch (Exception $e) {
    echo "❌ Error en configuración: " . $e->getMessage();
}
echo "</div>";

// Test de datos de pedido simulado
echo "<div class='test-section'>";
echo "<h2>4. 📋 Test con Datos Simulados</h2>";

$pedido_test = [
    'id' => 5,
    'usuario_nombre' => 'Carlos Test',
    'usuario_email' => 'carlos@test.com',
    'telefono' => '970765248',
    'total' => 18.00,
    'fecha_pedido' => date('Y-m-d H:i:s'),
    'estado' => 'pagado',
    'productos' => [
        [
            'producto_nombre' => 'Agua Oxigenada',
            'descripcion' => 'Antiséptico para heridas',
            'categoria_nombre' => 'Primeros Auxilios',
            'cantidad' => 2,
            'precio_unitario' => 9.00
        ]
    ]
];

echo "📋 Datos de pedido de prueba:<br>";
echo "<pre>";
print_r($pedido_test);
echo "</pre>";
echo "</div>";

// Test de generación de URL WhatsApp
echo "<div class='test-section'>";
echo "<h2>5. 📱 Test de URL WhatsApp</h2>";

function testGenerarURLWhatsApp($telefono, $mensaje) {
    $numero_limpio = preg_replace('/[^0-9]/', '', $telefono);
    
    if (strlen($numero_limpio) == 9) {
        $numero_limpio = '51' . $numero_limpio;
    }
    
    $mensaje_codificado = urlencode($mensaje);
    
    return "https://api.whatsapp.com/send?phone={$numero_limpio}&text={$mensaje_codificado}";
}

$mensaje_test = "🧪 Mensaje de prueba desde FarmaPlus\nPedido #000005\nTotal: S/ 18.00";
$url_whatsapp = testGenerarURLWhatsApp($pedido_test['telefono'], $mensaje_test);

echo "📱 Teléfono: {$pedido_test['telefono']}<br>";
echo "📝 Mensaje: <pre>$mensaje_test</pre>";
echo "🔗 URL generada: <br>";
echo "<code style='word-break: break-all;'>$url_whatsapp</code><br>";
echo "<a href='$url_whatsapp' target='_blank' class='btn'>🧪 Probar URL WhatsApp</a>";
echo "</div>";

// Test de directorio temporal
echo "<div class='test-section'>";
echo "<h2>6. 📁 Test de Directorio Temporal</h2>";

$temp_dir = __DIR__ . '/temp';
echo "📂 Directorio temporal: <code>$temp_dir</code><br>";

if (!file_exists($temp_dir)) {
    if (mkdir($temp_dir, 0755, true)) {
        echo "✅ Directorio temporal creado<br>";
    } else {
        echo "❌ No se pudo crear directorio temporal<br>";
    }
} else {
    echo "✅ Directorio temporal ya existe<br>";
}

if (is_writable($temp_dir)) {
    echo "✅ Directorio temporal es escribible<br>";
} else {
    echo "❌ Directorio temporal NO es escribible<br>";
}
echo "</div>";

// Test de generar PDF básico
echo "<div class='test-section'>";
echo "<h2>7. 📄 Test de Generación PDF Básico</h2>";

try {
    $html_basico = "
    <!DOCTYPE html>
    <html>
    <head><meta charset='UTF-8'><title>Test PDF</title></head>
    <body>
        <h1>Test de PDF - FarmaPlus</h1>
        <p>Pedido: {$pedido_test['id']}</p>
        <p>Cliente: {$pedido_test['usuario_nombre']}</p>
        <p>Total: S/ {$pedido_test['total']}</p>
        <p>Fecha: " . date('d/m/Y H:i') . "</p>
    </body>
    </html>";
    
    $filename_test = "temp/boleta_test_" . time() . ".html";
    
    if (file_put_contents($filename_test, $html_basico)) {
        echo "✅ Archivo HTML de prueba creado: <code>$filename_test</code><br>";
        echo "📊 Tamaño: " . filesize($filename_test) . " bytes<br>";
        echo "<a href='$filename_test' target='_blank' class='btn'>👀 Ver archivo generado</a>";
    } else {
        echo "❌ No se pudo crear archivo de prueba<br>";
    }
} catch (Exception $e) {
    echo "❌ Error generando archivo: " . $e->getMessage();
}
echo "</div>";

// Test de simulación de request
echo "<div class='test-section'>";
echo "<h2>8. 🔍 Simulación de Request WhatsApp</h2>";

function simularRequestWhatsApp($pedido) {
    try {
        // Simular lo que hace prepararWhatsApp()
        $temp_dir = __DIR__ . '/temp';
        
        // Simular generación de archivo
        $timestamp = time();
        $filename = "temp/boleta_test_{$pedido['id']}_{$timestamp}.html";
        
        $html_content = "
        <!DOCTYPE html>
        <html>
        <head><meta charset='UTF-8'></head>
        <body>
            <h1>Boleta de Venta #{$pedido['id']}</h1>
            <p>Cliente: {$pedido['usuario_nombre']}</p>
            <p>Total: S/ {$pedido['total']}</p>
        </body>
        </html>";
        
        if (!file_put_contents($filename, $html_content)) {
            throw new Exception('No se pudo generar archivo');
        }
        
        // Simular URL
        $protocol = 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $path = dirname($_SERVER['PHP_SELF'] ?? '');
        $boleta_url = $protocol . '://' . $host . $path . '/' . $filename;
        
        // Simular mensaje
        $mensaje = "🏥 FarmaPlus Test\n\n";
        $mensaje .= "Pedido #{$pedido['id']}\n";
        $mensaje .= "Cliente: {$pedido['usuario_nombre']}\n";
        $mensaje .= "Total: S/ {$pedido['total']}\n\n";
        $mensaje .= "Ver boleta: $boleta_url";
        
        $whatsapp_url = testGenerarURLWhatsApp($pedido['telefono'], $mensaje);
        
        return [
            'success' => true,
            'whatsapp_url' => $whatsapp_url,
            'boleta_url' => $boleta_url,
            'filename' => $filename,
            'mensaje' => $mensaje
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

$resultado_simulacion = simularRequestWhatsApp($pedido_test);

if ($resultado_simulacion['success']) {
    echo "<div class='success'>";
    echo "✅ <strong>Simulación EXITOSA</strong><br>";
    echo "📱 URL WhatsApp generada correctamente<br>";
    echo "📄 Archivo temporal creado<br>";
    echo "<br><strong>Resultado:</strong><br>";
    echo "<pre>";
    print_r($resultado_simulacion);
    echo "</pre>";
    echo "<a href='{$resultado_simulacion['whatsapp_url']}' target='_blank' class='btn'>🧪 Probar WhatsApp Simulado</a>";
    echo "<a href='{$resultado_simulacion['boleta_url']}' target='_blank' class='btn'>📄 Ver Boleta Simulada</a>";
    echo "</div>";
} else {
    echo "<div class='error'>";
    echo "❌ <strong>Error en simulación:</strong> {$resultado_simulacion['error']}";
    echo "</div>";
}
echo "</div>";

// Test de JavaScript
echo "<div class='test-section'>";
echo "<h2>9. 🖥️ Test de JavaScript</h2>";
echo "<button onclick='testJavaScript()' class='btn'>🧪 Probar JavaScript</button>";
echo "<div id='js-result'></div>";

echo "<script>
function testJavaScript() {
    const resultDiv = document.getElementById('js-result');
    resultDiv.innerHTML = '<p>🔄 Probando JavaScript...</p>';
    
    // Test fetch simulado
    const pedidoId = 5;
    const url = `generar_pdf.php?pedido_id=\${pedidoId}&accion=whatsapp`;
    
    resultDiv.innerHTML += `<p>📡 URL a probar: <code>\${url}</code></p>`;
    
    fetch(url, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        resultDiv.innerHTML += `<p>📊 Status: \${response.status}</p>`;
        resultDiv.innerHTML += `<p>📋 Content-Type: \${response.headers.get('content-type')}</p>`;
        
        if (!response.ok) {
            throw new Error(`HTTP \${response.status}: \${response.statusText}`);
        }
        
        return response.text();
    })
    .then(text => {
        resultDiv.innerHTML += '<p>✅ Respuesta recibida:</p>';
        resultDiv.innerHTML += `<pre style=\"max-height: 200px; overflow-y: auto;\">\${text}</pre>`;
        
        try {
            const json = JSON.parse(text);
            resultDiv.innerHTML += '<p>✅ JSON válido parseado</p>';
            if (json.success) {
                resultDiv.innerHTML += '<p>🎉 Respuesta exitosa del servidor</p>';
            } else {
                resultDiv.innerHTML += `<p>❌ Error del servidor: \${json.mensaje}</p>`;
            }
        } catch (e) {
            resultDiv.innerHTML += '<p>❌ Respuesta no es JSON válido</p>';
        }
    })
    .catch(error => {
        resultDiv.innerHTML += `<p>❌ Error en fetch: \${error.message}</p>`;
    });
}
</script>";
echo "</div>";

echo "<div class='test-section'>";
echo "<h2>🎯 Resumen del Diagnóstico</h2>";
echo "<p>Este test te ayudará a identificar exactamente dónde está el problema.</p>";
echo "<p><strong>Pasos a seguir:</strong></p>";
echo "<ol>";
echo "<li>Revisa cada sección para identificar errores</li>";
echo "<li>Prueba el JavaScript al final</li>";
echo "<li>Compara los resultados con lo que debería funcionar</li>";
echo "<li>Identifica el punto exacto de falla</li>";
echo "</ol>";
echo "</div>";
?>