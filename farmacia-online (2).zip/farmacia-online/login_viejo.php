<?php
$titulo_pagina = "Login y Registro";
require_once 'includes/functions.php';

$error_login = '';
$error_registro = '';
$success_message = '';

// Procesar LOGIN
if ($_POST && isset($_POST['login'])) {
    $email = sanitizar($_POST['email']);
    $password = $_POST['password'];
    
    if (empty($email) || empty($password)) {
        $error_login = 'Por favor completa todos los campos';
    } elseif (validarLogin($email, $password)) {
        // Redirigir según el rol
        $usuario = obtenerUsuarioActual();
        if ($usuario['rol_id'] == 1) {
            header('Location: admin.php');
            exit();
        } else {
            header('Location: index.php');
            exit();
        }
    } else {
        $error_login = 'Email o contraseña incorrectos';
    }
}

// Procesar REGISTRO (igual al que funciona)
if ($_POST && isset($_POST['registro'])) {
    $nombre = sanitizar($_POST['nombre']);
    $email = sanitizar($_POST['email']);
    $telefono = sanitizar($_POST['telefono']);
    $password = $_POST['password'];
    $confirmar_password = $_POST['confirmar_password'];
    $terminos = isset($_POST['terminos']) ? $_POST['terminos'] : '';
    
    // Validaciones
    if (empty($nombre) || empty($email) || empty($telefono) || empty($password) || empty($confirmar_password)) {
        $error_registro = 'Por favor completa todos los campos';
    } elseif (!$terminos) {
        $error_registro = 'Debes aceptar los términos y condiciones';
    } elseif (!validarEmail($email)) {
        $error_registro = 'Email no válido';
    } elseif (!validarTelefono($telefono)) {
        $error_registro = 'El teléfono debe tener 9 dígitos';
    } elseif (strlen($password) < 6) {
        $error_registro = 'La contraseña debe tener al menos 6 caracteres';
    } elseif ($password !== $confirmar_password) {
        $error_registro = 'Las contraseñas no coinciden';
    } elseif (registrarUsuario($nombre, $email, $telefono, $password)) {
        $success_message = '¡Usuario registrado exitosamente! Ya puedes iniciar sesión.';
    } else {
        $error_registro = 'Este email ya está registrado';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FarmaPlus - Iniciar Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --verde-principal: #28a745;
        }
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .auth-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 0 auto;
            overflow: hidden;
        }
        .auth-tabs {
            display: flex;
            background: #f8f9fa;
        }
        .auth-tab {
            flex: 1;
            padding: 15px;
            text-align: center;
            background: none;
            border: none;
            cursor: pointer;
            font-weight: 600;
            color: #6c757d;
            transition: all 0.3s ease;
        }
        .auth-tab.active {
            background: white;
            color: var(--verde-principal);
            border-bottom: 3px solid var(--verde-principal);
        }
        .auth-tab:hover {
            background: rgba(40, 167, 69, 0.1);
            color: var(--verde-principal);
        }
        .tab-content {
            display: none;
            padding: 30px;
        }
        .tab-content.active {
            display: block;
        }
        .btn-auth {
            background: linear-gradient(45deg, var(--verde-principal), #20c997);
            border: none;
            border-radius: 25px;
            padding: 12px 30px;
            font-weight: 600;
            color: white;
            width: 100%;
            transition: all 0.3s ease;
        }
        .btn-auth:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(40, 167, 69, 0.3);
            color: white;
        }
        .form-control:focus {
            border-color: var(--verde-principal);
            box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.25);
        }
        .form-check-input:checked {
            background-color: var(--verde-principal);
            border-color: var(--verde-principal);
        }
        .welcome-text {
            background: linear-gradient(45deg, var(--verde-principal), #20c997);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .logo {
            width: 60px;
            height: 60px;
            background: linear-gradient(45deg, var(--verde-principal), #20c997);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="auth-card">
            <!-- Header -->
            <div class="text-center pt-4 pb-2">
                <div class="logo">
                    <i class="fas fa-plus"></i>
                </div>
                <h2 class="welcome-text fw-bold mb-1">FarmaPlus</h2>
                <p class="text-muted small">Tu salud es nuestra prioridad</p>
            </div>

            <!-- Tabs -->
            <div class="auth-tabs">
                <button class="auth-tab <?php echo !$error_registro && !$success_message ? 'active' : ''; ?>" onclick="showTab('login')">
                    <i class="fas fa-sign-in-alt me-2"></i>Iniciar Sesión
                </button>
                <button class="auth-tab <?php echo $error_registro || $success_message ? 'active' : ''; ?>" onclick="showTab('registro')">
                    <i class="fas fa-user-plus me-2"></i>Registrarse
                </button>
            </div>

            <!-- LOGIN TAB -->
            <div id="login-tab" class="tab-content <?php echo !$error_registro && !$success_message ? 'active' : ''; ?>">
                <h4 class="text-center mb-4">Iniciar Sesión</h4>

                <?php if ($error_login): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error_login; ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <input type="hidden" name="login" value="1">
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-envelope me-2"></i>Correo Electrónico
                        </label>
                        <input type="email" class="form-control" name="email" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-lock me-2"></i>Contraseña
                        </label>
                        <input type="password" class="form-control" name="password" required>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox">
                            <label class="form-check-label small">
                                Recordarme
                            </label>
                        </div>
                        <a href="#" class="small text-decoration-none">¿Olvidaste tu contraseña?</a>
                    </div>

                    <button type="submit" class="btn btn-auth mb-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Iniciar Sesión
                    </button>

                    <!-- Datos de prueba -->
                    <div class="alert alert-info small">
                        <strong>Datos de prueba:</strong><br>
                        <strong>Admin:</strong> admin@farmacia.com / admin123
                    </div>
                </form>
            </div>

            <!-- REGISTRO TAB -->
            <div id="registro-tab" class="tab-content <?php echo $error_registro || $success_message ? 'active' : ''; ?>">
                <h4 class="text-center mb-4">Crear Cuenta</h4>

                <?php if ($error_registro): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error_registro; ?>
                    </div>
                <?php endif; ?>

                <?php if ($success_message): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <input type="hidden" name="registro" value="1">
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-user me-2"></i>Nombre Completo
                        </label>
                        <input type="text" class="form-control" name="nombre" required 
                               value="<?php echo isset($_POST['nombre']) ? htmlspecialchars($_POST['nombre']) : ''; ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-envelope me-2"></i>Correo Electrónico
                        </label>
                        <input type="email" class="form-control" name="email" required 
                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-phone me-2"></i>Teléfono (9 dígitos)
                        </label>
                        <input type="tel" class="form-control" name="telefono" maxlength="9" pattern="[0-9]{9}" required 
                               value="<?php echo isset($_POST['telefono']) ? htmlspecialchars($_POST['telefono']) : ''; ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-lock me-2"></i>Contraseña (mín. 6 caracteres)
                        </label>
                        <input type="password" class="form-control" name="password" minlength="6" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-lock me-2"></i>Confirmar Contraseña
                        </label>
                        <input type="password" class="form-control" name="confirmar_password" minlength="6" required>
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" name="terminos" value="1" required>
                        <label class="form-check-label small">
                            Acepto los términos y condiciones y la política de privacidad
                        </label>
                    </div>

                    <button type="submit" class="btn btn-auth">
                        <i class="fas fa-user-plus me-2"></i>Crear Cuenta
                    </button>
                </form>
            </div>

            <!-- Footer -->
            <div class="text-center p-3 bg-light">
                <small class="text-muted">
                    ¿Necesitas ayuda? 
                    <a href="tel:+51999888777" class="text-decoration-none">
                        <i class="fas fa-phone me-1"></i>+51 999 888 777
                    </a>
                </small>
            </div>
        </div>
    </div>

    <!-- JavaScript SIMPLE para las tabs -->
    <script>
        function showTab(tabName) {
            // Ocultar todas las tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remover active de todos los botones
            document.querySelectorAll('.auth-tab').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Mostrar tab seleccionada
            document.getElementById(tabName + '-tab').classList.add('active');
            
            // Activar botón correspondiente
            event.target.classList.add('active');
        }

        console.log('🔑 Login DEFINITIVO funcionando');

        // Auto-switch a registro si hay errores/éxito
        <?php if ($error_registro || $success_message): ?>
        document.addEventListener('DOMContentLoaded', function() {
            showTab('registro');
            document.querySelector('[onclick="showTab(\'registro\')"]').classList.add('active');
        });
        <?php endif; ?>
    </script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>