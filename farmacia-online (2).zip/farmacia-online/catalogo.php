<?php
$titulo_pagina = "Catálogo de Productos";
include 'includes/header.php';

$categoria_id = isset($_GET['categoria']) ? (int)$_GET['categoria'] : null;
$busqueda = isset($_GET['busqueda']) ? sanitizar($_GET['busqueda']) : '';
$orden = isset($_GET['orden']) ? sanitizar($_GET['orden']) : 'nombre_asc';

$productos = obtenerProductos($categoria_id, $busqueda);
$categorias = obtenerCategorias();
$categoria_actual = $categoria_id ? obtenerCategoriaPorId($categoria_id) : null;

function ordenarProductos($productos, $orden) {
    switch ($orden) {
        case 'precio_asc':
            usort($productos, fn($a, $b) => $a['precio'] <=> $b['precio']);
            break;
        case 'precio_desc':
            usort($productos, fn($a, $b) => $b['precio'] <=> $a['precio']);
            break;
        case 'nombre_desc':
            usort($productos, fn($a, $b) => strcmp($b['nombre'], $a['nombre']));
            break;
        default: // nombre_asc
            usort($productos, fn($a, $b) => strcmp($a['nombre'], $b['nombre']));
    }
    return $productos;
}

$productos = ordenarProductos($productos, $orden);
?>

<div id="carrito-sidebar" class="carrito-sidebar">
    <div class="carrito-header">
        <h5 class="mb-0">
            <i class="fas fa-shopping-cart me-2"></i>MI CARRITO 
            <span id="carrito-contador-sidebar" class="badge bg-success">0</span>
        </h5>
        <button class="btn-close-carrito" onclick="cerrarCarrito()">
            <i class="fas fa-times"></i>
        </button>
    </div>
    
    <div class="carrito-contenido">
        <div id="carrito-productos" class="carrito-productos">
        </div>
        
        <div class="carrito-resumen">
            <hr>
            <div class="d-flex justify-content-between mb-2">
                <span>Subtotal:</span>
                <span id="carrito-subtotal">S/ 0.00</span>
            </div>
            <div class="d-flex justify-content-between mb-3 fw-bold">
                <span>TOTAL:</span>
                <span id="carrito-total" class="text-success">S/ 0.00</span>
            </div>
            
            <div class="carrito-acciones">
                <a href="carrito.php" class="btn btn-success w-100 mb-2">
                    <i class="fas fa-credit-card me-2"></i>PROCEDER AL PAGO
                </a>
                <button class="btn btn-outline-danger w-100 mb-2" onclick="vaciarCarrito()">
                    <i class="fas fa-trash me-2"></i>VACIAR CARRITO
                </button>
                <button class="btn btn-outline-secondary w-100" onclick="cerrarCarrito()">
                    <i class="fas fa-times me-2"></i>CERRAR
                </button>
            </div>
        </div>
    </div>
</div>

<div id="carrito-overlay" class="carrito-overlay" onclick="cerrarCarrito()"></div>

<!-- Contenido principal -->
<div class="container-fluid py-4" id="contenido-principal">
    <div class="row">
        <div class="col-lg-3 d-none d-lg-block">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-success text-white">
                    <h6 class="mb-0"><i class="fas fa-filter me-2"></i>Filtros</h6>
                </div>
                <div class="card-body">
                    <!-- Categorías -->
                    <div class="mb-4">
                        <h6 class="fw-bold mb-3">Categorías</h6>
                        <div class="list-group list-group-flush">
                            <a href="catalogo.php" 
                               class="list-group-item list-group-item-action <?php echo !$categoria_id ? 'active' : ''; ?>">
                                <i class="fas fa-th-large me-2"></i>Todas las categorías
                                <span class="badge bg-secondary float-end"><?php echo count($productos); ?></span>
                            </a>
                            <?php foreach ($categorias as $cat): ?>
                            <a href="catalogo.php?categoria=<?php echo $cat['id']; ?>" 
                               class="list-group-item list-group-item-action <?php echo $categoria_id == $cat['id'] ? 'active' : ''; ?>">
                                <i class="fas fa-pills me-2"></i><?php echo $cat['nombre']; ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Ordenamiento -->
                    <div class="mb-4">
                        <h6 class="fw-bold mb-3">Ordenar por</h6>
                        <select class="form-select" id="ordenamiento" onchange="aplicarOrden()">
                            <option value="nombre_asc" <?php echo $orden == 'nombre_asc' ? 'selected' : ''; ?>>Nombre A-Z</option>
                            <option value="nombre_desc" <?php echo $orden == 'nombre_desc' ? 'selected' : ''; ?>>Nombre Z-A</option>
                            <option value="precio_asc" <?php echo $orden == 'precio_asc' ? 'selected' : ''; ?>>Precio menor a mayor</option>
                            <option value="precio_desc" <?php echo $orden == 'precio_desc' ? 'selected' : ''; ?>>Precio mayor a menor</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-1">
                        <?php if ($categoria_actual): ?>
                            <?php echo $categoria_actual['nombre']; ?>
                        <?php elseif ($busqueda): ?>
                            Resultados para "<?php echo $busqueda; ?>"
                        <?php else: ?>
                            Todos los productos
                        <?php endif; ?>
                    </h2>
                    <p class="text-muted mb-0"><?php echo count($productos); ?> productos encontrados</p>
                </div>

                <div class="d-lg-none">
                    <button class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#filtrosModal">
                        <i class="fas fa-filter me-2"></i>Filtros
                    </button>
                </div>
            </div>

            <?php if (empty($productos)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No se encontraron productos</h4>
                    <p class="text-muted">Intenta con otra búsqueda o categoría</p>
                    <a href="catalogo.php" class="btn btn-success">Ver todos los productos</a>
                </div>
            <?php else: ?>
                <div class="row g-4" id="productos-grid">
                    <?php foreach ($productos as $producto): ?>
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="card producto-card h-100 border-0 shadow-sm" data-producto-id="<?php echo $producto['id']; ?>">
                            <!-- Imagen del producto -->
                            <div class="position-relative">
                                <img src="<?php echo obtenerImagenProducto($producto['imagen']); ?>" 
                                     class="card-img-top" alt="<?php echo $producto['nombre']; ?>"
                                     style="height: 220px; object-fit: cover;">
                                
                                <!-- Badges -->
                                <?php if ($producto['stock'] < 10 && $producto['stock'] > 0): ?>
                                <span class="position-absolute top-0 end-0 badge bg-warning m-2">
                                    <i class="fas fa-exclamation-triangle me-1"></i>Pocas unidades
                                </span>
                                <?php elseif ($producto['stock'] == 0): ?>
                                <span class="position-absolute top-0 end-0 badge bg-danger m-2">
                                    <i class="fas fa-times me-1"></i>Agotado
                                </span>
                                <?php endif; ?>
                            </div>

                            <!-- Contenido de la card -->
                            <div class="card-body d-flex flex-column">
                                <h6 class="card-title fw-bold mb-2"><?php echo $producto['nombre']; ?></h6>
                                <p class="card-text text-muted small flex-grow-1 mb-3">
                                    <?php echo substr($producto['descripcion'], 0, 80) . '...'; ?>
                                </p>
                                
                                <!-- Precio -->
                                <div class="precio-section mb-3">
                                    <span class="h5 text-success fw-bold">
                                        <?php echo formatearPrecio($producto['precio']); ?>
                                    </span>
                                    <br>
                                    <small class="text-muted">
                                        Stock: <?php echo $producto['stock']; ?> unidades
                                    </small>
                                </div>

                                <!-- Botones de acción -->
                                <div class="producto-acciones">
                                    <!-- Estado inicial: botón agregar -->
                                    <div class="accion-inicial">
                                        <button class="btn btn-success w-100" 
                                                onclick="agregarAlCarrito(<?php echo $producto['id']; ?>)"
                                                <?php echo $producto['stock'] == 0 ? 'disabled' : ''; ?>>
                                            <i class="fas fa-cart-plus me-2"></i>
                                            <?php echo $producto['stock'] == 0 ? 'Agotado' : 'Agregar al carrito'; ?>
                                        </button>
                                    </div>

                                    <!-- Estado con controles (inicialmente oculto) -->
                                    <div class="accion-controles" style="display: none;">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <button class="btn btn-outline-success btn-sm" 
                                                    onclick="decrementarProducto(<?php echo $producto['id']; ?>)">
                                                <i class="fas fa-minus"></i>
                                            </button>
                                            
                                            <span class="cantidad-producto fw-bold mx-3">1</span>
                                            
                                            <button class="btn btn-outline-success btn-sm" 
                                                    onclick="incrementarProducto(<?php echo $producto['id']; ?>)">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                            
                                            <button class="btn btn-outline-danger btn-sm ms-2" 
                                                    onclick="eliminarDelCarrito(<?php echo $producto['id']; ?>)"
                                                    title="Eliminar del carrito">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="modal fade" id="filtrosModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-filter me-2"></i>Filtros</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-4">
                    <h6 class="fw-bold mb-3">Categorías</h6>
                    <div class="list-group">
                        <a href="catalogo.php" class="list-group-item list-group-item-action">
                            Todas las categorías
                        </a>
                        <?php foreach ($categorias as $cat): ?>
                        <a href="catalogo.php?categoria=<?php echo $cat['id']; ?>" 
                           class="list-group-item list-group-item-action">
                            <?php echo $cat['nombre']; ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function aplicarOrden() {
    const orden = document.getElementById('ordenamiento').value;
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set('orden', orden);
    window.location.search = urlParams.toString();
}

console.log('📋 Catálogo iniciado - carrito.js se encarga de todo');
</script>

<?php include 'includes/footer.php'; ?>