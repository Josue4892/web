let carritoItems = [];
let productosDataCarrito = {};

document.addEventListener('DOMContentLoaded', function () {
    console.log('🛒 Inicializando carrito...');

    cargarCarritoDesdeStorage();
    configurarEventosCarrito();
    cargarProductosDesdeBD().catch(() => {
        cargarProductosDesdeDOM();
    });
    actualizarInterfazCompleta();

    console.log('✅ Carrito inicializado correctamente');
});


async function cargarProductosDesdeBD() {
    try {
        const response = await fetch('api/productos.php');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const texto = await response.text();
        if (!texto.trim().startsWith('{') && !texto.trim().startsWith('[')) {
            throw new Error('Respuesta no es JSON válido');
        }

        const resultado = JSON.parse(texto);

        if (resultado.success && resultado.data) {
            resultado.data.forEach(producto => {
                productosDataCarrito[producto.id] = {
                    id: parseInt(producto.id),
                    nombre: producto.nombre,
                    precio: parseFloat(producto.precio),
                    stock: parseInt(producto.stock),
                    imagen: producto.imagen || 'producto_default.jpg',
                    disponible: parseInt(producto.stock) > 0
                };
            });
            console.log(`✅ ${Object.keys(productosDataCarrito).length} productos cargados desde API`);
            return true;
        } else {
            throw new Error('API no devolvió datos válidos');
        }
    } catch (error) {
        console.error('❌ Error cargando desde API:', error);
        throw error;
    }
}

function cargarProductosDesdeDOM() {
    console.log('🔄 Cargando productos desde DOM...');

    document.querySelectorAll('.producto-card, [data-producto-id]').forEach(card => {
        const productId = parseInt(card.getAttribute('data-producto-id')) ||
            parseInt(card.querySelector('[onclick*="agregarAlCarrito"]')?.getAttribute('onclick')?.match(/\d+/)?.[0]);

        if (!productId) return;

        const nombre = card.querySelector('.card-title, h6, h5')?.textContent?.trim() || `Producto ${productId}`;
        const precioElement = card.querySelector('.h5, .precio-section .h5, .text-success');
        const precioText = precioElement?.textContent || '0';
        const precio = parseFloat(precioText.replace(/[^0-9.]/g, '')) || 0;

        productosDataCarrito[productId] = {
            id: productId,
            nombre: nombre,
            precio: precio,
            stock: 50,
            imagen: 'producto_default.jpg',
            disponible: true
        };
    });

    console.log(`📋 ${Object.keys(productosDataCarrito).length} productos cargados desde DOM`);
}

function agregarAlCarrito(productId) {
    console.log('🛒 Agregando producto:', productId);

    const producto = productosDataCarrito[productId];
    if (!producto) {
        mostrarNotificacion('Producto no encontrado', 'error');
        return false;
    }

    const cantidadActual = obtenerCantidadEnCarrito(productId);
    const nuevaCantidad = cantidadActual + 1;

    if (nuevaCantidad > producto.stock) {
        mostrarNotificacion(`Solo hay ${producto.stock} unidades disponibles`, 'warning');
        return false;
    }

    const itemExistente = carritoItems.find(item => item.id === productId);

    if (itemExistente) {
        itemExistente.cantidad = nuevaCantidad;
    } else {
        carritoItems.push({
            id: productId,
            nombre: producto.nombre,
            precio: producto.precio,
            imagen: producto.imagen,
            cantidad: 1,
            fechaAgregado: new Date().toISOString()
        });
    }

    guardarCarritoEnStorage();
    actualizarInterfazCompleta();
    mostrarNotificacion(`${producto.nombre} agregado al carrito`, 'success');
    return true;
}

function incrementarProducto(productId) {
    const itemCarrito = carritoItems.find(item => item.id === productId);
    const producto = productosDataCarrito[productId];

    if (!itemCarrito || !producto) return false;

    if (itemCarrito.cantidad < producto.stock) {
        itemCarrito.cantidad += 1;
        guardarCarritoEnStorage();
        actualizarInterfazCompleta();
        return true;
    } else {
        mostrarNotificacion('Stock máximo alcanzado', 'warning');
        return false;
    }
}

function decrementarProducto(productId) {
    const itemCarrito = carritoItems.find(item => item.id === productId);
    if (!itemCarrito) return false;

    if (itemCarrito.cantidad > 1) {
        itemCarrito.cantidad -= 1;
        guardarCarritoEnStorage();
        actualizarInterfazCompleta();
    } else {
        eliminarDelCarrito(productId);
    }
    return true;
}

function eliminarDelCarrito(productId) {
    const indice = carritoItems.findIndex(item => item.id === productId);
    if (indice !== -1) {
        const producto = carritoItems[indice];
        carritoItems.splice(indice, 1);
        guardarCarritoEnStorage();
        actualizarInterfazCompleta();
        mostrarNotificacion(`${producto.nombre} eliminado`, 'info');
        return true;
    }
    return false;
}

function vaciarCarrito() {
    if (carritoItems.length === 0) {
        mostrarNotificacion('El carrito ya está vacío', 'info');
        return;
    }

    if (confirm('¿Vaciar todo el carrito?')) {
        carritoItems = [];
        guardarCarritoEnStorage();
        actualizarInterfazCompleta();
        mostrarNotificacion('Carrito vaciado', 'info');
    }
}



function actualizarInterfazCompleta() {
    actualizarContadorCarrito();
    actualizarPaginaCarrito();
    actualizarTodosLosResumenes();
}

function actualizarContadorCarrito() {
    const contadores = document.querySelectorAll('#contador-carrito, #carrito-contador, .carrito-contador');
    const cantidadTotal = obtenerCantidadTotal();

    contadores.forEach(contador => {
        if (contador) {
            contador.textContent = cantidadTotal;
            contador.style.display = cantidadTotal > 0 ? 'inline' : 'none';
        }
    });
}

function actualizarPaginaCarrito() {
    if (window.location.pathname.includes('carrito.php')) {
        const contenidoCarrito = document.getElementById('carrito-contenido');
        const carritoVacio = document.getElementById('carrito-vacio');

        if (contenidoCarrito && carritoVacio) {
            if (carritoItems.length === 0) {
                carritoVacio.style.display = 'block';
                contenidoCarrito.style.display = 'none';
            } else {
                carritoVacio.style.display = 'none';
                contenidoCarrito.style.display = 'block';
                mostrarProductosEnPagina();
            }
        }
    }
}

function mostrarProductosEnPagina() {
    const contenedor = document.getElementById('carrito-contenido');
    if (!contenedor) return;

    let html = '';
    carritoItems.forEach((item) => {
        const subtotal = item.precio * item.cantidad;
        html += `
            <div class="carrito-item border rounded p-3 mb-3">
                <div class="row align-items-center">
                    <div class="col-md-2">
                        <img src="assets/images/productos/${item.imagen}" alt="${item.nombre}" 
                             class="img-fluid rounded" style="height: 80px; object-fit: cover;"
                             onerror="this.src='assets/images/productos/producto_default.jpg'">
                    </div>
                    <div class="col-md-4">
                        <h6 class="fw-bold">${item.nombre}</h6>
                        <p class="text-muted small">${formatearPrecio(item.precio)} por unidad</p>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group input-group-sm">
                            <button class="btn btn-outline-secondary" onclick="decrementarProducto(${item.id})">-</button>
                            <input type="number" class="form-control text-center" value="${item.cantidad}" readonly>
                            <button class="btn btn-outline-secondary" onclick="incrementarProducto(${item.id})">+</button>
                        </div>
                    </div>
                    <div class="col-md-2 text-end">
                        <div class="fw-bold">${formatearPrecio(subtotal)}</div>
                    </div>
                    <div class="col-md-1 text-end">
                        <button class="btn btn-outline-danger btn-sm" onclick="eliminarDelCarrito(${item.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    });

    contenedor.innerHTML = html;
}

function actualizarTodosLosResumenes() {
    const totalItems = obtenerCantidadTotal();
    const subtotal = calcularSubtotal();
    const precioFormateado = formatearPrecio(subtotal);

    const elementosActualizar = [
        'total-items',
        'subtotal-carrito',
        'total-carrito',
        'carrito-subtotal',
        'carrito-total',
        'total-final-checkout'
    ];

    elementosActualizar.forEach(id => {
        const elemento = document.getElementById(id);
        if (elemento) {
            if (id === 'total-items') {
                elemento.textContent = totalItems;
            } else {
                elemento.textContent = precioFormateado;
            }
        }
    });

    const btnCheckout = document.getElementById('btn-checkout');
    if (btnCheckout) {
        btnCheckout.style.display = totalItems > 0 ? 'inline-block' : 'none';
    }
}



function mostrarCheckout() {
    console.log('🛒 Abriendo checkout...');

    if (carritoItems.length === 0) {
        mostrarNotificacion('Tu carrito está vacío', 'warning');
        return;
    }

    const modalElement = document.getElementById('checkoutModal');
    if (!modalElement) {
        mostrarNotificacion('Error: Modal de checkout no encontrado', 'error');
        return;
    }

    actualizarTodosLosResumenes();

    try {
        const modal = new bootstrap.Modal(modalElement);
        modal.show();

        setTimeout(() => {
            actualizarTodosLosResumenes();
        }, 100);

    } catch (error) {
        console.error('❌ Error mostrando modal:', error);
        mostrarNotificacion('Error al abrir el checkout', 'error');
    }
}

async function procesarPedidoReal(datosFormulario) {
    try {
        console.log('🛒 Procesando pedido...');

        // DATOS SIMPLIFICADOS para la API
        const pedidoData = {
            productos: carritoItems,
            telefono: datosFormulario.telefono,
            direccion: datosFormulario.direccion,
            distrito: datosFormulario.distrito,
            metodo_pago: datosFormulario.metodo_pago,
            comentarios: datosFormulario.comentarios || '',
            total: calcularSubtotal()
        };

        console.log('📤 Enviando datos:', pedidoData);

        // Usar fetch más simple
        const response = await fetch('api/pedidos.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(pedidoData)
        });

        console.log('📥 Status:', response.status);

        // Leer respuesta como texto primero para debug
        const textoRespuesta = await response.text();
        console.log('📥 Respuesta texto:', textoRespuesta);

        // Intentar parsear como JSON
        let resultado;
        try {
            resultado = JSON.parse(textoRespuesta);
        } catch (e) {
            console.error('❌ Error parseando JSON:', e);
            throw new Error('La API devolvió una respuesta inválida: ' + textoRespuesta.substring(0, 100));
        }

        console.log('📥 Resultado parseado:', resultado);

        if (resultado.success) {
            // ÉXITO
            carritoItems = [];
            guardarCarritoEnStorage();
            actualizarInterfazCompleta();

            // Cerrar modal de checkout
            const modal = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
            if (modal) modal.hide();

            // Mostrar modal de confirmación en lugar de WhatsApp automático
            mostrarModalConfirmacion(resultado.data.pedido_id);

        } else {
            throw new Error(resultado.message || 'Error desconocido del servidor');
        }

    } catch (error) {
        console.error('❌ Error completo:', error);
        mostrarNotificacion('Error: ' + error.message, 'error');
    }
}

function mostrarModalConfirmacion(pedidoId) {
    const modalHTML = `
        <div class="modal fade" id="modalConfirmacionPedido" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow">
                    <div class="modal-body text-center p-5">
                        <div class="mb-4">
                            <i class="fas fa-check-circle fa-4x text-success mb-3"></i>
                            <h3 class="text-success fw-bold">¡Pedido Realizado!</h3>
                        </div>
                        
                        <div class="mb-4">
                            <p class="text-muted mb-2">Tu pedido ha sido procesado exitosamente</p>
                            <div class="bg-light p-3 rounded mb-3">
                                <strong>Número de Pedido: #${String(pedidoId).padStart(6, '0')}</strong>
                            </div>
                            <p class="small text-muted">
                                Recibirás una confirmación pronto. Puedes revisar el estado de tu pedido en tu perfil.
                            </p>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="button" class="btn btn-success btn-lg" onclick="irAPerfil()">
                                <i class="fas fa-user me-2"></i>Ver Mi Perfil
                            </button>
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-home me-2"></i>Continuar Comprando
                            </button>
                        </div>
                        
                        <div class="mt-4 pt-3 border-top">
                            <small class="text-muted">
                                <i class="fas fa-info-circle me-1"></i>
                                Te contactaremos pronto para confirmar tu pedido
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    const modalAnterior = document.getElementById('modalConfirmacionPedido');
    if (modalAnterior) {
        modalAnterior.remove();
    }

    document.body.insertAdjacentHTML('beforeend', modalHTML);

    const modal = new bootstrap.Modal(document.getElementById('modalConfirmacionPedido'));
    modal.show();

    document.getElementById('modalConfirmacionPedido').addEventListener('hidden.bs.modal', function () {
        this.remove();
    });
}

function irAPerfil() {
    const modal = bootstrap.Modal.getInstance(document.getElementById('modalConfirmacionPedido'));
    if (modal) modal.hide();

    setTimeout(() => {
        window.location.href = 'perfil.php';
    }, 300);
}

function configurarEventosCarrito() {
    document.addEventListener('submit', function (e) {
        if (e.target.id === 'form-checkout') {
            e.preventDefault();

            const form = e.target;
            const datosFormulario = {
                nombre_completo: form.nombre_completo.value,
                telefono: form.telefono.value,
                direccion: form.direccion.value,
                distrito: form.distrito.value,
                metodo_pago: form.metodo_pago.value,
                comentarios: form.comentarios.value
            };

            if (!datosFormulario.nombre_completo || !datosFormulario.telefono ||
                !datosFormulario.direccion || !datosFormulario.distrito) {
                mostrarNotificacion('Por favor complete todos los campos obligatorios', 'warning');
                return;
            }

            procesarPedidoReal(datosFormulario);
        }
    });
}



function calcularSubtotal() {
    return carritoItems.reduce((total, item) => total + (item.precio * item.cantidad), 0);
}

function obtenerCantidadTotal() {
    return carritoItems.reduce((total, item) => total + item.cantidad, 0);
}

function obtenerCantidadEnCarrito(productId) {
    const item = carritoItems.find(item => item.id === productId);
    return item ? item.cantidad : 0;
}

function guardarCarritoEnStorage() {
    try {
        localStorage.setItem('farmacia_carrito', JSON.stringify(carritoItems));
    } catch (error) {
        console.error('❌ Error guardando carrito:', error);
    }
}

function cargarCarritoDesdeStorage() {
    try {
        const carritoGuardado = localStorage.getItem('farmacia_carrito');
        if (carritoGuardado) {
            carritoItems = JSON.parse(carritoGuardado);
            console.log('📥 Carrito cargado:', carritoItems.length, 'items');
        }
    } catch (error) {
        console.error('❌ Error cargando carrito:', error);
        carritoItems = [];
    }
}

function formatearPrecio(precio) {
    return `S/ ${precio.toFixed(2)}`;
}

function mostrarNotificacion(mensaje, tipo = 'info') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${tipo === 'success' ? 'success' : tipo === 'warning' ? 'warning' : tipo === 'error' ? 'danger' : 'info'} position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    toast.innerHTML = `
        <i class="fas fa-${tipo === 'success' ? 'check-circle' : tipo === 'warning' ? 'exclamation-triangle' : tipo === 'error' ? 'times-circle' : 'info-circle'} me-2"></i>
        ${mensaje}
        <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
    `;

    document.body.appendChild(toast);

    setTimeout(() => {
        if (toast.parentNode) {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

window.agregarAlCarrito = agregarAlCarrito;
window.incrementarProducto = incrementarProducto;
window.decrementarProducto = decrementarProducto;
window.eliminarDelCarrito = eliminarDelCarrito;
window.vaciarCarrito = vaciarCarrito;
window.mostrarCheckout = mostrarCheckout;
window.actualizarTodosLosResumenes = actualizarTodosLosResumenes;
window.mostrarModalConfirmacion = mostrarModalConfirmacion;
window.irAPerfil = irAPerfil;
window.carritoItems = carritoItems;

console.log('🛒 Carrito.js cargado correctamente');