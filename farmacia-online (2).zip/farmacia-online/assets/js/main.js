let isScrolled = false;

document.addEventListener('DOMContentLoaded', function () {
    inicializarComponentes();
    configurarEventListeners();
    inicializarAnimaciones();
    configurarNavegacion();
    configurarFormularios();
});

function inicializarComponentes() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    configurarScrollSuave();

    window.addEventListener('scroll', manejarScroll);

    console.log('✅ Componentes inicializados');
}

function manejarScroll() {
    const navbar = document.querySelector('.navbar');
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    if (scrollTop > 100 && !isScrolled) {
        navbar.classList.add('navbar-scrolled');
        isScrolled = true;
    } else if (scrollTop <= 100 && isScrolled) {
        navbar.classList.remove('navbar-scrolled');
        isScrolled = false;
    }
}

function configurarScrollSuave() {
    const enlaces = document.querySelectorAll('a[href^="#"]');

    enlaces.forEach(enlace => {
        enlace.addEventListener('click', function (e) {
            const href = this.getAttribute('href');

            if (href !== '#') {
                e.preventDefault();
                const destino = document.querySelector(href);

                if (destino) {
                    const offsetTop = destino.offsetTop - 80;

                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

function configurarNavegacion() {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');

    if (navbarToggler && navbarCollapse) {
        const navLinks = navbarCollapse.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 992) {
                    const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
                        toggle: false
                    });
                    bsCollapse.hide();
                }
            });
        });
    }
}


function configurarFormularios() {
    const formularios = document.querySelectorAll('form');

    formularios.forEach(form => {
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', validarCampo);
            input.addEventListener('input', limpiarErrores);
        });

        form.addEventListener('submit', validarFormulario);
    });
}

function validarCampo(event) {
    const campo = event.target;
    const valor = campo.value.trim();
    const tipo = campo.type;
    const nombre = campo.name;

    let esValido = true;
    let mensaje = '';

    switch (tipo) {
        case 'email':
            if (valor && !validarEmail(valor)) {
                esValido = false;
                mensaje = 'Email no válido';
            }
            break;

        case 'tel':
            if (valor && !validarTelefono(valor)) {
                esValido = false;
                mensaje = 'Teléfono debe tener 9 dígitos';
            }
            break;

        case 'password':
            if (valor && valor.length < 6) {
                esValido = false;
                mensaje = 'Mínimo 6 caracteres';
            }
            break;
    }

    if (nombre === 'confirmar_password') {
        const password = document.querySelector('input[name="password"], input[name="password_registro"]');
        if (password && valor !== password.value) {
            esValido = false;
            mensaje = 'Las contraseñas no coinciden';
        }
    }

    if (!esValido) {
        mostrarErrorCampo(campo, mensaje);
    } else {
        quitarErrorCampo(campo);
    }

    return esValido;
}

function mostrarErrorCampo(campo, mensaje) {
    quitarErrorCampo(campo);

    campo.classList.add('is-invalid');

    const feedbackDiv = document.createElement('div');
    feedbackDiv.className = 'invalid-feedback';
    feedbackDiv.textContent = mensaje;

    campo.parentNode.appendChild(feedbackDiv);
}

function quitarErrorCampo(campo) {
    campo.classList.remove('is-invalid');
    const feedback = campo.parentNode.querySelector('.invalid-feedback');
    if (feedback) {
        feedback.remove();
    }
}

function limpiarErrores(event) {
    const campo = event.target;
    if (campo.classList.contains('is-invalid')) {
        campo.classList.remove('is-invalid');
        const feedback = campo.parentNode.querySelector('.invalid-feedback');
        if (feedback) {
            feedback.remove();
        }
    }
}

function validarFormulario(event) {
    const form = event.target;
    const campos = form.querySelectorAll('input[required], select[required], textarea[required]');
    let formularioValido = true;

    campos.forEach(campo => {
        if (!validarCampo({ target: campo })) {
            formularioValido = false;
        }

        if (!campo.value.trim()) {
            mostrarErrorCampo(campo, 'Este campo es obligatorio');
            formularioValido = false;
        }
    });

    if (!formularioValido) {
        event.preventDefault();
        mostrarAlerta('Por favor, corrige los errores en el formulario', 'warning');
    }
}

function inicializarAnimaciones() {
    observarElementos();

    window.addEventListener('scroll', efectoParallax);

    configurarHoverCards();
}

function observarElementos() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    const elementos = document.querySelectorAll('.card, .hero-section, .categoria-card, .producto-card');
    elementos.forEach(el => {
        el.classList.add('animate-ready');
        observer.observe(el);
    });
}

function efectoParallax() {
    const scrolled = window.pageYOffset;
    const parallaxElements = document.querySelectorAll('.hero-section');

    parallaxElements.forEach(element => {
        const speed = 0.5;
        element.style.transform = `translateY(${scrolled * speed}px)`;
    });
}

function configurarHoverCards() {
    const cards = document.querySelectorAll('.card');

    cards.forEach(card => {
        card.addEventListener('mouseenter', function () {
            this.style.transform = 'translateY(-8px) scale(1.02)';
        });

        card.addEventListener('mouseleave', function () {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
}


function configurarEventListeners() {
    const logo = document.querySelector('.navbar-brand');
    if (logo) {
        logo.addEventListener('click', function (e) {
            if (window.location.pathname.includes('index.php') || window.location.pathname === '/') {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    }

    configurarBotonVolverArriba();

    configurarEnlacesExternos();

    configurarBusqueda();
}

function configurarBotonVolverArriba() {
    // Crear botón si no existe
    let botonArriba = document.getElementById('volver-arriba');

    if (!botonArriba) {
        botonArriba = document.createElement('button');
        botonArriba.id = 'volver-arriba';
        botonArriba.innerHTML = '<i class="fas fa-arrow-up"></i>';
        botonArriba.className = 'btn-volver-arriba';
        botonArriba.style.cssText = `
            position: fixed;
            bottom: 100px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: var(--verde-principal);
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: none;
            z-index: 1000;
            transition: all 0.3s ease;
        `;
        document.body.appendChild(botonArriba);
    }

    // Mostrar/ocultar según scroll
    window.addEventListener('scroll', function () {
        if (window.pageYOffset > 300) {
            botonArriba.style.display = 'block';
        } else {
            botonArriba.style.display = 'none';
        }
    });

    // Funcionalidad
    botonArriba.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// Configurar enlaces externos
function configurarEnlacesExternos() {
    const enlacesExternos = document.querySelectorAll('a[href^="http"], a[href^="https"], a[href^="tel:"], a[href^="mailto:"]');

    enlacesExternos.forEach(enlace => {
        if (!enlace.hostname || enlace.hostname !== window.location.hostname) {
            enlace.setAttribute('target', '_blank');
            enlace.setAttribute('rel', 'noopener noreferrer');
        }
    });
}

// Configurar búsqueda
function configurarBusqueda() {
    const campoBusqueda = document.querySelector('input[name="busqueda"]');

    if (campoBusqueda) {
        let timeoutBusqueda;

        campoBusqueda.addEventListener('input', function () {
            clearTimeout(timeoutBusqueda);

            timeoutBusqueda = setTimeout(() => {
                const termino = this.value.trim();
                if (termino.length > 2) {
                    // Aquí se podría implementar búsqueda en vivo
                    console.log('Buscando:', termino);
                }
            }, 300);
        });
    }
}

function validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// Validar teléfono peruano
function validarTelefono(telefono) {
    const regex = /^[0-9]{9}$/;
    return regex.test(telefono);
}

// Mostrar alerta/notificación
function mostrarAlerta(mensaje, tipo = 'info', duracion = 5000) {
    // Crear contenedor de alertas si no existe
    let contenedor = document.getElementById('alertas-container');
    if (!contenedor) {
        contenedor = document.createElement('div');
        contenedor.id = 'alertas-container';
        contenedor.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
        `;
        document.body.appendChild(contenedor);
    }

    // Crear alerta
    const alerta = document.createElement('div');
    alerta.className = `alert alert-${tipo} alert-dismissible fade show`;
    alerta.innerHTML = `
        <i class="fas fa-${tipo === 'success' ? 'check-circle' : tipo === 'warning' ? 'exclamation-triangle' : tipo === 'danger' ? 'times-circle' : 'info-circle'} me-2"></i>
        ${mensaje}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    contenedor.appendChild(alerta);

    // Auto-ocultar
    setTimeout(() => {
        if (alerta.parentNode) {
            const bsAlert = new bootstrap.Alert(alerta);
            bsAlert.close();
        }
    }, duracion);
}

// Formatear número como moneda peruana
function formatearMoneda(cantidad) {
    return new Intl.NumberFormat('es-PE', {
        style: 'currency',
        currency: 'PEN',
        minimumFractionDigits: 2
    }).format(cantidad);
}

// Debounce para optimizar eventos
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle para optimizar scroll
function throttle(func, limit) {
    let inThrottle;
    return function () {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

function animarContador(elemento, valorFinal, duracion = 2000) {
    const valorInicial = 0;
    const incremento = valorFinal / (duracion / 16);
    let valorActual = valorInicial;

    const timer = setInterval(() => {
        valorActual += incremento;
        elemento.textContent = Math.floor(valorActual);

        if (valorActual >= valorFinal) {
            elemento.textContent = valorFinal;
            clearInterval(timer);
        }
    }, 16);
}

function copiarAlPortapapeles(texto) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(texto).then(() => {
            mostrarAlerta('Texto copiado al portapapeles', 'success', 2000);
        });
    } else {
        const textArea = document.createElement('textarea');
        textArea.value = texto;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        mostrarAlerta('Texto copiado al portapapeles', 'success', 2000);
    }
}

function configurarLazyLoading() {
    const imagenes = document.querySelectorAll('img[data-src]');

    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    imagenes.forEach(img => imageObserver.observe(img));
}

window.addEventListener('error', function (e) {
    console.error('Error JavaScript:', e.error);
});

window.addEventListener('unhandledrejection', function (e) {
    console.error('Promesa rechazada:', e.reason);
});

window.mostrarAlerta = mostrarAlerta;
window.formatearMoneda = formatearMoneda;
window.validarEmail = validarEmail;
window.validarTelefono = validarTelefono;
window.copiarAlPortapapeles = copiarAlPortapapeles;

console.log('🚀 Main.js cargado correctamente');