let chatbotData = {};
let chatbotActivo = false;
let conversacionActual = [];
let categoriaActual = null;
let chatbotInicializado = false;

function inicializarChatbot() {
    if (chatbotInicializado) {
        console.log('🤖 Chatbot ya inicializado');
        return;
    }

    console.log('🤖 Inicializando chatbot...');

    cargarDatosChatbot()
        .then(() => {
            configurarEventosChatbot();
            prepararMensajeBienvenida();
            chatbotInicializado = true;
            console.log('✅ Chatbot inicializado correctamente');
        })
        .catch(error => {
            console.error('❌ Error al inicializar chatbot:', error);
            inicializarChatbotFallback();
        });
}

function inicializarChatbotFallback() {
    console.log('🔄 Inicializando chatbot con datos básicos...');

    chatbotData = {
        saludo: {
            mensaje: "¡Hola! 👋 Soy el asistente virtual de FarmaPlus. ¿En qué puedo ayudarte?",
            opciones: ["informacion_general", "productos_servicios", "contacto_ubicacion"]
        },
        despedida: {
            mensaje: "¡Gracias por contactarnos! 😊 ¿Hay algo más en lo que pueda ayudarte?"
        }
    };

    configurarEventosChatbot();
    prepararMensajeBienvenida();
    chatbotInicializado = true;
    console.log('✅ Chatbot inicializado con datos básicos');
}

async function cargarDatosChatbot() {
    try {
        const response = await fetch('data/chatbot-data.json');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        chatbotData = await response.json();
        console.log('📋 Datos del chatbot cargados:', Object.keys(chatbotData));
    } catch (error) {
        console.warn('⚠️ No se pudo cargar chatbot-data.json:', error);
        throw error;
    }
}

function toggleChatbot() {
    console.log('🔄 Toggle chatbot, estado actual:', chatbotActivo);

    if (window.chatbotToggling) {
        console.log('⏳ Toggle en progreso, ignorando...');
        return;
    }

    window.chatbotToggling = true;

    try {
        if (chatbotActivo) {
            cerrarChatbot();
        } else {
            abrirChatbot();
        }
    } finally {
        setTimeout(() => {
            window.chatbotToggling = false;
        }, 300);
    }
}

function abrirChatbot() {
    console.log('📂 Abriendo chatbot...');

    const container = document.getElementById('chatbot-container');
    const button = document.getElementById('chatbot-button');

    if (!container || !button) {
        console.error('❌ Elementos del chatbot no encontrados');
        return;
    }

    if (chatbotActivo) {
        console.log('ℹ️ Chatbot ya está abierto');
        return;
    }

    chatbotActivo = true;

    container.style.display = 'block';
    container.classList.add('chatbot-abierto');
    button.classList.add('activo');

    setTimeout(() => {
        container.style.transform = 'translateY(0)';
        container.style.opacity = '1';
    }, 10);

    const mensajes = document.getElementById('chatbot-messages');
    if (mensajes && mensajes.children.length === 0) {
        mostrarMensajeBienvenida();
    }

    setTimeout(() => {
        if (mensajes) {
            mensajes.scrollTop = mensajes.scrollHeight;
        }
    }, 100);

    console.log('✅ Chatbot abierto correctamente');
}

function cerrarChatbot() {
    console.log('📁 Cerrando chatbot...');

    const container = document.getElementById('chatbot-container');
    const button = document.getElementById('chatbot-button');

    if (!container || !button) {
        console.error('❌ Elementos del chatbot no encontrados');
        return;
    }

    if (!chatbotActivo) {
        console.log('ℹ️ Chatbot ya está cerrado');
        return;
    }

    chatbotActivo = false;

    container.style.transform = 'translateY(100%)';
    container.style.opacity = '0';
    button.classList.remove('activo');

    setTimeout(() => {
        if (!chatbotActivo) {
            container.style.display = 'none';
            container.classList.remove('chatbot-abierto');
        }
    }, 300);

    console.log('✅ Chatbot cerrado correctamente');
}


function prepararMensajeBienvenida() {
    console.log('📋 Mensaje de bienvenida preparado');
}

function mostrarMensajeBienvenida() {
    if (chatbotData.saludo) {
        agregarMensajeChatbot(chatbotData.saludo.mensaje);
        mostrarOpcionesPrincipales();
    } else {
        agregarMensajeChatbot("¡Hola! 👋 Soy el asistente virtual de FarmaPlus. ¿En qué puedo ayudarte?");
        mostrarOpcionesBasicas();
    }
}

function agregarMensajeChatbot(mensaje, opciones = null) {
    const contenedor = document.getElementById('chatbot-messages');
    if (!contenedor) {
        console.error('❌ Contenedor de mensajes no encontrado');
        return;
    }

    const mensajeDiv = document.createElement('div');
    mensajeDiv.className = 'chatbot-mensaje chatbot-respuesta';

    const tiempoActual = new Date().toLocaleTimeString('es-PE', {
        hour: '2-digit',
        minute: '2-digit'
    });

    mensajeDiv.innerHTML = `
        <div class="mensaje-contenido">
            <div class="mensaje-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="mensaje-texto">
                <p>${mensaje}</p>
                <small class="mensaje-hora">${tiempoActual}</small>
            </div>
        </div>
    `;

    contenedor.appendChild(mensajeDiv);

    setTimeout(() => {
        mensajeDiv.classList.add('mensaje-visible');
    }, 100);

    if (opciones) {
        setTimeout(() => {
            mostrarOpciones(opciones);
        }, 500);
    }

    scrollAlFinal();

    conversacionActual.push({
        tipo: 'bot',
        mensaje: mensaje,
        timestamp: new Date()
    });
}

function agregarMensajeUsuario(mensaje) {
    const contenedor = document.getElementById('chatbot-messages');
    if (!contenedor) return;

    const tiempoActual = new Date().toLocaleTimeString('es-PE', {
        hour: '2-digit',
        minute: '2-digit'
    });

    const mensajeDiv = document.createElement('div');
    mensajeDiv.className = 'chatbot-mensaje usuario-mensaje';

    mensajeDiv.innerHTML = `
        <div class="mensaje-contenido">
            <div class="mensaje-texto">
                <p>${mensaje}</p>
                <small class="mensaje-hora">${tiempoActual}</small>
            </div>
            <div class="mensaje-avatar">
                <i class="fas fa-user"></i>
            </div>
        </div>
    `;

    contenedor.appendChild(mensajeDiv);

    setTimeout(() => {
        mensajeDiv.classList.add('mensaje-visible');
    }, 100);

    scrollAlFinal();

    conversacionActual.push({
        tipo: 'usuario',
        mensaje: mensaje,
        timestamp: new Date()
    });
}

function mostrarOpcionesPrincipales() {
    const opciones = [];

    if (chatbotData.categorias) {
        Object.keys(chatbotData.categorias).forEach(key => {
            opciones.push({
                id: key,
                texto: chatbotData.categorias[key].titulo,
                accion: () => mostrarCategoria(key)
            });
        });
    }

    opciones.push({
        id: 'humano',
        texto: '👨‍💼 Hablar con un humano',
        accion: () => derivarAHumano()
    });

    mostrarOpciones(opciones);
}

function mostrarOpcionesBasicas() {
    const opciones = [
        {
            id: 'info',
            texto: '📋 Información General',
            accion: () => responderBasico('info')
        },
        {
            id: 'productos',
            texto: '💊 Productos',
            accion: () => responderBasico('productos')
        },
        {
            id: 'contacto',
            texto: '📞 Contacto',
            accion: () => responderBasico('contacto')
        },
        {
            id: 'humano',
            texto: '👨‍💼 Hablar con un humano',
            accion: () => derivarAHumano()
        }
    ];

    mostrarOpciones(opciones);
}

function mostrarOpciones(opciones) {
    const contenedor = document.getElementById('chatbot-messages');
    if (!contenedor || !opciones) return;

    const opcionesDiv = document.createElement('div');
    opcionesDiv.className = 'chatbot-opciones';

    opciones.forEach(opcion => {
        const boton = document.createElement('button');
        boton.className = 'opcion-boton btn btn-outline-success btn-sm m-1';
        boton.textContent = opcion.texto;
        boton.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();

            removerOpciones();

            agregarMensajeUsuario(opcion.texto);

            setTimeout(() => {
                if (typeof opcion.accion === 'function') {
                    opcion.accion();
                }
            }, 500);
        };

        opcionesDiv.appendChild(boton);
    });

    contenedor.appendChild(opcionesDiv);

    setTimeout(() => {
        opcionesDiv.classList.add('opciones-visibles');
    }, 200);

    scrollAlFinal();
}

function removerOpciones() {
    const opciones = document.querySelectorAll('.chatbot-opciones');
    opciones.forEach(opcion => {
        opcion.style.opacity = '0';
        setTimeout(() => {
            if (opcion.parentNode) {
                opcion.parentNode.removeChild(opcion);
            }
        }, 300);
    });
}

function responderBasico(tipo) {
    const respuestas = {
        info: "🏥 FarmaPlus está abierto de Lunes a Viernes de 7:00 AM a 11:00 PM. Nos encontramos en Av. Conquistadores 123, San Isidro.",
        productos: "💊 Contamos con medicamentos, productos de belleza, cuidado personal, vitaminas y más. ¿Buscas algo específico?",
        contacto: "📞 Puedes contactarnos al +51 999 888 777 o escribirnos por WhatsApp. También puedes visitarnos en San Isidro."
    };

    const mensaje = respuestas[tipo] || "Gracias por tu consulta. ¿Hay algo más en lo que pueda ayudarte?";
    agregarMensajeChatbot(mensaje);

    setTimeout(() => {
        mostrarOpcionesDespuesRespuesta();
    }, 2000);
}

function mostrarCategoria(categoriaId) {
    const categoria = chatbotData.categorias && chatbotData.categorias[categoriaId];
    if (!categoria) {
        responderBasico('general');
        return;
    }

    categoriaActual = categoriaId;

    agregarMensajeChatbot(`Perfecto, te ayudo con ${categoria.titulo.toLowerCase()}`);

    setTimeout(() => {
        const preguntas = categoria.preguntas;
        const opciones = Object.keys(preguntas).map(key => ({
            id: key,
            texto: preguntas[key].pregunta,
            accion: () => responderPregunta(categoriaId, key)
        }));

        opciones.push({
            id: 'volver',
            texto: '🔙 Volver al menú principal',
            accion: () => volverAlMenu()
        });

        agregarMensajeChatbot('¿Qué te gustaría saber?');
        mostrarOpciones(opciones);
    }, 1000);
}

function responderPregunta(categoriaId, preguntaId) {
    const categoria = chatbotData.categorias && chatbotData.categorias[categoriaId];
    const pregunta = categoria && categoria.preguntas && categoria.preguntas[preguntaId];

    if (!pregunta) {
        responderBasico('general');
        return;
    }

    agregarMensajeChatbot(pregunta.respuesta);

    setTimeout(() => {
        mostrarOpcionesDespuesRespuesta();
    }, 2000);
}

function mostrarOpcionesDespuesRespuesta() {
    const opciones = [
        {
            id: 'otra_pregunta',
            texto: '❓ Hacer otra pregunta',
            accion: () => {
                if (categoriaActual) {
                    mostrarCategoria(categoriaActual);
                } else {
                    volverAlMenu();
                }
            }
        },
        {
            id: 'menu_principal',
            texto: '🏠 Menú principal',
            accion: () => volverAlMenu()
        },
        {
            id: 'finalizar',
            texto: '👋 Finalizar conversación',
            accion: () => finalizarConversacion()
        }
    ];

    agregarMensajeChatbot('¿Te puedo ayudar en algo más?');
    mostrarOpciones(opciones);
}

// Volver al menú principal
function volverAlMenu() {
    categoriaActual = null;
    agregarMensajeChatbot('¿En qué más puedo ayudarte?');
    mostrarOpcionesPrincipales();
}

// Derivar a humano
function derivarAHumano() {
    const whatsapp = '+51999888777';

    agregarMensajeChatbot(`
        Perfecto, te conectaré con nuestro equipo humano. 👨‍💼
        
        Puedes contactarnos por:
        📱 WhatsApp: ${whatsapp}
        📞 Teléfono: +51 999 888 777
        📧 Email: contacto@farmaplus.pe
        
        ¡Estaremos encantados de atenderte!
    `);

    setTimeout(() => {
        const opciones = [
            {
                id: 'whatsapp',
                texto: '💬 Abrir WhatsApp',
                accion: () => {
                    const numeroLimpio = whatsapp.replace(/[^0-9]/g, '');
                    window.open(`https://wa.me/${numeroLimpio}?text=Hola, vengo del chatbot de FarmaPlus`, '_blank');
                    finalizarConversacion();
                }
            },
            {
                id: 'continuar',
                texto: '🤖 Continuar con el chatbot',
                accion: () => volverAlMenu()
            }
        ];

        mostrarOpciones(opciones);
    }, 1500);
}

function finalizarConversacion() {
    const mensajeDespedida = chatbotData.despedida?.mensaje ||
        "¡Gracias por usar nuestro chatbot! 😊 Que tengas un excelente día.";

    agregarMensajeChatbot(mensajeDespedida);

    setTimeout(() => {
        const opciones = [
            {
                id: 'nueva_consulta',
                texto: '🔄 Nueva consulta',
                accion: () => {
                    limpiarChat();
                    mostrarMensajeBienvenida();
                }
            },
            {
                id: 'cerrar',
                texto: '❌ Cerrar chat',
                accion: () => cerrarChatbot()
            }
        ];

        mostrarOpciones(opciones);
    }, 1000);
}

function scrollAlFinal() {
    const contenedor = document.getElementById('chatbot-messages');
    if (contenedor) {
        setTimeout(() => {
            contenedor.scrollTop = contenedor.scrollHeight;
        }, 100);
    }
}

// Limpiar chat
function limpiarChat() {
    const contenedor = document.getElementById('chatbot-messages');
    if (contenedor) {
        contenedor.innerHTML = '';
    }
    conversacionActual = [];
    categoriaActual = null;
}

function configurarEventosChatbot() {
    console.log('🔧 Configurando eventos del chatbot...');

    const botonChatbot = document.getElementById('chatbot-button');
    if (botonChatbot) {
        botonChatbot.replaceWith(botonChatbot.cloneNode(true));
        const nuevoBoton = document.getElementById('chatbot-button');

        nuevoBoton.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('🖱️ Click en botón chatbot');
            toggleChatbot();
        });

        console.log('✅ Evento click configurado en botón chatbot');
    } else {
        console.warn('⚠️ Botón chatbot no encontrado');
    }

    const botonCerrar = document.querySelector('.btn-close-chat');
    if (botonCerrar) {
        botonCerrar.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            cerrarChatbot();
        });
        console.log('✅ Evento cerrar configurado');
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && chatbotActivo) {
            cerrarChatbot();
        }
    });

    const container = document.getElementById('chatbot-container');
    if (container) {
        container.addEventListener('click', function (e) {
            e.stopPropagation();
        });
        console.log('✅ Prevención de propagación configurada');
    }

    console.log('✅ Eventos del chatbot configurados correctamente');
}

window.toggleChatbot = toggleChatbot;
window.inicializarChatbot = inicializarChatbot;
window.cerrarChatbot = cerrarChatbot;
window.abrirChatbot = abrirChatbot;


document.addEventListener('DOMContentLoaded', function () {
    console.log('📄 DOM cargado, preparando chatbot...');

    setTimeout(() => {
        inicializarChatbot();
    }, 1000);
});

console.log('🤖 Chatbot.js cargado correctamente');