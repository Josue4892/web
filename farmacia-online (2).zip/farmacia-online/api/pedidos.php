<?php
ini_set('display_errors', 0);
error_reporting(0);

header('Content-Type: application/json');

ob_start();

try {
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../includes/functions.php';

    // Iniciar sesión si no está iniciada
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Solo manejar POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Solo se permite POST');
    }

    // Leer datos JSON
    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input) {
        throw new Exception('No se recibieron datos JSON válidos');
    }

    // Verificar login
    if (!estaLogueado()) {
        throw new Exception('Debes iniciar sesión');
    }

    $usuario = obtenerUsuarioActual();

    // Validar datos básicos
    if (empty($input['productos'])) {
        throw new Exception('No hay productos en el carrito');
    }

    if (empty($input['telefono'])) {
        throw new Exception('El teléfono es obligatorio');
    }

    if (empty($input['direccion'])) {
        throw new Exception('La dirección es obligatoria');
    }

    if (empty($input['total']) || $input['total'] <= 0) {
        throw new Exception('Total inválido');
    }

    // Conectar a BD usando PDO directamente
    $db = new Database();
    $conn = $db->getConnection();

    if (!$conn) {
        throw new Exception('Error de conexión a BD');
    }

    // Configurar zona horaria de Perú
    date_default_timezone_set('America/Lima');

    // Insertar pedido usando PDO directamente
    $fecha = date('Y-m-d H:i:s');

    try {
        $query = "INSERT INTO pedidos (usuario_id, total, estado, fecha_pedido) VALUES (?, ?, 'pendiente', ?)";

        $stmt = $conn->prepare($query);
        $stmt->execute([
            $usuario['id'],
            (float) $input['total'],
            $fecha
        ]);

        $pedido_id = $conn->lastInsertId();
        error_log("Pedido insertado con ID: " . $pedido_id);

    } catch (PDOException $e) {
        error_log("Error PDO: " . $e->getMessage());
        throw new Exception('Error en base de datos: ' . $e->getMessage());
    }

    // Insertar productos usando PDO directamente Y actualizar stock
    foreach ($input['productos'] as $item) {
        try {
            // 1. Verificar stock disponible antes de insertar
            $query_stock = "SELECT stock FROM productos WHERE id = ?";
            $stmt_stock = $conn->prepare($query_stock);
            $stmt_stock->execute([$item['id']]);
            $producto_actual = $stmt_stock->fetch(PDO::FETCH_ASSOC);

            if (!$producto_actual) {
                error_log("Producto no encontrado: " . $item['id']);
                continue;
            }

            $stock_actual = (int) $producto_actual['stock'];
            $cantidad_pedida = (int) $item['cantidad'];

            if ($stock_actual < $cantidad_pedida) {
                error_log("Stock insuficiente para producto " . $item['id'] . ": Stock: $stock_actual, Pedido: $cantidad_pedida");
                continue;
            }

            // 2. Insertar detalle del pedido
            $query_detalle = "INSERT INTO detalle_pedidos (pedido_id, producto_id, cantidad, precio_unitario) 
                             VALUES (?, ?, ?, ?)";

            $stmt_detalle = $conn->prepare($query_detalle);
            $stmt_detalle->execute([
                $pedido_id,
                $item['id'],
                $cantidad_pedida,
                $item['precio']
            ]);

            // 3. Actualizar stock del producto (DESCONTAR)
            $nuevo_stock = $stock_actual - $cantidad_pedida;
            $query_update_stock = "UPDATE productos SET stock = ? WHERE id = ?";
            $stmt_update = $conn->prepare($query_update_stock);
            $stmt_update->execute([$nuevo_stock, $item['id']]);

            error_log("Producto " . $item['id'] . " - Stock actualizado: $stock_actual -> $nuevo_stock");

        } catch (PDOException $e) {
            error_log("Error procesando producto " . $item['id'] . ": " . $e->getMessage());
        }
    }

    $whatsapp_url = generarWhatsAppURL($pedido_id, $input);

    // Contar productos procesados exitosamente
    $productos_procesados = 0;
    foreach ($input['productos'] as $item) {
        $query_check = "SELECT COUNT(*) as existe FROM detalle_pedidos WHERE pedido_id = ? AND producto_id = ?";
        $stmt_check = $conn->prepare($query_check);
        $stmt_check->execute([$pedido_id, $item['id']]);
        $existe = $stmt_check->fetch(PDO::FETCH_ASSOC);
        if ($existe['existe'] > 0) {
            $productos_procesados++;
        }
    }

    ob_end_clean();

    // Respuesta exitosa con información de stock
    echo json_encode([
        'success' => true,
        'message' => 'Pedido creado exitosamente',
        'data' => [
            'pedido_id' => $pedido_id,
            'whatsapp_url' => $whatsapp_url,
            'productos_procesados' => $productos_procesados,
            'total_productos' => count($input['productos']),
            'stock_actualizado' => true
        ]
    ]);

} catch (Exception $e) {
    ob_end_clean();

    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'data' => null
    ]);
}

function generarWhatsAppURL($pedido_id, $datos)
{
    $telefono = '51999888777';

    $mensaje = "🏥 *Nuevo Pedido FarmaPlus*\n\n";
    $mensaje .= "📋 Pedido #" . str_pad($pedido_id, 6, '0', STR_PAD_LEFT) . "\n";
    $mensaje .= "📞 " . $datos['telefono'] . "\n";
    $mensaje .= "📍 " . $datos['direccion'] . "\n";
    $mensaje .= "💰 Total: S/ " . number_format($datos['total'], 2) . "\n\n";
    $mensaje .= "🛒 Productos:\n";

    foreach ($datos['productos'] as $item) {
        $mensaje .= "• " . $item['nombre'] . " x" . $item['cantidad'] . "\n";
    }

    $mensaje .= "\n¡Gracias por tu compra! 🙏";

    return "https://wa.me/{$telefono}?text=" . urlencode($mensaje);
}
?>