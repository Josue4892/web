<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

$response = [
    'success' => false,
    'message' => '',
    'data' => null
];

try {
    switch ($method) {
        case 'GET':
            $categorias = obtenerCategorias();
            $response['success'] = true;
            $response['data'] = $categorias;
            $response['message'] = count($categorias) . ' categorías encontradas';
            break;

        case 'POST':
            if (esAdmin()) {
                $nombre = sanitizar($input['nombre']);
                $descripcion = sanitizar($input['descripcion'] ?? '');

                $db = new Database();
                $query = "INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)";
                if ($db->execute($query, [$nombre, $descripcion])) {
                    $response['success'] = true;
                    $response['message'] = 'Categoría creada exitosamente';
                } else {
                    throw new Exception('Error al crear categoría');
                }
            } else {
                throw new Exception('Sin permisos');
            }
            break;
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    http_response_code(400);
}

echo json_encode($response);
?>