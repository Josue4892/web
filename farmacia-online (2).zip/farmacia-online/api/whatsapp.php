<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

$response = [
    'success' => false,
    'message' => '',
    'data' => null
];

try {
    if ($method !== 'POST') {
        throw new Exception('Solo se permite método POST');
    }
    
    $accion = $input['accion'] ?? null;
    
    switch ($accion) {
        case 'enviar_boleta':
            handleEnviarBoleta();
            break;
            
        case 'enviar_consulta':
            handleEnviarConsulta();
            break;
            
        case 'generar_pdf':
            handleGenerarPDF();
            break;
            
        default:
            throw new Exception('Acción no válida');
    }
    
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    http_response_code(400);
}

echo json_encode($response);

function handleEnviarBoleta() {
    global $response, $input;
    
    // Validar datos requeridos
    $campos_requeridos = ['telefono', 'pedido_id', 'productos', 'total'];
    foreach ($campos_requeridos as $campo) {
        if (!isset($input[$campo]) || empty($input[$campo])) {
            throw new Exception("El campo '$campo' es requerido");
        }
    }
    
    $telefono = sanitizar($input['telefono']);
    $pedido_id = (int)$input['pedido_id'];
    $productos = $input['productos'];
    $total = (float)$input['total'];
    $nombre_cliente = sanitizar($input['nombre_cliente'] ?? 'Cliente');
    
    // Validar teléfono
    if (!validarTelefono($telefono)) {
        throw new Exception('Número de teléfono no válido');
    }
    
    try {
        // Generar PDF de la boleta
        $pdf_path = generarBoletaPDF($pedido_id, $productos, $total, $nombre_cliente);
        
        // Crear URL de WhatsApp
        $config = cargarConfiguracion();
        $mensaje_boleta = $config['whatsapp']['mensaje_boleta'] ?? '¡Gracias por tu compra! Aquí tienes tu boleta:';
        
        $mensaje_completo = "🏥 *{$config['farmacia']['nombre']}*\n\n";
        $mensaje_completo .= "$mensaje_boleta\n\n";
        $mensaje_completo .= "📋 *Pedido #$pedido_id*\n";
        $mensaje_completo .= "👤 Cliente: $nombre_cliente\n";
        $mensaje_completo .= "📅 Fecha: " . date('d/m/Y H:i') . "\n\n";
        
        $mensaje_completo .= "🛒 *Productos:*\n";
        foreach ($productos as $producto) {
            $subtotal = $producto['precio'] * $producto['cantidad'];
            $mensaje_completo .= "• {$producto['cantidad']}x {$producto['nombre']}\n";
            $mensaje_completo .= "  " . formatearPrecio($producto['precio']) . " c/u = " . formatearPrecio($subtotal) . "\n\n";
        }
        
        $mensaje_completo .= "💰 *Total: " . formatearPrecio($total) . "*\n\n";
        $mensaje_completo .= "📱 Para consultas: {$config['farmacia']['telefono']}\n";
        $mensaje_completo .= "🌐 {$config['farmacia']['email']}";
        
        $whatsapp_url = generarURLWhatsApp($telefono, $mensaje_completo);
        
        $response['success'] = true;
        $response['data'] = [
            'whatsapp_url' => $whatsapp_url,
            'pdf_path' => $pdf_path,
            'mensaje' => $mensaje_completo,
            'pedido_id' => $pedido_id
        ];
        $response['message'] = 'Boleta preparada para envío por WhatsApp';
        
        error_log("Boleta generada para WhatsApp: Pedido $pedido_id, Teléfono $telefono");
        
    } catch (Exception $e) {
        throw new Exception('Error al preparar boleta: ' . $e->getMessage());
    }
}

function handleEnviarConsulta() {
    global $response, $input;
    
    $telefono = sanitizar($input['telefono'] ?? '');
    $mensaje = sanitizar($input['mensaje'] ?? '');
    $tipo_consulta = sanitizar($input['tipo'] ?? 'general');
    
    if (empty($telefono)) {
        throw new Exception('Número de teléfono es requerido');
    }
    
    if (!validarTelefono($telefono)) {
        throw new Exception('Número de teléfono no válido');
    }
    
    $config = cargarConfiguracion();
    
    $mensajes_predefinidos = [
        'general' => "🏥 Hola, me gustaría hacer una consulta sobre FarmaPlus.",
        'producto' => "💊 Hola, tengo una consulta sobre un producto específico.",
        'pedido' => "📋 Hola, necesito ayuda con mi pedido.",
        'stock' => "📦 Hola, quisiera consultar sobre stock de productos.",
        'farmaceutico' => "👨‍⚕️ Hola, necesito hablar con el farmacéutico.",
        'personalizado' => $mensaje
    ];
    
    $mensaje_final = $mensajes_predefinidos[$tipo_consulta] ?? $mensajes_predefinidos['general'];
    
    if (!empty($mensaje) && $tipo_consulta !== 'personalizado') {
        $mensaje_final .= "\n\nDetalles: $mensaje";
    }
    
    $whatsapp_url = generarURLWhatsApp($telefono, $mensaje_final, true);
    
    $response['success'] = true;
    $response['data'] = [
        'whatsapp_url' => $whatsapp_url,
        'mensaje' => $mensaje_final,
        'numero_farmacia' => $config['farmacia']['whatsapp']
    ];
    $response['message'] = 'URL de WhatsApp generada para consulta';
}

function handleGenerarPDF() {
    global $response, $input;
    
    // Verificar que el usuario esté logueado
    if (!estaLogueado()) {
        throw new Exception('Debes iniciar sesión para generar PDFs');
    }
    
    $pedido_id = (int)($input['pedido_id'] ?? 0);
    $productos = $input['productos'] ?? [];
    $total = (float)($input['total'] ?? 0);
    
    if (empty($productos)) {
        throw new Exception('No hay productos para generar la boleta');
    }
    
    try {
        $usuario = obtenerUsuarioActual();
        $pdf_path = generarBoletaPDF($pedido_id, $productos, $total, $usuario['nombre']);
        
        $response['success'] = true;
        $response['data'] = [
            'pdf_path' => $pdf_path,
            'download_url' => "download_pdf.php?file=" . basename($pdf_path),
            'pedido_id' => $pedido_id
        ];
        $response['message'] = 'PDF generado exitosamente';
        
    } catch (Exception $e) {
        throw new Exception('Error al generar PDF: ' . $e->getMessage());
    }
}

function generarURLWhatsApp($telefono, $mensaje, $a_farmacia = false) {
    $config = cargarConfiguracion();
    
    $numero_destino = $a_farmacia ? 
        str_replace(['+', ' ', '-'], '', $config['farmacia']['whatsapp']) : 
        $telefono;
    
    $numero_limpio = preg_replace('/[^0-9]/', '', $numero_destino);
    
    if (strlen($numero_limpio) == 9) {
        $numero_limpio = '51' . $numero_limpio;
    }
    
    $mensaje_codificado = urlencode($mensaje);
    
    return "https://api.whatsapp.com/send?phone={$numero_limpio}&text={$mensaje_codificado}";
}

function generarBoletaPDF($pedido_id, $productos, $total, $nombre_cliente) {
    $config = cargarConfiguracion();
    $fecha_actual = date('d/m/Y H:i');
    
    $html_content = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; margin-bottom: 30px; }
            .info { margin-bottom: 20px; }
            .productos { width: 100%; border-collapse: collapse; }
            .productos th, .productos td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            .productos th { background-color: #28a745; color: white; }
            .total { text-align: right; margin-top: 20px; font-size: 18px; font-weight: bold; }
            .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class='header'>
            <h1>{$config['farmacia']['nombre']}</h1>
            <p>{$config['farmacia']['slogan']}</p>
            <p>{$config['farmacia']['direccion']}</p>
            <p>Tel: {$config['farmacia']['telefono']} | Email: {$config['farmacia']['email']}</p>
        </div>
        
        <div class='info'>
            <h2>BOLETA DE VENTA</h2>
            <p><strong>Pedido #:</strong> $pedido_id</p>
            <p><strong>Cliente:</strong> $nombre_cliente</p>
            <p><strong>Fecha:</strong> $fecha_actual</p>
        </div>
        
        <table class='productos'>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio Unit.</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>";
    
    foreach ($productos as $producto) {
        $subtotal = $producto['precio'] * $producto['cantidad'];
        $html_content .= "
                <tr>
                    <td>{$producto['nombre']}</td>
                    <td>{$producto['cantidad']}</td>
                    <td>" . formatearPrecio($producto['precio']) . "</td>
                    <td>" . formatearPrecio($subtotal) . "</td>
                </tr>";
    }
    
    $html_content .= "
            </tbody>
        </table>
        
        <div class='total'>
            TOTAL: " . formatearPrecio($total) . "
        </div>
        
        <div class='footer'>
            <p>Gracias por su compra</p>
            <p>Esta boleta fue generada automáticamente</p>
        </div>
    </body>
    </html>";
    
    // Crear directorio si no existe
    $pdf_dir = '../temp/pdfs/';
    if (!is_dir($pdf_dir)) {
        mkdir($pdf_dir, 0755, true);
    }
    
    // Generar nombre único para el archivo
    $filename = "boleta_pedido_{$pedido_id}_" . date('YmdHis') . ".html";
    $filepath = $pdf_dir . $filename;
    
    // Guardar archivo HTML (en un proyecto real convertirías a PDF)
    file_put_contents($filepath, $html_content);
    
    return $filepath;
}

function validarNumeroWhatsApp($numero) {
    // Validar formato de número internacional
    $numero_limpio = preg_replace('/[^0-9]/', '', $numero);
    
    // Debe tener al menos 10 dígitos (código país + número)
    return strlen($numero_limpio) >= 10 && strlen($numero_limpio) <= 15;
}
?>