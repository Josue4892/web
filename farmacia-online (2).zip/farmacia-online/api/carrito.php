<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

// Inicializar respuesta
$response = [
    'success' => false,
    'message' => '',
    'data' => null
];

try {
    if (!estaLogueado()) {
        throw new Exception('Debes iniciar sesión para usar el carrito');
    }

    switch ($method) {
        case 'GET':
            handleGetCarrito();
            break;

        case 'POST':
            handleAgregarCarrito();
            break;

        case 'PUT':
            handleActualizarCarrito();
            break;

        case 'DELETE':
            handleEliminarCarrito();
            break;

        default:
            throw new Exception('Método no permitido');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    http_response_code(400);
}

echo json_encode($response);

function handleGetCarrito()
{
    global $response;

    $response['success'] = true;
    $response['message'] = 'Carrito obtenido desde localStorage';
    $response['data'] = [
        'mensaje' => 'El carrito se maneja desde el frontend con localStorage',
        'usuario_id' => obtenerUsuarioActual()['id']
    ];
}

function handleAgregarCarrito()
{
    global $response, $input;

    // Validar datos requeridos
    if (!isset($input['producto_id']) || !isset($input['cantidad'])) {
        throw new Exception('Producto ID y cantidad son requeridos');
    }

    $producto_id = (int) $input['producto_id'];
    $cantidad = (int) $input['cantidad'];

    if ($cantidad <= 0) {
        throw new Exception('La cantidad debe ser mayor a 0');
    }

    // Verificar que el producto existe
    $producto = obtenerProductoPorId($producto_id);
    if (!$producto) {
        throw new Exception('Producto no encontrado');
    }

    // Verificar stock disponible
    if ($producto['stock'] < $cantidad) {
        throw new Exception("Solo hay {$producto['stock']} unidades disponibles");
    }

    $response['success'] = true;
    $response['data'] = [
        'producto' => $producto,
        'cantidad_agregada' => $cantidad,
        'precio_total' => $producto['precio'] * $cantidad
    ];
    $response['message'] = 'Producto agregado al carrito';

    // Log de actividad
    $usuario = obtenerUsuarioActual();
    error_log("Producto agregado al carrito: Usuario {$usuario['id']}, Producto {$producto_id}, Cantidad {$cantidad}");
}

function handleActualizarCarrito()
{
    global $response, $input;

    if (!isset($input['producto_id']) || !isset($input['cantidad'])) {
        throw new Exception('Producto ID y cantidad son requeridos');
    }

    $producto_id = (int) $input['producto_id'];
    $cantidad = (int) $input['cantidad'];

    if ($cantidad < 0) {
        throw new Exception('La cantidad no puede ser negativa');
    }

    // Verificar que el producto existe
    $producto = obtenerProductoPorId($producto_id);
    if (!$producto) {
        throw new Exception('Producto no encontrado');
    }

    // Si cantidad es 0, es equivalente a eliminar
    if ($cantidad == 0) {
        $response['success'] = true;
        $response['message'] = 'Producto eliminado del carrito';
        $response['data'] = ['producto_id' => $producto_id, 'accion' => 'eliminado'];
        return;
    }

    // Verificar stock disponible
    if ($producto['stock'] < $cantidad) {
        throw new Exception("Solo hay {$producto['stock']} unidades disponibles");
    }

    $response['success'] = true;
    $response['data'] = [
        'producto_id' => $producto_id,
        'nueva_cantidad' => $cantidad,
        'precio_total' => $producto['precio'] * $cantidad
    ];
    $response['message'] = 'Carrito actualizado';
}

function handleEliminarCarrito()
{
    global $response;

    $producto_id = isset($_GET['producto_id']) ? (int) $_GET['producto_id'] : null;
    $accion = isset($_GET['accion']) ? $_GET['accion'] : null;

    if ($accion === 'vaciar') {
        // Vaciar todo el carrito
        $response['success'] = true;
        $response['message'] = 'Carrito vaciado';
        $response['data'] = ['accion' => 'vaciar_todo'];
    } elseif ($producto_id) {
        // Eliminar producto específico
        $response['success'] = true;
        $response['message'] = 'Producto eliminado del carrito';
        $response['data'] = ['producto_id' => $producto_id, 'accion' => 'eliminar_producto'];
    } else {
        throw new Exception('Acción no válida');
    }
}
?>