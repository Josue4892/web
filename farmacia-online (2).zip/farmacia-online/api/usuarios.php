<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

$response = [
    'success' => false,
    'message' => '',
    'data' => null
];

try {
    switch ($method) {
        case 'GET':
            handleGetUsuarios();
            break;

        case 'POST':
            handleCreateUsuario();
            break;

        case 'PUT':
            handleUpdateUsuario();
            break;

        case 'DELETE':
            handleDeleteUsuario();
            break;

        default:
            throw new Exception('Método no permitido');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    http_response_code(400);
}

echo json_encode($response);

function handleGetUsuarios()
{
    global $response;

    // Solo administradores pueden ver usuarios
    if (!esAdmin()) {
        throw new Exception('No tienes permisos para ver esta información');
    }

    $usuario_id = isset($_GET['id']) ? (int) $_GET['id'] : null;

    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            throw new Exception('Error de conexión a la base de datos');
        }

        if ($usuario_id) {
            // Obtener un usuario específico
            $query = "SELECT u.*, r.nombre as rol_nombre 
                      FROM usuarios u 
                      LEFT JOIN roles r ON u.rol_id = r.id 
                      WHERE u.id = ?";
            $resultado = $db->select($query, [$usuario_id]);

            if ($resultado) {
                $usuario = $resultado[0];
                // No incluir password en la respuesta
                unset($usuario['password']);

                $response['success'] = true;
                $response['data'] = $usuario;
                $response['message'] = 'Usuario encontrado';
            } else {
                $response['message'] = 'Usuario no encontrado';
            }
        } else {
            // Obtener lista de usuarios
            $query = "SELECT u.id, u.nombre, u.email, u.telefono, u.fecha_registro, r.nombre as rol_nombre 
                      FROM usuarios u 
                      LEFT JOIN roles r ON u.rol_id = r.id 
                      ORDER BY u.fecha_registro DESC";
            $usuarios = $db->select($query);

            $response['success'] = true;
            $response['data'] = $usuarios;
            $response['message'] = count($usuarios) . ' usuarios encontrados';
        }
    } catch (Exception $e) {
        throw new Exception('Error en la base de datos: ' . $e->getMessage());
    }
}

function handleCreateUsuario()
{
    global $response, $input;

    // Validar campos obligatorios
    $campos_requeridos = ['nombre', 'email', 'telefono', 'password'];
    foreach ($campos_requeridos as $campo) {
        if (!isset($input[$campo]) || empty($input[$campo])) {
            throw new Exception("El campo '$campo' es obligatorio");
        }
    }

    // Validar email
    if (!validarEmail($input['email'])) {
        throw new Exception('El email no es válido');
    }

    // Validar teléfono
    if (!validarTelefono($input['telefono'])) {
        throw new Exception('El teléfono debe tener 9 dígitos');
    }

    // Validar contraseña
    if (!validarPassword($input['password'])) {
        throw new Exception('La contraseña debe tener al menos 6 caracteres');
    }

    // Intentar registrar usuario
    if (registrarUsuario($input['nombre'], $input['email'], $input['telefono'], $input['password'])) {
        $response['success'] = true;
        $response['message'] = 'Usuario registrado exitosamente';

        error_log("Usuario registrado: {$input['email']}");
    } else {
        throw new Exception('Este email ya está registrado');
    }
}

function handleUpdateUsuario()
{
    global $response, $input;

    if (!isset($input['id']) || !is_numeric($input['id'])) {
        throw new Exception('ID de usuario no válido');
    }

    $usuario_id = (int) $input['id'];
    $usuario_actual = obtenerUsuarioActual();

    if (!esAdmin() && $usuario_actual['id'] != $usuario_id) {
        throw new Exception('No tienes permisos para actualizar este usuario');
    }

    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            throw new Exception('Error de conexión a la base de datos');
        }

        $campos = [];
        $params = [];

        if (isset($input['nombre'])) {
            $campos[] = "nombre = ?";
            $params[] = sanitizar($input['nombre']);
        }

        if (isset($input['email'])) {
            if (!validarEmail($input['email'])) {
                throw new Exception('El email no es válido');
            }

            // Verificar que el email no esté en uso por otro usuario
            $email_check = $db->select("SELECT id FROM usuarios WHERE email = ? AND id != ?", [$input['email'], $usuario_id]);
            if ($email_check) {
                throw new Exception('Este email ya está en uso por otro usuario');
            }

            $campos[] = "email = ?";
            $params[] = sanitizar($input['email']);
        }

        if (isset($input['telefono'])) {
            if (!validarTelefono($input['telefono'])) {
                throw new Exception('El teléfono debe tener 9 dígitos');
            }
            $campos[] = "telefono = ?";
            $params[] = sanitizar($input['telefono']);
        }

        if (isset($input['password']) && !empty($input['password'])) {
            if (!validarPassword($input['password'])) {
                throw new Exception('La contraseña debe tener al menos 6 caracteres');
            }
            $campos[] = "password = MD5(?)";
            $params[] = $input['password'];
        }

        // Solo admin puede cambiar rol
        if (isset($input['rol_id']) && esAdmin()) {
            $campos[] = "rol_id = ?";
            $params[] = (int) $input['rol_id'];
        }

        if (empty($campos)) {
            throw new Exception('No hay campos para actualizar');
        }

        $query = "UPDATE usuarios SET " . implode(', ', $campos) . " WHERE id = ?";
        $params[] = $usuario_id;

        if ($db->execute($query, $params)) {
            $response['success'] = true;
            $response['message'] = 'Usuario actualizado exitosamente';

            // Log de actividad
            error_log("Usuario actualizado: ID {$usuario_id}");
        } else {
            throw new Exception('Error al actualizar el usuario');
        }
    } catch (Exception $e) {
        throw new Exception('Error en la base de datos: ' . $e->getMessage());
    }
}

function handleDeleteUsuario()
{
    global $response;

    // Solo administradores pueden eliminar usuarios
    if (!esAdmin()) {
        throw new Exception('No tienes permisos para eliminar usuarios');
    }

    $usuario_id = isset($_GET['id']) ? (int) $_GET['id'] : null;

    if (!$usuario_id) {
        throw new Exception('ID de usuario no válido');
    }

    // No permitir que el admin se elimine a sí mismo
    $usuario_actual = obtenerUsuarioActual();
    if ($usuario_actual['id'] == $usuario_id) {
        throw new Exception('No puedes eliminar tu propia cuenta');
    }

    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            throw new Exception('Error de conexión a la base de datos');
        }

        // Verificar si el usuario tiene pedidos
        $pedidos_query = "SELECT COUNT(*) as total FROM pedidos WHERE usuario_id = ?";
        $pedidos_result = $db->select($pedidos_query, [$usuario_id]);

        if ($pedidos_result && $pedidos_result[0]['total'] > 0) {
            throw new Exception('No se puede eliminar el usuario porque tiene pedidos asociados');
        }

        $query = "DELETE FROM usuarios WHERE id = ?";

        if ($db->execute($query, [$usuario_id])) {
            $response['success'] = true;
            $response['data'] = ['id' => $usuario_id];
            $response['message'] = 'Usuario eliminado exitosamente';

            error_log("Usuario eliminado: ID {$usuario_id}");
        } else {
            throw new Exception('Error al eliminar el usuario');
        }
    } catch (Exception $e) {
        throw new Exception('Error en la base de datos: ' . $e->getMessage());
    }
}
?>