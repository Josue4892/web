<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

$response = [
    'success' => false,
    'message' => '',
    'data' => null
];

try {
    switch ($method) {
        case 'GET':
            handleGetChatbotData();
            break;

        case 'POST':
            handleChatbotQuery();
            break;

        default:
            throw new Exception('Método no permitido');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    http_response_code(400);
}

echo json_encode($response);


function handleGetChatbotData()
{
    global $response;

    try {
        // Cargar datos del chatbot desde JSON
        $chatbot_file = '../data/chatbot-data.json';

        if (!file_exists($chatbot_file)) {
            throw new Exception('Archivo de datos del chatbot no encontrado');
        }

        $chatbot_data = json_decode(file_get_contents($chatbot_file), true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Error al leer datos del chatbot: ' . json_last_error_msg());
        }

        // Agregar estadísticas del chatbot
        $chatbot_data['estadisticas'] = [
            'total_categorias' => count($chatbot_data['categorias'] ?? []),
            'total_preguntas' => 0,
            'version' => '1.0.0',
            'ultima_actualizacion' => date('Y-m-d H:i:s')
        ];

        // Contar preguntas
        foreach ($chatbot_data['categorias'] ?? [] as $categoria) {
            $chatbot_data['estadisticas']['total_preguntas'] += count($categoria['preguntas'] ?? []);
        }

        $response['success'] = true;
        $response['data'] = $chatbot_data;
        $response['message'] = 'Datos del chatbot obtenidos exitosamente';

    } catch (Exception $e) {
        throw new Exception('Error al obtener datos del chatbot: ' . $e->getMessage());
    }
}

function handleChatbotQuery()
{
    global $response, $input;

    if (!isset($input['query']) || empty($input['query'])) {
        throw new Exception('Query es requerido');
    }

    $query = sanitizar($input['query']);
    $contexto = $input['contexto'] ?? null;
    $categoria_actual = $input['categoria'] ?? null;

    try {
        $chatbot_file = '../data/chatbot-data.json';
        $chatbot_data = json_decode(file_get_contents($chatbot_file), true);

        $resultado = procesarQueryInteligente($query, $chatbot_data, $contexto, $categoria_actual);

        $response['success'] = true;
        $response['data'] = $resultado;
        $response['message'] = 'Query procesado exitosamente';

        guardarEstadisticaChatbot($query, $resultado['tipo']);

    } catch (Exception $e) {
        throw new Exception('Error al procesar query: ' . $e->getMessage());
    }
}

function procesarQueryInteligente($query, $chatbot_data, $contexto, $categoria_actual)
{
    $query_lower = strtolower($query);

    // 1. Buscar coincidencia exacta en preguntas
    $respuesta_exacta = buscarRespuestaExacta($query_lower, $chatbot_data);
    if ($respuesta_exacta) {
        return [
            'tipo' => 'respuesta_exacta',
            'respuesta' => $respuesta_exacta['respuesta'],
            'categoria' => $respuesta_exacta['categoria'],
            'pregunta_original' => $respuesta_exacta['pregunta'],
            'confidence' => 1.0
        ];
    }

    // 2. Buscar por palabras clave
    $respuesta_keywords = buscarPorPalabrasClave($query_lower, $chatbot_data);
    if ($respuesta_keywords) {
        return [
            'tipo' => 'busqueda_keywords',
            'respuesta' => $respuesta_keywords['respuesta'],
            'categoria' => $respuesta_keywords['categoria'],
            'confidence' => $respuesta_keywords['confidence'],
            'sugerencias' => $respuesta_keywords['sugerencias'] ?? []
        ];
    }

    // 3. Detectar intención especial
    $intencion = detectarIntencion($query_lower);
    if ($intencion) {
        return procesarIntencionEspecial($intencion, $chatbot_data);
    }

    // 4. Buscar productos relacionados
    $productos_relacionados = buscarProductosRelacionados($query_lower);
    if ($productos_relacionados) {
        return [
            'tipo' => 'productos_relacionados',
            'respuesta' => "Encontré algunos productos relacionados con tu búsqueda:",
            'productos' => $productos_relacionados,
            'confidence' => 0.7
        ];
    }

    // 5. Respuesta por defecto con sugerencias
    return [
        'tipo' => 'no_encontrado',
        'respuesta' => "No encontré una respuesta específica para tu pregunta. ¿Te puedo ayudar con alguna de estas opciones?",
        'sugerencias' => obtenerSugerenciasPopulares($chatbot_data),
        'confidence' => 0.0
    ];
}

function buscarRespuestaExacta($query, $chatbot_data)
{
    foreach ($chatbot_data['categorias'] ?? [] as $categoria_id => $categoria) {
        foreach ($categoria['preguntas'] ?? [] as $pregunta_id => $pregunta_data) {
            $pregunta_lower = strtolower($pregunta_data['pregunta']);

            // Coincidencia exacta o muy similar
            if ($query === $pregunta_lower || similar_text($query, $pregunta_lower) > 80) {
                return [
                    'respuesta' => $pregunta_data['respuesta'],
                    'categoria' => $categoria['titulo'],
                    'pregunta' => $pregunta_data['pregunta']
                ];
            }
        }
    }
    return null;
}

function buscarPorPalabrasClave($query, $chatbot_data)
{
    $palabras_query = explode(' ', $query);
    $mejores_coincidencias = [];

    $keywords_categorias = [
        'informacion_general' => ['horario', 'horarios', 'atención', 'ubicación', 'dirección', 'delivery', 'entrega', 'estacionamiento'],
        'productos_servicios' => ['medicamento', 'medicina', 'producto', 'belleza', 'bebé', 'vitamina', 'stock', 'precio', 'descuento'],
        'pagos_procesos' => ['pago', 'tarjeta', 'efectivo', 'yape', 'plin', 'devolver', 'cuenta', 'contraseña'],
        'salud_medicamentos' => ['receta', 'farmacéutico', 'interacción', 'genérico', 'dosis', 'efecto'],
        'contacto_ubicacion' => ['teléfono', 'whatsapp', 'email', 'contacto', 'facebook', 'instagram', 'llegar']
    ];

    foreach ($keywords_categorias as $categoria_id => $keywords) {
        $coincidencias = 0;
        foreach ($palabras_query as $palabra) {
            foreach ($keywords as $keyword) {
                if (strpos($palabra, $keyword) !== false || strpos($keyword, $palabra) !== false) {
                    $coincidencias++;
                }
            }
        }

        if ($coincidencias > 0) {
            $mejores_coincidencias[$categoria_id] = $coincidencias;
        }
    }

    if (!empty($mejores_coincidencias)) {
        arsort($mejores_coincidencias);
        $mejor_categoria = array_key_first($mejores_coincidencias);

        // Obtener una respuesta representativa de esa categoría
        $categoria_data = $chatbot_data['categorias'][$mejor_categoria] ?? null;
        if ($categoria_data) {
            $preguntas = array_values($categoria_data['preguntas']);
            $pregunta_representativa = $preguntas[0] ?? null;

            if ($pregunta_representativa) {
                return [
                    'respuesta' => $pregunta_representativa['respuesta'],
                    'categoria' => $categoria_data['titulo'],
                    'confidence' => min($mejores_coincidencias[$mejor_categoria] / count($palabras_query), 0.9),
                    'sugerencias' => array_slice(array_keys($categoria_data['preguntas']), 0, 3)
                ];
            }
        }
    }

    return null;
}

function detectarIntencion($query)
{
    $intenciones = [
        'saludo' => ['hola', 'buenos días', 'buenas tardes', 'buenas noches', 'hey', 'saludos'],
        'despedida' => ['adiós', 'hasta luego', 'nos vemos', 'chau', 'bye', 'gracias'],
        'ayuda' => ['ayuda', 'help', 'no entiendo', 'no comprendo', 'explicar'],
        'humano' => ['humano', 'persona', 'operador', 'atención', 'hablar con alguien'],
        'precio' => ['precio', 'costo', 'cuánto cuesta', 'valor', 'tarifa'],
        'stock' => ['stock', 'disponible', 'hay', 'tienen', 'cantidad']
    ];

    foreach ($intenciones as $intencion => $palabras) {
        foreach ($palabras as $palabra) {
            if (strpos($query, $palabra) !== false) {
                return $intencion;
            }
        }
    }

    return null;
}

function procesarIntencionEspecial($intencion, $chatbot_data)
{
    switch ($intencion) {
        case 'saludo':
            return [
                'tipo' => 'saludo',
                'respuesta' => $chatbot_data['saludo']['mensaje'] ?? '¡Hola! ¿En qué puedo ayudarte?',
                'confidence' => 1.0
            ];

        case 'despedida':
            return [
                'tipo' => 'despedida',
                'respuesta' => $chatbot_data['despedida']['mensaje'] ?? '¡Gracias por contactarnos! Que tengas un excelente día.',
                'confidence' => 1.0
            ];

        case 'ayuda':
            return [
                'tipo' => 'ayuda',
                'respuesta' => 'Puedo ayudarte con información sobre productos, horarios, precios y más. ¿Qué te gustaría saber?',
                'sugerencias' => obtenerSugerenciasPopulares($chatbot_data),
                'confidence' => 1.0
            ];

        case 'humano':
            $config = cargarConfiguracion();
            return [
                'tipo' => 'derivar_humano',
                'respuesta' => "Te conectaré con nuestro equipo humano. Puedes contactarnos por:\n📱 WhatsApp: {$config['farmacia']['whatsapp']}\n📞 Teléfono: {$config['farmacia']['telefono']}\n📧 Email: {$config['farmacia']['email']}",
                'confidence' => 1.0
            ];

        default:
            return null;
    }
}

function buscarProductosRelacionados($query)
{
    try {
        $productos = obtenerProductos(null, $query, 5);

        if (!empty($productos)) {
            return array_map(function ($producto) {
                return [
                    'id' => $producto['id'],
                    'nombre' => $producto['nombre'],
                    'precio' => formatearPrecio($producto['precio']),
                    'stock' => $producto['stock'],
                    'disponible' => $producto['stock'] > 0
                ];
            }, $productos);
        }
    } catch (Exception $e) {
        error_log("Error buscando productos: " . $e->getMessage());
    }

    return null;
}

function obtenerSugerenciasPopulares($chatbot_data)
{
    $sugerencias = [
        'informacion_general' => '📋 Información General',
        'productos_servicios' => '💊 Productos y Servicios',
        'pagos_procesos' => '💳 Pagos y Procesos',
        'contacto_ubicacion' => '📞 Contacto y Ubicación'
    ];

    return array_values($sugerencias);
}

function guardarEstadisticaChatbot($query, $tipo)
{
    try {
        $estadisticas_file = '../data/chatbot_stats.json';
        $estadisticas = [];

        if (file_exists($estadisticas_file)) {
            $estadisticas = json_decode(file_get_contents($estadisticas_file), true) ?? [];
        }

        $estadisticas[] = [
            'query' => $query,
            'tipo' => $tipo,
            'timestamp' => date('Y-m-d H:i:s'),
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ];

        // Mantener solo los últimos 1000 registros
        if (count($estadisticas) > 1000) {
            $estadisticas = array_slice($estadisticas, -1000);
        }

        file_put_contents($estadisticas_file, json_encode($estadisticas, JSON_PRETTY_PRINT));
    } catch (Exception $e) {
        error_log("Error guardando estadísticas del chatbot: " . $e->getMessage());
    }
}
?>