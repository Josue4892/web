<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];

$isFormData = isset($_POST) && !empty($_POST);
$input = $isFormData ? $_POST : json_decode(file_get_contents('php://input'), true);

$response = [
    'success' => false,
    'message' => '',
    'data' => null
];

try {
    switch ($method) {
        case 'GET':
            handleGetProductos();
            break;

        case 'POST':
            handleCreateOrUpdateProducto();
            break;

        case 'PUT':
            handleUpdateProducto();
            break;

        case 'DELETE':
            handleDeleteProducto();
            break;

        default:
            throw new Exception('Método no permitido');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    http_response_code(400);
}

echo json_encode($response);

function handleGetProductos()
{
    global $response;

    $categoria_id = isset($_GET['categoria']) ? (int) $_GET['categoria'] : null;
    $busqueda = isset($_GET['busqueda']) ? sanitizar($_GET['busqueda']) : null;
    $limite = isset($_GET['limite']) ? (int) $_GET['limite'] : null;
    $producto_id = isset($_GET['id']) ? (int) $_GET['id'] : null;

    if ($producto_id) {
        // Obtener un producto específico
        $producto = obtenerProductoPorId($producto_id);
        if ($producto) {
            $response['success'] = true;
            $response['data'] = $producto;
            $response['message'] = 'Producto encontrado';
        } else {
            $response['message'] = 'Producto no encontrado';
        }
    } else {
        // Obtener lista de productos
        $productos = obtenerProductos($categoria_id, $busqueda, $limite);

        // Agregar información adicional
        foreach ($productos as &$producto) {
            $producto['imagen_url'] = obtenerImagenProducto($producto['imagen']);
            $producto['precio_formateado'] = formatearPrecio($producto['precio']);
            $producto['stock_estado'] = $producto['stock'] > 20 ? 'alto' : ($producto['stock'] > 5 ? 'medio' : ($producto['stock'] > 0 ? 'bajo' : 'agotado'));
            $producto['disponible'] = $producto['stock'] > 0;
        }

        $response['success'] = true;
        $response['data'] = $productos;
        $response['message'] = count($productos) . ' productos encontrados';
    }
}

function handleCreateOrUpdateProducto()
{
    global $response, $input, $isFormData;

    $producto_id = isset($input['producto_id']) && !empty($input['producto_id']) ? (int) $input['producto_id'] : null;
    $accion = isset($input['accion']) ? $input['accion'] : '';

    if ($producto_id || $accion === 'editar_producto') {
        handleUpdateProductoFormData();
    } else {
        handleCreateProductoFormData();
    }
}

function handleCreateProductoFormData()
{
    global $response, $input, $isFormData;

    // Validar campos obligatorios
    $campos_requeridos = ['nombre', 'precio', 'stock', 'categoria_id'];
    foreach ($campos_requeridos as $campo) {
        if (!isset($input[$campo]) || empty($input[$campo])) {
            throw new Exception("El campo '$campo' es obligatorio");
        }
    }

    // Validar datos
    if (!is_numeric($input['precio']) || $input['precio'] < 0) {
        throw new Exception('El precio debe ser un número positivo');
    }

    if (!is_numeric($input['stock']) || $input['stock'] < 0) {
        throw new Exception('El stock debe ser un número positivo');
    }

    // Verificar que la categoría existe
    $categoria = obtenerCategoriaPorId($input['categoria_id']);
    if (!$categoria) {
        throw new Exception('La categoría especificada no existe');
    }

    // Manejar archivo de imagen
    $nombre_imagen = 'producto_default.jpg';
    if ($isFormData && isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $nombre_imagen = procesarImagenSubida($_FILES['imagen']);
    }

    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            throw new Exception('Error de conexión a la base de datos');
        }

        $query = "INSERT INTO productos (nombre, descripcion, precio, stock, categoria_id, imagen, fecha_creacion) 
                  VALUES (?, ?, ?, ?, ?, ?, NOW())";

        $params = [
            sanitizar($input['nombre']),
            sanitizar($input['descripcion'] ?? ''),
            (float) $input['precio'],
            (int) $input['stock'],
            (int) $input['categoria_id'],
            $nombre_imagen
        ];

        if ($db->execute($query, $params)) {
            $nuevo_id = $db->lastInsertId();
            $producto_creado = obtenerProductoPorId($nuevo_id);

            $response['success'] = true;
            $response['data'] = $producto_creado;
            $response['message'] = 'Producto creado exitosamente';

            error_log("Producto creado: ID {$nuevo_id}, Nombre: {$input['nombre']}");
        } else {
            throw new Exception('Error al crear el producto');
        }
    } catch (Exception $e) {
        throw new Exception('Error en la base de datos: ' . $e->getMessage());
    }
}

function handleUpdateProductoFormData()
{
    global $response, $input, $isFormData;

    $producto_id = isset($input['producto_id']) ? (int) $input['producto_id'] : null;

    if (!$producto_id) {
        throw new Exception('ID de producto no válido');
    }

    $producto_actual = obtenerProductoPorId($producto_id);
    if (!$producto_actual) {
        throw new Exception('Producto no encontrado');
    }

    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            throw new Exception('Error de conexión a la base de datos');
        }

        $campos = [];
        $params = [];

        if (isset($input['nombre']) && !empty($input['nombre'])) {
            $campos[] = "nombre = ?";
            $params[] = sanitizar($input['nombre']);
        }

        if (isset($input['descripcion'])) {
            $campos[] = "descripcion = ?";
            $params[] = sanitizar($input['descripcion']);
        }

        if (isset($input['precio']) && !empty($input['precio'])) {
            if (!is_numeric($input['precio']) || $input['precio'] < 0) {
                throw new Exception('El precio debe ser un número positivo');
            }
            $campos[] = "precio = ?";
            $params[] = (float) $input['precio'];
        }

        if (isset($input['stock']) && $input['stock'] !== '') {
            if (!is_numeric($input['stock']) || $input['stock'] < 0) {
                throw new Exception('El stock debe ser un número positivo');
            }
            $campos[] = "stock = ?";
            $params[] = (int) $input['stock'];
        }

        if (isset($input['categoria_id']) && !empty($input['categoria_id'])) {
            $categoria = obtenerCategoriaPorId($input['categoria_id']);
            if (!$categoria) {
                throw new Exception('La categoría especificada no existe');
            }
            $campos[] = "categoria_id = ?";
            $params[] = (int) $input['categoria_id'];
        }

        // Manejar archivo de imagen
        if ($isFormData && isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            $nombre_imagen = procesarImagenSubida($_FILES['imagen']);
            $campos[] = "imagen = ?";
            $params[] = $nombre_imagen;
        }

        if (empty($campos)) {
            throw new Exception('No hay campos para actualizar');
        }

        $query = "UPDATE productos SET " . implode(', ', $campos) . " WHERE id = ?";
        $params[] = $producto_id;

        if ($db->execute($query, $params)) {
            $producto_actualizado = obtenerProductoPorId($producto_id);

            $response['success'] = true;
            $response['data'] = $producto_actualizado;
            $response['message'] = 'Producto actualizado exitosamente';

            error_log("Producto actualizado: ID {$producto_id}");
        } else {
            throw new Exception('Error al actualizar el producto');
        }
    } catch (Exception $e) {
        throw new Exception('Error en la base de datos: ' . $e->getMessage());
    }
}

function handleUpdateProducto()
{
    global $response, $input;

    if (!isset($input['id']) || !is_numeric($input['id'])) {
        throw new Exception('ID de producto no válido');
    }

    $producto_id = (int) $input['id'];

    // Verificar que el producto existe
    $producto_actual = obtenerProductoPorId($producto_id);
    if (!$producto_actual) {
        throw new Exception('Producto no encontrado');
    }

    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            throw new Exception('Error de conexión a la base de datos');
        }

        // Construir query dinámicamente
        $campos = [];
        $params = [];

        if (isset($input['nombre'])) {
            $campos[] = "nombre = ?";
            $params[] = sanitizar($input['nombre']);
        }

        if (isset($input['descripcion'])) {
            $campos[] = "descripcion = ?";
            $params[] = sanitizar($input['descripcion']);
        }

        if (isset($input['precio'])) {
            if (!is_numeric($input['precio']) || $input['precio'] < 0) {
                throw new Exception('El precio debe ser un número positivo');
            }
            $campos[] = "precio = ?";
            $params[] = (float) $input['precio'];
        }

        if (isset($input['stock'])) {
            if (!is_numeric($input['stock']) || $input['stock'] < 0) {
                throw new Exception('El stock debe ser un número positivo');
            }
            $campos[] = "stock = ?";
            $params[] = (int) $input['stock'];
        }

        if (isset($input['categoria_id'])) {
            $categoria = obtenerCategoriaPorId($input['categoria_id']);
            if (!$categoria) {
                throw new Exception('La categoría especificada no existe');
            }
            $campos[] = "categoria_id = ?";
            $params[] = (int) $input['categoria_id'];
        }

        if (isset($input['imagen'])) {
            $campos[] = "imagen = ?";
            $params[] = sanitizar($input['imagen']);
        }

        if (empty($campos)) {
            throw new Exception('No hay campos para actualizar');
        }

        $query = "UPDATE productos SET " . implode(', ', $campos) . " WHERE id = ?";
        $params[] = $producto_id;

        if ($db->execute($query, $params)) {
            $producto_actualizado = obtenerProductoPorId($producto_id);

            $response['success'] = true;
            $response['data'] = $producto_actualizado;
            $response['message'] = 'Producto actualizado exitosamente';

            error_log("Producto actualizado: ID {$producto_id}");
        } else {
            throw new Exception('Error al actualizar el producto');
        }
    } catch (Exception $e) {
        throw new Exception('Error en la base de datos: ' . $e->getMessage());
    }
}

function handleDeleteProducto()
{
    global $response, $input;

    $producto_id = isset($_GET['id']) ? (int) $_GET['id'] : (isset($input['id']) ? (int) $input['id'] : null);

    if (!$producto_id) {
        throw new Exception('ID de producto no válido');
    }

    $producto = obtenerProductoPorId($producto_id);
    if (!$producto) {
        throw new Exception('Producto no encontrado');
    }

    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            throw new Exception('Error de conexión a la base de datos');
        }

        $pedidos_query = "SELECT COUNT(*) as total FROM detalle_pedidos WHERE producto_id = ?";
        $pedidos_result = $db->select($pedidos_query, [$producto_id]);

        if ($pedidos_result && $pedidos_result[0]['total'] > 0) {
            throw new Exception('No se puede eliminar el producto porque tiene pedidos asociados');
        }

        $query = "DELETE FROM productos WHERE id = ?";

        if ($db->execute($query, [$producto_id])) {
            $response['success'] = true;
            $response['data'] = ['id' => $producto_id];
            $response['message'] = 'Producto eliminado exitosamente';

            error_log("Producto eliminado: ID {$producto_id}, Nombre: {$producto['nombre']}");
        } else {
            throw new Exception('Error al eliminar el producto');
        }
    } catch (Exception $e) {
        throw new Exception('Error en la base de datos: ' . $e->getMessage());
    }
}


function procesarImagenSubida($archivo)
{
    $directorio_destino = __DIR__ . '/../assets/images/productos/';

    // Crear directorio si no existe
    if (!is_dir($directorio_destino)) {
        mkdir($directorio_destino, 0755, true);
    }

    // Validar tipo de archivo
    $tipos_permitidos = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($archivo['type'], $tipos_permitidos)) {
        throw new Exception('Tipo de archivo no permitido. Use JPG, PNG, GIF o WEBP.');
    }

    // Validar tamaño (máximo 2MB)
    if ($archivo['size'] > 2 * 1024 * 1024) {
        throw new Exception('El archivo es demasiado grande. Máximo 2MB.');
    }

    // Generar nombre único
    $extension = pathinfo($archivo['name'], PATHINFO_EXTENSION);
    $nombre_archivo = 'producto_' . time() . '_' . rand(1000, 9999) . '.' . $extension;
    $ruta_completa = $directorio_destino . $nombre_archivo;

    // Mover archivo
    if (move_uploaded_file($archivo['tmp_name'], $ruta_completa)) {
        return $nombre_archivo;
    } else {
        throw new Exception('Error al subir la imagen');
    }
}

function validarImagen($nombre_imagen)
{
    $extensiones_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $extension = strtolower(pathinfo($nombre_imagen, PATHINFO_EXTENSION));

    return in_array($extension, $extensiones_permitidas);
}

function generarSlug($texto)
{
    $slug = strtolower($texto);
    $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
    $slug = preg_replace('/[\s-]+/', '-', $slug);
    $slug = trim($slug, '-');

    return $slug;
}
?>