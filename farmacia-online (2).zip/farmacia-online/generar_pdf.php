<?php
require_once 'includes/functions.php';

require_once 'libreria/tcpdf.php';

error_reporting(E_ALL);
ini_set('display_errors', 0);
if (!estaLogueado()) {
    if (isset($_GET['accion']) && $_GET['accion'] === 'whatsapp') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'mensaje' => 'Acceso denegado']);
        exit;
    }
    http_response_code(401);
    die('Acceso denegado');
}

// Obtener parámetros
$pedido_id = isset($_GET['pedido_id']) ? (int) $_GET['pedido_id'] : 0;
$accion = isset($_GET['accion']) ? $_GET['accion'] : 'ver';

if (!$pedido_id) {
    if ($accion === 'whatsapp') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'mensaje' => 'ID de pedido requerido']);
        exit;
    }
    die('ID de pedido requerido');
}

// Obtener datos del pedido
$pedido = obtenerPedidoCompleto($pedido_id);
if (!$pedido) {
    if ($accion === 'whatsapp') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'mensaje' => 'Pedido no encontrado']);
        exit;
    }
    die('Pedido no encontrado');
}

// Verificar permisos
$usuario_actual = obtenerUsuarioActual();
if (!esAdmin() && $pedido['usuario_id'] != $usuario_actual['id']) {
    if ($accion === 'whatsapp') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'mensaje' => 'No tienes permiso para ver este pedido']);
        exit;
    }
    die('No tienes permiso para ver este pedido');
}

// Manejar acciones
try {
    switch ($accion) {
        case 'descargar':
            generarPDFReal($pedido, true);
            break;

        case 'whatsapp':
            enviarMensajeWhatsApp($pedido);
            break;

        default: // 'ver'
            generarPDFReal($pedido, false);
            break;
    }
} catch (Exception $e) {
    error_log("Error en generar_pdf.php: " . $e->getMessage());

    if ($accion === 'whatsapp') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'mensaje' => 'Error interno: ' . $e->getMessage()]);
        exit;
    }

    die('Error al procesar la solicitud: ' . $e->getMessage());
}


function obtenerPedidoCompleto($pedido_id)
{
    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn)
            return null;

        // Pedido con usuario
        $query = "SELECT p.*, u.nombre as usuario_nombre, u.email as usuario_email, u.telefono
                  FROM pedidos p 
                  INNER JOIN usuarios u ON p.usuario_id = u.id 
                  WHERE p.id = ?";

        $resultado = $db->select($query, [$pedido_id]);
        if (!$resultado)
            return null;

        $pedido = $resultado[0];

        // Productos del pedido
        $query_productos = "SELECT dp.*, pr.nombre as producto_nombre, pr.descripcion, 
                           c.nombre as categoria_nombre, pr.imagen
                           FROM detalle_pedidos dp
                           INNER JOIN productos pr ON dp.producto_id = pr.id
                           LEFT JOIN categorias c ON pr.categoria_id = c.id
                           WHERE dp.pedido_id = ?
                           ORDER BY pr.nombre";

        $productos = $db->select($query_productos, [$pedido_id]);
        $pedido['productos'] = $productos ?: [];

        return $pedido;

    } catch (Exception $e) {
        error_log("Error obteniendo pedido: " . $e->getMessage());
        return null;
    }
}


function generarPDFReal($pedido, $descargar = false)
{
    // USAR LA FUNCIÓN QUE YA EXISTE EN functions.php
    $config = cargarConfiguracion();
    $farmacia = $config['farmacia'];

    try {
        // Crear nuevo documento PDF
        $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

        // Configurar documento
        $pdf->SetCreator('FarmaPlus');
        $pdf->SetAuthor($farmacia['nombre']);
        $pdf->SetTitle('Boleta de Venta #' . str_pad($pedido['id'], 6, '0', STR_PAD_LEFT));
        $pdf->SetSubject('Boleta de Venta');

        // Remover header y footer por defecto
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);

        // Configurar márgenes
        $pdf->SetMargins(10, 10, 10);
        $pdf->SetAutoPageBreak(TRUE, 15);

        // Agregar página
        $pdf->AddPage();

        // Contenido HTML de la boleta MEJORADO CON NUEVO ESTILO
        $html = generarHTMLBoletaMejorada($pedido, $farmacia);

        // Configurar fuente por defecto
        $pdf->SetFont('helvetica', '', 10);

        // Escribir HTML al PDF
        $pdf->writeHTML($html, true, false, true, false, '');

        // Configurar nombre del archivo
        $filename = 'boleta_' . str_pad($pedido['id'], 6, '0', STR_PAD_LEFT) . '.pdf';

        // Generar PDF
        if ($descargar) {
            $pdf->Output($filename, 'D'); // D = descargar
        } else {
            $pdf->Output($filename, 'I'); // I = mostrar en navegador
        }

    } catch (Exception $e) {
        error_log("Error generando PDF: " . $e->getMessage());
        throw new Exception('Error al generar el PDF: ' . $e->getMessage());
    }
}

function generarHTMLBoletaMejorada($pedido, $farmacia)
{
    $fecha_actual = date('d/m/Y H:i');
    $fecha_pedido = date('d/m/Y H:i', strtotime($pedido['fecha_pedido']));
    $numero_boleta = str_pad($pedido['id'], 6, '0', STR_PAD_LEFT);

    $html = '
    <style>
        body { 
            font-family: Arial, sans-serif; 
            font-size: 10px;
            line-height: 1.4;
            color: #2c3e50;
            margin: 0;
            padding: 0;
        }
        
        .header-principal {
            text-align: center;
            background-color: #27ae60;
            color: white;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 15px;
            box-shadow: 0 3px 6px rgba(0,0,0,0.15);
        }
        
        .farmacia-nombre {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 4px;
        }
        
        .farmacia-slogan {
            font-size: 11px;
            margin-bottom: 6px;
            opacity: 0.95;
            font-style: italic;
        }
        
        .farmacia-contacto {
            font-size: 9px;
            opacity: 0.9;
        }
        
        .info-boleta {
            background-color: #f8f9fa;
            border: 2px solid #27ae60;
            color: #2c3e50;
            padding: 12px;
            text-align: center;
            margin-bottom: 15px;
            border-radius: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .boleta-numero {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 3px;
            color: #27ae60;
        }
        
        .boleta-fecha {
            font-size: 9px;
            color: #6c757d;
        }
        
        .tabla-info {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 3px 6px rgba(0,0,0,0.12);
        }
        
        .tabla-info th {
            background-color: #f8f9fa;
            color: #2c3e50;
            padding: 10px 8px;
            text-align: center;
            font-weight: bold;
            font-size: 10px;
            border-right: 1px solid #dee2e6;
            border-bottom: 2px solid #27ae60;
        }
        
        .tabla-info th:last-child {
            border-right: none;
        }
        
        .tabla-info td {
            padding: 10px 8px;
            border: 1px solid #dee2e6;
            font-size: 9px;
            vertical-align: top;
            background-color: #ffffff;
        }
        
        .etiqueta-info {
            font-weight: bold;
            color: #495057;
            display: block;
            margin-bottom: 4px;
            font-size: 9px;
            text-transform: uppercase;
        }
        
        .valor-info {
            color: #2c3e50;
            line-height: 1.3;
        }
        
        .productos-seccion {
            margin-bottom: 15px;
        }
        
        .productos-titulo {
            background-color: #f8f9fa;
            color: #2c3e50;
            border: 2px solid #27ae60;
            border-bottom: none;
            padding: 10px;
            text-align: center;
            font-size: 12px;
            font-weight: bold;
            border-radius: 15px 15px 0 0;
            margin: 0;
        }
        
        .tabla-productos {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 3px 6px rgba(0,0,0,0.12);
            border-radius: 0 0 15px 15px;
            overflow: hidden;
        }
        
        .tabla-productos th {
            background-color: #f8f9fa;
            color: #2c3e50;
            padding: 10px 8px;
            text-align: center;
            font-weight: bold;
            font-size: 10px;
            border-right: 1px solid #dee2e6;
            border-bottom: 1px solid #dee2e6;
        }
        
        .tabla-productos th:last-child {
            border-right: none;
        }
        
        .tabla-productos td {
            padding: 10px 6px;
            border: 1px solid #dee2e6;
            font-size: 9px;
            text-align: center;
            vertical-align: middle;
            color: #2c3e50;
        }
        
        .tabla-productos tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        
        .tabla-productos tr:nth-child(odd) {
            background-color: #ffffff;
        }
        
        .col-producto { width: 35%; text-align: left; }
        .col-categoria { width: 20%; }
        .col-cantidad { width: 15%; }
        .col-precio { width: 15%; text-align: right; }
        .col-subtotal { width: 15%; text-align: right; }
        
        .producto-nombre {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 3px;
            font-size: 10px;
        }
        
        .producto-descripcion {
            font-size: 9px;
            color: #6c757d;
            font-style: italic;
            line-height: 1.2;
        }
        
        .categoria-texto {
            color: #2c3e50;
            padding: 3px 6px;
            border: 1px solid #dee2e6;
            border-radius: 20px;
            font-size: 8px;
            font-weight: normal;
            display: inline-block;
            background-color: #f8f9fa;
        }
        
        .cantidad-numero {
            color: #2c3e50;
            padding: 4px 8px;
            border: 1px solid #dee2e6;
            border-radius: 12px;
            font-weight: bold;
            font-size: 9px;
            background-color: #f8f9fa;
        }
        
        .precio-valor {
            font-weight: bold;
            color: #2c3e50;
            font-family: monospace;
        }
        
        .subtotal-valor {
            font-weight: bold;
            color: #2c3e50;
            font-family: monospace;
        }
        
        .seccion-totales {
            display: table;
            width: 100%;
            margin-bottom: 12px;
        }
        
        .col-resumen {
            display: table-cell;
            width: 65%;
            padding-right: 15px;
            vertical-align: top;
        }
        
        .col-total {
            display: table-cell;
            width: 35%;
            vertical-align: top;
        }
        
        .resumen-caja {
            background-color: #ffffff;
            border: 2px solid #dee2e6;
            border-radius: 15px;
            padding: 12px;
            box-shadow: 0 3px 6px rgba(0,0,0,0.12);
        }
        
        .resumen-titulo {
            background-color: #f8f9fa;
            color: #2c3e50;
            margin: -12px -12px 10px -12px;
            padding: 8px;
            border-radius: 13px 13px 0 0;
            font-weight: bold;
            text-align: center;
            font-size: 10px;
            border-bottom: 2px solid #27ae60;
        }
        
        .resumen-item {
            display: table;
            width: 100%;
            margin-bottom: 4px;
            font-size: 9px;
            padding: 2px 0;
        }
        
        .resumen-item:last-child {
            border-top: 2px solid #27ae60;
            margin-top: 8px;
            padding-top: 8px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .resumen-etiqueta {
            display: table-cell;
            color: #495057;
            font-weight: 500;
        }
        
        .resumen-valor {
            display: table-cell;
            text-align: right;
            font-weight: bold;
            color: #2c3e50;
            font-family: monospace;
        }
        
        .total-final {
            background-color: #27ae60;
            color: white;
            padding: 15px;
            text-align: center;
            border-radius: 15px;
            box-shadow: 0 3px 6px rgba(0,0,0,0.15);
        }
        
        .total-etiqueta {
            font-size: 11px;
            margin-bottom: 4px;
            opacity: 0.95;
        }
        
        .total-monto {
            font-size: 18px;
            font-weight: bold;
            font-family: monospace;
        }
        
        .footer {
            text-align: center;
            margin-top: 15px;
            padding: 12px;
            background-color: #f8f9fa;
            border-top: 3px solid #27ae60;
            border-radius: 15px;
            font-size: 8px;
            color: #495057;
            box-shadow: 0 2px 4px rgba(0,0,0,0.08);
        }
        
        .footer-gracias {
            font-weight: bold;
            color: #27ae60;
            margin-bottom: 4px;
            font-size: 10px;
        }
        
        .footer-contacto {
            margin-bottom: 4px;
            font-weight: 500;
        }
        
        .footer-legal {
            color: #6c757d;
            font-style: italic;
            margin-top: 4px;
        }
    </style>
    
    <!-- HEADER PRINCIPAL -->
    <div class="header-principal">
        <div class="farmacia-nombre">' . htmlspecialchars($farmacia['nombre'], ENT_QUOTES, 'UTF-8') . '</div>
        <div class="farmacia-slogan">' . htmlspecialchars($farmacia['slogan'], ENT_QUOTES, 'UTF-8') . '</div>
        <div class="farmacia-contacto">
            Tel: ' . htmlspecialchars($farmacia['telefono'], ENT_QUOTES, 'UTF-8') . ' | Email: ' . htmlspecialchars($farmacia['email'], ENT_QUOTES, 'UTF-8') . ' | Lima, Perú
        </div>
    </div>
    
    <!-- INFORMACIÓN BOLETA -->
    <div class="info-boleta">
        <div class="boleta-numero">BOLETA DE VENTA #' . $numero_boleta . '</div>
        <div class="boleta-fecha">Generada el ' . $fecha_actual . '</div>
    </div>
    
    <!-- TABLA INFORMACIÓN DEL PEDIDO -->
    <table class="tabla-info">
        <thead>
            <tr>
                <th width="25%">CLIENTE</th>
                <th width="25%">CONTACTO</th>
                <th width="25%">PEDIDO</th>
                <th width="25%">FECHAS</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <span class="etiqueta-info">Nombre:</span>
                    <div class="valor-info">' . htmlspecialchars($pedido['usuario_nombre'], ENT_QUOTES, 'UTF-8') . '</div>
                </td>
                <td>
                    <span class="etiqueta-info">Email:</span>
                    <div class="valor-info">' . htmlspecialchars($pedido['usuario_email'], ENT_QUOTES, 'UTF-8') . '</div>
                    <br>
                    <span class="etiqueta-info">Teléfono:</span>
                    <div class="valor-info">' . htmlspecialchars($pedido['telefono'], ENT_QUOTES, 'UTF-8') . '</div>
                </td>
                <td>
                    <span class="etiqueta-info">Número:</span>
                    <div class="valor-info">#' . $pedido['id'] . '</div>
                    <br>
                    <span class="etiqueta-info">Estado:</span>
                    <div class="valor-info">' . ucfirst(str_replace('_', ' ', $pedido['estado'])) . '</div>
                </td>
                <td>
                    <span class="etiqueta-info">Fecha Pedido:</span>
                    <div class="valor-info">' . $fecha_pedido . '</div>
                    <br>
                    <span class="etiqueta-info">Fecha Boleta:</span>
                    <div class="valor-info">' . $fecha_actual . '</div>
                </td>
            </tr>
        </tbody>
    </table>';

    // PRODUCTOS
    if (!empty($pedido['productos'])) {
        $html .= '
    <!-- SECCION PRODUCTOS -->
    <div class="productos-seccion">
        <div class="productos-titulo">Detalle de Productos Adquiridos</div>
        
        <table class="tabla-productos">
            <thead>
                <tr>
                    <th class="col-producto">Producto</th>
                    <th class="col-categoria">Categoría</th>
                    <th class="col-cantidad">Cantidad</th>
                    <th class="col-precio">Precio Unit.</th>
                    <th class="col-subtotal">Subtotal</th>
                </tr>
            </thead>
            <tbody>';

        $subtotal_general = 0;
        $total_productos = 0;

        foreach ($pedido['productos'] as $producto) {
            $subtotal = $producto['cantidad'] * $producto['precio_unitario'];
            $subtotal_general += $subtotal;
            $total_productos += $producto['cantidad'];

            $categoria = !empty($producto['categoria_nombre']) ? $producto['categoria_nombre'] : 'General';
            $descripcion = !empty($producto['descripcion']) ? $producto['descripcion'] : '';

            $html .= '
            <tr>
                <td class="col-producto">
                    <div class="producto-nombre">' . htmlspecialchars($producto['producto_nombre'], ENT_QUOTES, 'UTF-8') . '</div>';

            if ($descripcion) {
                $html .= '<div class="producto-descripcion">' . htmlspecialchars($descripcion, ENT_QUOTES, 'UTF-8') . '</div>';
            }

            $html .= '
                </td>
                <td class="col-categoria">
                    <span class="categoria-texto">' . htmlspecialchars($categoria, ENT_QUOTES, 'UTF-8') . '</span>
                </td>
                <td class="col-cantidad">
                    <span class="cantidad-numero">' . $producto['cantidad'] . '</span>
                </td>
                <td class="col-precio precio-valor">S/ ' . number_format($producto['precio_unitario'], 2) . '</td>
                <td class="col-subtotal subtotal-valor">S/ ' . number_format($subtotal, 2) . '</td>
            </tr>';
        }

        $html .= '
            </tbody>
        </table>
    </div>
    
    <!-- SECCION TOTALES -->
    <div class="seccion-totales">
        <div class="col-resumen">
            <div class="resumen-caja">
                <div class="resumen-titulo">Resumen del Pedido</div>
                
                <div class="resumen-item">
                    <span class="resumen-etiqueta">Productos diferentes:</span>
                    <span class="resumen-valor">' . count($pedido['productos']) . '</span>
                </div>
                
                <div class="resumen-item">
                    <span class="resumen-etiqueta">Cantidad total:</span>
                    <span class="resumen-valor">' . $total_productos . ' unidades</span>
                </div>
                
                <div class="resumen-item">
                    <span class="resumen-etiqueta">Subtotal:</span>
                    <span class="resumen-valor">S/ ' . number_format($subtotal_general, 2) . '</span>
                </div>
                
                <div class="resumen-item">
                    <span class="resumen-etiqueta">TOTAL FINAL:</span>
                    <span class="resumen-valor">S/ ' . number_format($pedido['total'], 2) . '</span>
                </div>
            </div>
        </div>
        
        <div class="col-total">
            <div class="total-final">
                <div class="total-etiqueta">Total a Pagar</div>
                <div class="total-monto">S/ ' . number_format($pedido['total'], 2) . '</div>
            </div>
        </div>
    </div>';
    }

    $html .= '
    <!-- FOOTER -->
    <div class="footer">
        <div class="footer-gracias">¡Gracias por su compra en ' . htmlspecialchars($farmacia['nombre'], ENT_QUOTES, 'UTF-8') . '!</div>
        <div class="footer-contacto">' . htmlspecialchars($farmacia['telefono'], ENT_QUOTES, 'UTF-8') . ' | ' . htmlspecialchars($farmacia['email'], ENT_QUOTES, 'UTF-8') . '</div>
        <div class="footer-legal">Boleta generada electrónicamente - Documento válido como comprobante de compra</div>
    </div>';

    return $html;
}

function enviarMensajeWhatsApp($pedido)
{
    header('Content-Type: application/json; charset=utf-8');

    try {
        $config = cargarConfiguracion();
        $farmacia = $config['farmacia'];

        $temp_dir = __DIR__ . '/temp';
        if (!file_exists($temp_dir)) {
            if (!mkdir($temp_dir, 0755, true)) {
                throw new Exception('No se pudo crear el directorio temporal');
            }
        }

        if (!is_writable($temp_dir)) {
            throw new Exception('El directorio temporal no tiene permisos de escritura');
        }

        $pdf_generado = false;
        $filename = '';
        $boleta_url = '';
        $full_path = '';

        // Intentar generar PDF temporal
        try {
            $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
            $pdf->SetCreator('FarmaPlus');
            $pdf->SetAuthor($farmacia['nombre']);
            $pdf->SetTitle('Boleta #' . $pedido['id']);
            $pdf->setPrintHeader(false);
            $pdf->setPrintFooter(false);
            $pdf->SetMargins(10, 10, 10);
            $pdf->SetAutoPageBreak(TRUE, 15);
            $pdf->SetFont('helvetica', '', 10);
            $pdf->AddPage();

            $html = generarHTMLBoletaMejorada($pedido, $farmacia);
            $pdf->writeHTML($html, true, false, true, false, '');

            // Guardar PDF temporalmente
            $filename = 'temp/boleta_' . $pedido['id'] . '_' . time() . '.pdf';
            $full_path = __DIR__ . '/' . $filename;

            $pdf->Output($full_path, 'F'); // F = guardar archivo

            if (file_exists($full_path) && filesize($full_path) > 0) {
                $pdf_generado = true;
                // URL completa para el PDF
                $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
                $host = $_SERVER['HTTP_HOST'];
                $path = dirname($_SERVER['PHP_SELF']);
                $boleta_url = $protocol . '://' . $host . $path . '/' . $filename;
            }

        } catch (Exception $e) {
            error_log("Error generando PDF temporal: " . $e->getMessage());
            // Fallback: usar enlace directo al generador
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
            $host = $_SERVER['HTTP_HOST'];
            $path = dirname($_SERVER['PHP_SELF']);
            $boleta_url = $protocol . '://' . $host . $path . '/generar_pdf.php?pedido_id=' . $pedido['id'] . '&accion=ver';
        }

        // Preparar número de teléfono
        $telefono_cliente = $pedido['telefono'];

        // Limpiar y formatear teléfono
        $telefono_limpio = preg_replace('/[^0-9]/', '', $telefono_cliente);

        // Agregar código de país si no lo tiene
        if (!str_starts_with($telefono_limpio, '51') && strlen($telefono_limpio) === 9) {
            $telefono_limpio = '51' . $telefono_limpio;
        } elseif (str_starts_with($telefono_limpio, '51') && strlen($telefono_limpio) === 11) {
            // Ya tiene el código, mantenerlo
        } else {
            // Intentar formato directo
            if (strlen($telefono_limpio) === 9) {
                $telefono_limpio = '51' . $telefono_limpio;
            }
        }

        // Crear mensaje de WhatsApp mejorado
        $mensaje = generarMensajeWhatsApp($pedido, $farmacia, $boleta_url);

        // URL de WhatsApp
        $whatsapp_url = "https://wa.me/" . $telefono_limpio . "?text=" . urlencode($mensaje);

        // Programar limpieza del archivo temporal (si se generó)
        if ($pdf_generado && file_exists($full_path)) {
            // Usar ignore_user_abort para que la limpieza no se cancele
            register_shutdown_function(function () use ($full_path) {
                // Programar eliminación después de 2 horas
                $cleanup_script = '
                <?php
                sleep(7200); // 2 horas
                if (file_exists("' . $full_path . '")) {
                    unlink("' . $full_path . '");
                }
                ?>';

                // Ejecutar limpieza en background (solo en sistemas Unix)
                if (function_exists('exec') && stripos(PHP_OS, 'WIN') === false) {
                    exec('php -r \'' . str_replace("'", "\'", trim($cleanup_script, '<?php ?>')) . '\' > /dev/null 2>&1 &');
                }
            });
        }

        // Respuesta exitosa
        echo json_encode([
            'success' => true,
            'whatsapp_url' => $whatsapp_url,
            'boleta_url' => $boleta_url,
            'pdf_generado' => $pdf_generado,
            'archivo_temporal' => $pdf_generado ? $filename : null,
            'mensaje' => $pdf_generado ? 'Boleta PDF generada y mensaje preparado para WhatsApp' : 'Mensaje preparado con enlace directo a la boleta',
            'telefono' => $telefono_limpio,
            'debug' => [
                'telefono_original' => $pedido['telefono'],
                'telefono_procesado' => $telefono_limpio,
                'pdf_path' => $pdf_generado ? $full_path : null,
                'pdf_size' => $pdf_generado && file_exists($full_path) ? filesize($full_path) : 0
            ]
        ], JSON_UNESCAPED_UNICODE);

    } catch (Exception $e) {
        error_log("Error en enviarMensajeWhatsApp: " . $e->getMessage());

        echo json_encode([
            'success' => false,
            'mensaje' => 'Error interno del servidor: ' . $e->getMessage(),
            'error_type' => 'server_error',
            'debug' => [
                'error_message' => $e->getMessage(),
                'error_file' => $e->getFile(),
                'error_line' => $e->getLine()
            ]
        ], JSON_UNESCAPED_UNICODE);
    }

    exit;
}

// ================================
// GENERAR MENSAJE DE WHATSAPP
// ================================
function generarMensajeWhatsApp($pedido, $farmacia, $boleta_url)
{
    $numero_boleta = str_pad($pedido['id'], 6, '0', STR_PAD_LEFT);
    $fecha_pedido = date('d/m/Y H:i', strtotime($pedido['fecha_pedido']));

    $mensaje = "🏥 *Hola! Le escribimos de {$farmacia['nombre']}* 🏥\n\n";
    $mensaje .= "📋 *BOLETA DE VENTA #{$numero_boleta}*\n";
    $mensaje .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";

    // Información del pedido
    $mensaje .= "👤 *Cliente:* {$pedido['usuario_nombre']}\n";
    $mensaje .= "📅 *Fecha del pedido:* {$fecha_pedido}\n";
    $mensaje .= "🆔 *Número de pedido:* #{$pedido['id']}\n";
    $mensaje .= "📊 *Estado:* " . ucfirst(str_replace('_', ' ', $pedido['estado'])) . "\n\n";

    // Productos resumidos
    $mensaje .= "🛒 *Productos adquiridos:*\n";
    $total_items = 0;
    foreach ($pedido['productos'] as $index => $producto) {
        $subtotal = $producto['cantidad'] * $producto['precio_unitario'];
        $total_items += $producto['cantidad'];

        if ($index < 5) { // Mostrar solo los primeros 5 productos
            $mensaje .= "• *{$producto['cantidad']}x* {$producto['producto_nombre']}\n";
            $mensaje .= "   _S/ " . number_format($subtotal, 2) . "_\n";
        }
    }

    if (count($pedido['productos']) > 5) {
        $productos_restantes = count($pedido['productos']) - 5;
        $mensaje .= "• _... y {$productos_restantes} producto(s) más_\n";
    }

    $mensaje .= "\n📦 *Total de items:* {$total_items}\n";
    $mensaje .= "💰 *TOTAL PAGADO: S/ " . number_format($pedido['total'], 2) . "*\n\n";

    // Enlaces
    $mensaje .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    $mensaje .= "🧾 *Ver/Descargar boleta completa:*\n";
    $mensaje .= "{$boleta_url}\n\n";

    // Información de contacto
    $mensaje .= "📞 *¿Necesita ayuda?*\n";
    $mensaje .= "• Teléfono: {$farmacia['telefono']}\n";
    $mensaje .= "• Email: {$farmacia['email']}\n\n";

    // Despedida
    $mensaje .= "💊 *¡Gracias por confiar en nosotros!*\n";
    $mensaje .= "🌟 *Que tenga un excelente día*\n\n";
    $mensaje .= "_Este mensaje fue generado automáticamente_";

    return $mensaje;
}
?>