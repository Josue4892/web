</main>
  
    <footer class="bg-dark text-light mt-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="d-flex align-items-center mb-3">
                        <img src="assets/images/logo.png" alt="<?php echo $farmacia['nombre']; ?>" height="40">
                        <h5 class="text-success mb-0 ms-2"><?php echo $farmacia['nombre']; ?></h5>
                    </div>
                    <p class="text-muted"><?php echo $farmacia['slogan']; ?></p>
                    <p class="mb-2">
                        <i class="fas fa-map-marker-alt text-success me-2"></i>
                        <?php echo $farmacia['direccion'] ?? 'Av. Principal 123, San Isidro, Lima'; ?>
                    </p>
                    <p class="mb-2">
                        <i class="fas fa-phone text-success me-2"></i>
                        <?php echo $farmacia['telefono']; ?>
                    </p>
                    <p class="mb-0">
                        <i class="fas fa-envelope text-success me-2"></i>
                        <?php echo $farmacia['email']; ?>
                    </p>
                </div>

                <div class="col-lg-2 col-md-6 mb-4">
                    <h6 class="text-success mb-3">Enlaces Útiles</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <a href="index.php" class="text-muted text-decoration-none">
                                <i class="fas fa-home me-2"></i>Inicio
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="catalogo.php" class="text-muted text-decoration-none">
                                <i class="fas fa-pills me-2"></i>Productos
                            </a>
                        </li>
                        <?php if (estaLogueado()): ?>
                        <li class="mb-2">
                            <a href="perfil.php" class="text-muted text-decoration-none">
                                <i class="fas fa-user me-2"></i>Mi Perfil
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="carrito.php" class="text-muted text-decoration-none">
                                <i class="fas fa-shopping-cart me-2"></i>Mi Carrito
                            </a>
                        </li>
                        <?php else: ?>
                        <li class="mb-2">
                            <a href="login_viejo.php" class="text-muted text-decoration-none">
                                <i class="fas fa-sign-in-alt me-2"></i>Ingresar
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4">
                    <h6 class="text-success mb-3">Horarios de Atención</h6>
                    <div class="text-muted">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Lunes - Viernes:</span>
                            <span><?php echo $farmacia['horarios']['lunes_viernes']; ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Sábados:</span>
                            <span><?php echo $farmacia['horarios']['sabado'] ?? '8:00 AM - 8:00 PM'; ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Domingos:</span>
                            <span><?php echo $farmacia['horarios']['domingo'] ?? '9:00 AM - 6:00 PM'; ?></span>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <h6 class="text-success mb-3">Métodos de Pago</h6>
                        <div class="d-flex flex-wrap">
                            <span class="badge bg-secondary me-2 mb-2">
                                <i class="fas fa-credit-card me-1"></i>Visa
                            </span>
                            <span class="badge bg-secondary me-2 mb-2">
                                <i class="fas fa-credit-card me-1"></i>Mastercard
                            </span>
                            <span class="badge bg-secondary me-2 mb-2">
                                <i class="fas fa-money-bill me-1"></i>Efectivo
                            </span>
                            <span class="badge bg-secondary me-2 mb-2">
                                <i class="fas fa-mobile-alt me-1"></i>Yape/Plin
                            </span>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 mb-4">
                    <h6 class="text-success mb-3">Síguenos</h6>
                    <div class="d-flex mb-3">
                        <a href="<?php echo $farmacia['redes_sociales']['facebook'] ?? '#'; ?>" 
                           class="text-muted me-3" target="_blank" title="Facebook">
                            <i class="fab fa-facebook-f fa-lg"></i>
                        </a>
                        <a href="<?php echo $farmacia['redes_sociales']['instagram'] ?? '#'; ?>" 
                           class="text-muted me-3" target="_blank" title="Instagram">
                            <i class="fab fa-instagram fa-lg"></i>
                        </a>
                        <a href="https://wa.me/<?php echo str_replace(['+', ' '], '', $farmacia['redes_sociales']['whatsapp'] ?? $farmacia['telefono']); ?>" 
                           class="text-success" target="_blank" title="WhatsApp">
                            <i class="fab fa-whatsapp fa-lg"></i>
                        </a>
                    </div>

                    <div class="mt-4">
                        <h6 class="text-success mb-3">Newsletter</h6>
                        <p class="text-muted small">Recibe ofertas y consejos de salud</p>
                        <form class="newsletter-form">
                            <div class="input-group input-group-sm">
                                <input type="email" class="form-control" placeholder="Tu email">
                                <button class="btn btn-success" type="submit">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <hr class="my-0 border-secondary">

        <div class="container py-3">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="text-muted small mb-0">
                        © <?php echo date('Y'); ?> <?php echo $farmacia['nombre']; ?>. 
                        Todos los derechos reservados.
                    </p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="text-muted small mb-0">
                        Versión <?php echo $config['sistema']['version'] ?? '1.0.0'; ?> | 
                       
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <a href="https://wa.me/<?php echo str_replace(['+', ' '], '', $farmacia['redes_sociales']['whatsapp'] ?? $farmacia['telefono']); ?>?text=<?php echo urlencode('Hola, tengo una consulta sobre sus productos'); ?>" 
       class="whatsapp-float" target="_blank" title="Chatea con nosotros">
        <i class="fab fa-whatsapp"></i>
    </a>

    <div id="chatbot-widget">
        <div id="chatbot-button" class="chatbot-button" onclick="toggleChatbot()">
            <i class="fas fa-comments"></i>
        </div>
        <div id="chatbot-container" class="chatbot-container" style="display: none;">
            <div class="chatbot-header">
                <h6 class="mb-0">Asistente Virtual</h6>
                <button onclick="toggleChatbot()" class="btn-close-chat">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div id="chatbot-messages" class="chatbot-messages">
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <?php if (basename($_SERVER['PHP_SELF']) == 'carrito.php' || basename($_SERVER['PHP_SELF']) == 'catalogo.php' || basename($_SERVER['PHP_SELF']) == 'index.php'): ?>
        <script src="assets/js/carrito.js"></script>
    <?php endif; ?>

    <?php if (file_exists('assets/js/main.js')): ?>
        <script src="assets/js/main.js"></script>
    <?php endif; ?>
    
    <?php if (file_exists('assets/js/chatbot.js')): ?>
        <script src="assets/js/chatbot.js"></script>
    <?php endif; ?>

    <!-- FUNCIONALIDAD CATEGORÍAS INTELIGENTE -->
    <script>
    // Variables globales para categorías
    let categoriesOpen = false;

    // Función para toggle de categorías
    function toggleCategories() {
        const panel = document.getElementById('categoriesPanel');
        const btn = document.getElementById('categoriesBtn');
        
        if (!categoriesOpen) {
            showCategories();
        } else {
            hideCategories();
        }
    }

    function showCategories() {
    const panel = document.getElementById('categoriesPanel');
    
    if (!panel) {
        console.error('Panel de categorías no encontrado');
        return;
    }
    
    // Crear overlay
    createOverlay();
    
    // Mostrar panel
    panel.classList.add('show');
    
    // Prevenir scroll del body
    document.body.style.overflow = 'hidden';
    document.body.classList.add('categories-active');
    
    categoriesOpen = true;
    console.log('✅ Panel de categorías abierto');
}

   function hideCategories() {
    const panel = document.getElementById('categoriesPanel');
    const overlay = document.getElementById('categoriesOverlay');
    
    if (panel) {
        panel.classList.remove('show');
    }
    
    // IMPORTANTE: Restaurar scroll del body
    document.body.style.overflow = '';
    document.body.classList.remove('categories-active');
    
    // Remover overlay completamente
    if (overlay) {
        overlay.classList.remove('show');
        setTimeout(() => {
            if (overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
            }
        }, 300);
    }
    
    categoriesOpen = false;
    console.log('✅ Panel de categorías cerrado y overlay limpiado');
}

    function createOverlay() {
        if (!document.getElementById('categoriesOverlay')) {
            const overlay = document.createElement('div');
            overlay.id = 'categoriesOverlay';
            overlay.className = 'categories-overlay';
            overlay.addEventListener('click', hideCategories);
            document.body.appendChild(overlay);
            
            setTimeout(() => {
                overlay.classList.add('show');
            }, 50);
        }
    }

    // Event listeners
    document.addEventListener('DOMContentLoaded', function() {
        // Bootstrap dropdowns
        var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'));
        var dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
            return new bootstrap.Dropdown(dropdownToggleEl);
        });
        
        console.log('✅ Bootstrap dropdowns inicializados:', dropdownList.length);
        
        // Chatbot function
        if (typeof toggleChatbot !== 'function') {
            window.toggleChatbot = function() {
                const container = document.getElementById('chatbot-container');
                const button = document.getElementById('chatbot-button');
                
                if (container && button) {
                    if (container.style.display === 'none') {
                        container.style.display = 'block';
                        button.innerHTML = '<i class="fas fa-times"></i>';
                    } else {
                        container.style.display = 'none';
                        button.innerHTML = '<i class="fas fa-comments"></i>';
                    }
                }
            };
            console.log('✅ Función toggleChatbot creada');
        }
        
        // Newsletter form
        const newsletterForm = document.querySelector('.newsletter-form');
        if (newsletterForm) {
            newsletterForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const email = this.querySelector('input[type="email"]').value;
                if (email) {
                    alert('¡Gracias por suscribirte! Pronto recibirás nuestras ofertas.');
                    this.querySelector('input[type="email"]').value = '';
                }
            });
        }
        
        // Inicializar botón de categorías para móvil
        const btn = document.getElementById('categoriesBtn');
        if (btn && window.innerWidth <= 480) {
            btn.innerHTML = '<i class="fas fa-th-large"></i>';
        }
        
        console.log('✅ Sistema de categorías inteligente cargado');
    });

    // Cerrar categorías con ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && categoriesOpen) {
            hideCategories();
        }
    });

    // Responsive - ajustar botón en resize
    window.addEventListener('resize', function() {
        const btn = document.getElementById('categoriesBtn');
        if (btn) {
            if (window.innerWidth <= 480) {
                if (categoriesOpen) {
                    btn.innerHTML = '<i class="fas fa-times"></i>';
                } else {
                    btn.innerHTML = '<i class="fas fa-th-large"></i>';
                }
            } else {
                if (categoriesOpen) {
                    btn.innerHTML = '<i class="fas fa-times me-2"></i><span>Cerrar</span><i class="fas fa-chevron-up ms-2"></i>';
                } else {
                    btn.innerHTML = '<i class="fas fa-th-large me-2"></i><span>Categorías</span><i class="fas fa-chevron-down ms-2"></i>';
                }
            }
        }
    });
    </script>

</body>
</html>