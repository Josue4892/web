<?php
// Incluir configuración de base de datos
require_once __DIR__ . '/../config/database.php';

function iniciarSesion() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
}

// Verificar si el usuario está logueado
function estaLogueado() {
    iniciarSesion();
    return isset($_SESSION['usuario_id']);
}

// Verificar si el usuario es administrador
function esAdmin() {
    iniciarSesion();
    return isset($_SESSION['rol_id']) && $_SESSION['rol_id'] == 1;
}

// Obtener datos del usuario logueado
function obtenerUsuarioActual() {
    iniciarSesion();
    if (estaLogueado()) {
        return [
            'id' => $_SESSION['usuario_id'],
            'nombre' => $_SESSION['usuario_nombre'],
            'email' => $_SESSION['usuario_email'],
            'rol_id' => $_SESSION['rol_id']
        ];
    }
    return null;
}

// Cerrar sesión
function cerrarSesion() {
    iniciarSesion();
    session_destroy();
    header('Location: login_viejo.php');
    exit();
}

// Redirigir si no está logueado
function requireLogin() {
    if (!estaLogueado()) {
        header('Location: login_viejo.php');
        exit();
    }
}

// Redirigir si no es admin
function requireAdmin() {
    if (!esAdmin()) {
        header('Location: index.php');
        exit();
    }
}

// Obtener todos los productos
function obtenerProductos($categoria_id = null, $busqueda = null, $limite = null) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return [];
        }
        
        $query = "SELECT p.*, c.nombre as categoria_nombre 
                  FROM productos p 
                  LEFT JOIN categorias c ON p.categoria_id = c.id 
                  WHERE 1=1";
        $params = [];
        
        if ($categoria_id) {
            $query .= " AND p.categoria_id = ?";
            $params[] = $categoria_id;
        }
        
        if ($busqueda) {
            $query .= " AND (p.nombre LIKE ? OR p.descripcion LIKE ?)";
            $params[] = "%$busqueda%";
            $params[] = "%$busqueda%";
        }
        
        $query .= " ORDER BY p.nombre ASC";
        
        if ($limite) {
            $query .= " LIMIT ?";
            $params[] = $limite;
        }
        
        $result = $db->select($query, $params);
        return $result ? $result : [];
        
    } catch (Exception $e) {
        error_log("Error en obtenerProductos: " . $e->getMessage());
        return [];
    }
}

// Obtener un producto por ID
function obtenerProductoPorId($id) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return null;
        }
        
        $query = "SELECT p.*, c.nombre as categoria_nombre 
                  FROM productos p 
                  LEFT JOIN categorias c ON p.categoria_id = c.id 
                  WHERE p.id = ?";
        $resultado = $db->select($query, [$id]);
        return $resultado ? $resultado[0] : null;
        
    } catch (Exception $e) {
        error_log("Error en obtenerProductoPorId: " . $e->getMessage());
        return null;
    }
}

// Obtener todas las categorías
function obtenerCategorias() {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return [];
        }
        
        $result = $db->select("SELECT * FROM categorias ORDER BY nombre ASC");
        return $result ? $result : [];
        
    } catch (Exception $e) {
        error_log("Error en obtenerCategorias: " . $e->getMessage());
        return [];
    }
}

// Obtener categoría por ID
function obtenerCategoriaPorId($id) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return null;
        }
        
        $resultado = $db->select("SELECT * FROM categorias WHERE id = ?", [$id]);
        return $resultado ? $resultado[0] : null;
        
    } catch (Exception $e) {
        error_log("Error en obtenerCategoriaPorId: " . $e->getMessage());
        return null;
    }
}

// Validar login
function validarLogin($email, $password) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return false;
        }
        
        $query = "SELECT * FROM usuarios WHERE email = ? AND password = MD5(?)";
        $resultado = $db->select($query, [$email, $password]);
        
        if ($resultado && count($resultado) > 0) {
            $usuario = $resultado[0];
            iniciarSesion();
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nombre'] = $usuario['nombre'];
            $_SESSION['usuario_email'] = $usuario['email'];
            $_SESSION['rol_id'] = $usuario['rol_id'];
            return true;
        }
        return false;
        
    } catch (Exception $e) {
        error_log("Error en validarLogin: " . $e->getMessage());
        return false;
    }
}

// Registrar nuevo usuario
function registrarUsuario($nombre, $email, $telefono, $password) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return false;
        }
        
        // Verificar si el email ya existe
        $emailExiste = $db->select("SELECT id FROM usuarios WHERE email = ?", [$email]);
        if ($emailExiste && count($emailExiste) > 0) {
            return false; // Email ya registrado
        }
        
        $query = "INSERT INTO usuarios (nombre, email, telefono, password, rol_id) 
                  VALUES (?, ?, ?, MD5(?), 2)";
        return $db->execute($query, [$nombre, $email, $telefono, $password]);
        
    } catch (Exception $e) {
        error_log("Error en registrarUsuario: " . $e->getMessage());
        return false;
    }
}

function contarProductosCarrito() {
    return 0;
}

// Formatear precio en soles
function formatearPrecio($precio) {
    return "S/ " . number_format($precio, 2);
}

function sanitizar($texto) {
    return htmlspecialchars(strip_tags(trim($texto)));
}

function generarCSRF() {
    iniciarSesion();
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verificarCSRF($token) {
    iniciarSesion();
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function redirigirConMensaje($url, $mensaje, $tipo = 'success') {
    iniciarSesion();
    $_SESSION['mensaje'] = $mensaje;
    $_SESSION['tipo_mensaje'] = $tipo;
    header("Location: $url");
    exit();
}

function mostrarMensaje() {
    iniciarSesion();
    if (isset($_SESSION['mensaje'])) {
        $mensaje = $_SESSION['mensaje'];
        $tipo = $_SESSION['tipo_mensaje'] ?? 'info';
        
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                if (typeof mostrarAlerta === 'function') {
                    mostrarAlerta('" . addslashes($mensaje) . "', '$tipo');
                }
            });
        </script>";
        
        unset($_SESSION['mensaje']);
        unset($_SESSION['tipo_mensaje']);
    }
}


function cargarConfiguracion() {
    try {
        $configPath = 'config/settings.json';
        if (file_exists($configPath)) {
            $config = file_get_contents($configPath);
            return json_decode($config, true);
        }
        return [];
    } catch (Exception $e) {
        error_log("Error al cargar configuración: " . $e->getMessage());
        return [];
    }
}

function obtenerConfig($clave) {
    $config = cargarConfiguracion();
    $claves = explode('.', $clave);
    $valor = $config;
    
    foreach ($claves as $key) {
        if (isset($valor[$key])) {
            $valor = $valor[$key];
        } else {
            return null;
        }
    }
    
    return $valor;
}

// Validar email
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Validar teléfono peruano
function validarTelefono($telefono) {
    return preg_match('/^[0-9]{9}$/', $telefono);
}

// Validar password
function validarPassword($password) {
    return strlen($password) >= 6;
}

// Obtener imagen del producto
function obtenerImagenProducto($nombre_imagen) {
    $ruta = "assets/images/productos/" . $nombre_imagen;
    
    // Si la imagen existe, la devuelve, sino una por defecto
    if (file_exists($ruta)) {
        return $ruta;
    } else {
        return "assets/images/productos/producto_default.jpg";
    }
}
?>