<?php
require_once 'includes/functions.php';
iniciarSesion();

$config = cargarConfiguracion();
$farmacia = $config['farmacia'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($titulo_pagina) ? $titulo_pagina . ' - ' : ''; ?><?php echo $farmacia['nombre']; ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <link href="assets/css/style.css" rel="stylesheet">
    
    <meta name="description" content="<?php echo $farmacia['slogan']; ?> - Medicamentos, productos de belleza y cuidado personal en <?php echo $farmacia['nombre']; ?>">
    <meta name="keywords" content="farmacia, medicamentos, belleza, cuidado personal, Lima, Peru">
    <meta name="author" content="<?php echo $farmacia['nombre']; ?>">
</head>
<body>
    <!-- BOTÓN DE CATEGORÍAS COMPLETAMENTE INDEPENDIENTE -->
    

    <!-- Panel de categorías independiente -->
    <div class="categories-panel" id="categoriesPanel">
        <div class="categories-content">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="d-flex flex-wrap justify-content-center">
                            <a href="catalogo.php" class="btn btn-outline-success btn-sm me-2 mb-2">
                                <i class="fas fa-th-large me-1"></i>Todos
                            </a>
                            <?php
                            $categorias = obtenerCategorias();
                            foreach ($categorias as $categoria):
                            ?>
                            <a href="catalogo.php?categoria=<?php echo $categoria['id']; ?>" 
                               class="btn btn-outline-success btn-sm me-2 mb-2">
                                <?php echo $categoria['nombre']; ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <header class="main-header">
        <div class="top-bar bg-primary text-white py-2">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <small>
                            <i class="fas fa-phone me-2"></i><?php echo $farmacia['telefono']; ?>
                            <span class="mx-3">|</span>
                            <i class="fas fa-envelope me-2"></i><?php echo $farmacia['email']; ?>
                        </small>
                    </div>
                    <div class="col-md-6 text-end">
                        <small>
                            <i class="fas fa-clock me-2"></i>
                            Lun-Vie: <?php echo $farmacia['horarios']['lunes_viernes']; ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <img src="assets/images/logo.png" alt="<?php echo $farmacia['nombre']; ?>" height="50">
                    <span class="fw-bold text-success ms-2"><?php echo $farmacia['nombre']; ?></span>
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <div class="mx-auto d-none d-lg-block">
                        <form class="d-flex search-form" action="catalogo.php" method="GET">
                            <div class="input-group">
                                <input class="form-control" type="search" name="busqueda" 
                                       placeholder="Buscar medicamentos, productos..." 
                                       value="<?php echo isset($_GET['busqueda']) ? sanitizar($_GET['busqueda']) : ''; ?>">
                                <button class="btn btn-success" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </form>
                    </div>

                      <ul class="navbar-nav ms-auto">
                        <!-- Botón de Categorías integrado en el navbar -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="categoriesDropdown" role="button" 
                               data-bs-toggle="dropdown" aria-expanded="false" onclick="toggleCategories()">
                                <i class="fas fa-th-large me-1"></i>Categorías
                            </a>
                            
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="fas fa-home me-1"></i>Inicio
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="catalogo.php">
                                <i class="fas fa-pills me-1"></i>Productos
                            </a>
                        </li>   
                        

                        <?php if (estaLogueado()): ?>
                            <?php $usuario = obtenerUsuarioActual(); ?>
                            
                             <!-- Carrito -->
                            <li class="nav-item">
                                <a class="nav-link position-relative" href="carrito.php">
                                    <i class="fas fa-shopping-cart me-1"></i>Carrito
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="contador-carrito">
                                        0
                                    </span>
                                </a>
                            </li>

                            <!-- Menú usuario -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" 
                                   data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user me-1"></i><?php echo $usuario['nombre']; ?>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="perfil.php">
                                        <i class="fas fa-user-circle me-2"></i>Mi Perfil
                                    </a></li>
                                    <li><a class="dropdown-item" href="perfil.php#historial">
                                        <i class="fas fa-history me-2"></i>Mis Compras
                                    </a></li>
                                    <?php if (esAdmin()): ?>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item text-primary" href="admin.php">
                                            <i class="fas fa-cog me-2"></i>Panel Admin
                                        </a></li>
                                    <?php endif; ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-danger" href="auth/logout.php">
                                        <i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión
                                    </a></li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <!-- Usuario no logueado -->
                            <li class="nav-item">
                                <a class="nav-link" href="login_viejo.php">
                                    <i class="fas fa-sign-in-alt me-1"></i>Ingresar
                                </a>
            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="container mt-3">
        <?php mostrarMensaje(); ?>
    </div>

    <main class="main-content">