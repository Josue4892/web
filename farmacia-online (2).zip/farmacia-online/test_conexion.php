<?php
// test_connection.php - Verificador Completo para FarmaPlus
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>🔧 Test FarmaPlus - Verificador Completo</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css' rel='stylesheet'>
    <style>
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .test-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin: 20px auto;
            max-width: 1200px;
        }
        .test-header {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            padding: 30px;
            border-radius: 15px 15px 0 0;
            text-align: center;
        }
        .test-section {
            margin: 20px 0;
            padding: 20px;
            border-left: 4px solid #28a745;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .success { color: #28a745; font-weight: bold; }
        .error { color: #dc3545; font-weight: bold; }
        .warning { color: #ffc107; font-weight: bold; }
        .info { color: #17a2b8; font-weight: bold; }
        .test-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .test-card {
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .progress-custom {
            height: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .table-responsive {
            max-height: 300px;
            overflow-y: auto;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-success { background: #d4edda; color: #155724; }
        .status-error { background: #f8d7da; color: #721c24; }
        .status-warning { background: #fff3cd; color: #856404; }
    </style>
</head>
<body>";

echo "<div class='test-container'>
    <div class='test-header'>
        <h1><i class='fas fa-stethoscope'></i> FarmaPlus System Health Check</h1>
        <p class='mb-0'>Verificador completo de sistema - Versión 2.0</p>
        <small>Generado: " . date('d/m/Y H:i:s') . "</small>
    </div>
    <div class='container-fluid p-4'>";

// Contadores globales
$total_tests = 0;
$passed_tests = 0;
$failed_tests = 0;
$warnings = 0;

function testResult($condition, $successMsg, $errorMsg, $warningMsg = null) {
    global $total_tests, $passed_tests, $failed_tests, $warnings;
    $total_tests++;
    
    if ($condition === true) {
        $passed_tests++;
        return "<span class='success'><i class='fas fa-check-circle'></i> $successMsg</span>";
    } elseif ($condition === false) {
        $failed_tests++;
        return "<span class='error'><i class='fas fa-times-circle'></i> $errorMsg</span>";
    } else {
        $warnings++;
        return "<span class='warning'><i class='fas fa-exclamation-triangle'></i> $warningMsg</span>";
    }
}

// =================================
// 1. VERIFICACIÓN DE ARCHIVOS CORE
// =================================
echo "<div class='test-section'>
<h3><i class='fas fa-file-code'></i> 1. Verificación de Archivos Core</h3>";

$core_files = [
    'config/database.php' => 'Configuración de BD',
    'includes/functions.php' => 'Funciones principales',
    'includes/header.php' => 'Header del sitio',
    'includes/footer.php' => 'Footer del sitio',
    'admin.php' => 'Panel administrativo',
    'index.php' => 'Página principal'
];

echo "<div class='test-grid'>";
foreach ($core_files as $file => $description) {
    $exists = file_exists($file);
    echo "<div class='test-card'>
        <h6>$description</h6>
        <code>$file</code><br>
        " . testResult($exists, "Archivo existe", "Archivo no encontrado") . "
    </div>";
}
echo "</div></div>";

// =================================
// 2. VERIFICACIÓN DE CONFIGURACIÓN BD
// =================================
echo "<div class='test-section'>
<h3><i class='fas fa-database'></i> 2. Configuración de Base de Datos</h3>";

if (file_exists('config/database.php')) {
    include_once 'config/database.php';
    
    echo "<div class='test-grid'>
        <div class='test-card'>
            <h6>Constantes Definidas</h6>";
    
    $constants = ['DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASS'];
    foreach ($constants as $const) {
        $defined = defined($const);
        echo testResult($defined, "$const definida", "$const no definida") . "<br>";
    }
    
    echo "</div><div class='test-card'>
            <h6>Valores de Configuración</h6>";
    if (defined('DB_HOST')) echo "<strong>Host:</strong> " . DB_HOST . "<br>";
    if (defined('DB_PORT')) echo "<strong>Puerto:</strong> " . DB_PORT . "<br>";
    if (defined('DB_NAME')) echo "<strong>Base de Datos:</strong> " . DB_NAME . "<br>";
    if (defined('DB_USER')) echo "<strong>Usuario:</strong> " . DB_USER . "<br>";
    if (defined('DB_PASS')) echo "<strong>Contraseña:</strong> " . (empty(DB_PASS) ? "Sin contraseña" : "Configurada") . "<br>";
    echo "</div></div>";
} else {
    echo testResult(false, "", "config/database.php no encontrado");
}

echo "</div>";

// =================================
// 3. PRUEBAS DE CONEXIÓN
// =================================
echo "<div class='test-section'>
<h3><i class='fas fa-plug'></i> 3. Pruebas de Conexión a Base de Datos</h3>";

$db_connection_ok = false;
$database = null;

if (class_exists('Database')) {
    echo testResult(true, "Clase Database encontrada", "Clase Database no encontrada") . "<br>";
    
    try {
        $database = new Database();
        echo testResult(true, "Instancia de Database creada", "Error creando instancia") . "<br>";
        
        $conn = $database->getConnection();
        if ($conn) {
            $db_connection_ok = true;
            echo testResult(true, "Conexión PDO establecida exitosamente", "No se pudo obtener conexión") . "<br>";
            
            // Test de funciones de Database
            $methods = ['select', 'execute', 'lastInsertId', 'closeConnection'];
            echo "<div class='mt-3'><h6>Métodos de Database:</h6>";
            foreach ($methods as $method) {
                $exists = method_exists($database, $method);
                echo testResult($exists, "Método $method() existe", "Método $method() no existe") . "<br>";
            }
            echo "</div>";
            
        } else {
            echo testResult(false, "", "Conexión falló - Verificar credenciales") . "<br>";
        }
    } catch (Exception $e) {
        echo testResult(false, "", "Error: " . $e->getMessage()) . "<br>";
    }
} else {
    echo testResult(false, "", "Clase Database no encontrada") . "<br>";
}

echo "</div>";

// =================================
// 4. VERIFICACIÓN DE TABLAS
// =================================
if ($db_connection_ok && $database) {
    echo "<div class='test-section'>
    <h3><i class='fas fa-table'></i> 4. Verificación de Estructura de Base de Datos</h3>";
    
    // Verificar que la BD existe y mostrar todas las tablas
    try {
        $tables_result = $database->select("SHOW TABLES");
        $tables = array_map(function($row) { return array_values($row)[0]; }, $tables_result);
        
        echo "<div class='test-grid'>
            <div class='test-card'>
                <h6>Tablas Encontradas (" . count($tables) . ")</h6>";
        
        $required_tables = ['usuarios', 'productos', 'categorias', 'pedidos', 'detalle_pedidos', 'roles'];
        
        foreach ($required_tables as $table) {
            $exists = in_array($table, $tables);
            echo testResult($exists, "Tabla '$table' existe", "Tabla '$table' no encontrada") . "<br>";
        }
        
        echo "</div><div class='test-card'>
                <h6>Todas las Tablas</h6>";
        foreach ($tables as $table) {
            echo "<span class='status-badge status-success'>$table</span> ";
        }
        echo "</div></div>";
        
        // Verificar registros en cada tabla
        echo "<div class='test-card mt-3'>
            <h6>Conteo de Registros por Tabla</h6>
            <div class='table-responsive'>
                <table class='table table-sm'>
                    <thead>
                        <tr>
                            <th>Tabla</th>
                            <th>Registros</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>";
        
        foreach ($required_tables as $table) {
            if (in_array($table, $tables)) {
                try {
                    $count_result = $database->select("SELECT COUNT(*) as total FROM $table");
                    $count = $count_result[0]['total'];
                    $status = $count > 0 ? 'success' : 'warning';
                    $icon = $count > 0 ? 'check' : 'exclamation-triangle';
                    
                    echo "<tr>
                        <td><code>$table</code></td>
                        <td><strong>$count</strong></td>
                        <td><i class='fas fa-$icon text-" . ($count > 0 ? 'success' : 'warning') . "'></i></td>
                    </tr>";
                } catch (Exception $e) {
                    echo "<tr>
                        <td><code>$table</code></td>
                        <td colspan='2'><span class='text-danger'>Error: " . $e->getMessage() . "</span></td>
                    </tr>";
                }
            }
        }
        
        echo "</tbody></table></div></div>";
        
    } catch (Exception $e) {
        echo testResult(false, "", "Error verificando tablas: " . $e->getMessage());
    }
    
    echo "</div>";
}

// =================================
// 5. VERIFICACIÓN DE APIs
// =================================
echo "<div class='test-section'>
<h3><i class='fas fa-cloud'></i> 5. Verificación de APIs</h3>";

$api_files = [
    'api/productos.php' => 'Gestión de productos',
    'api/carrito.php' => 'Gestión del carrito',
    'api/usuarios.php' => 'Gestión de usuarios',
    'api/pedidos.php' => 'Gestión de pedidos',
    'api/categorias.php' => 'Gestión de categorías'
];

echo "<div class='test-grid'>";
foreach ($api_files as $file => $description) {
    $exists = file_exists($file);
    echo "<div class='test-card'>
        <h6>$description</h6>
        <code>$file</code><br>
        " . testResult($exists, "API disponible", "API no encontrada") . "<br>";
    
    if ($exists) {
        // Test básico de respuesta HTTP
        $url = "http://localhost:" . (defined('DB_PORT') ? DB_PORT : '3000') . "/$file";
        echo "<small class='text-muted'>URL: $url</small>";
    }
    echo "</div>";
}
echo "</div></div>";

// =================================
// 6. VERIFICACIÓN DE FUNCIONES
// =================================
if (file_exists('includes/functions.php')) {
    echo "<div class='test-section'>
    <h3><i class='fas fa-cogs'></i> 6. Verificación de Funciones Core</h3>";
    
    include_once 'includes/functions.php';
    
    $core_functions = [
        'conectarDB' => 'Conexión rápida a BD',
        'obtenerProductos' => 'Obtener lista de productos',
        'obtenerCategorias' => 'Obtener categorías',
        'formatearPrecio' => 'Formatear precios',
        'esAdmin' => 'Verificar administrador',
        'obtenerUsuarioActual' => 'Usuario actual',
        'redirigirConMensaje' => 'Redirección con mensaje'
    ];
    
    echo "<div class='test-grid'>";
    foreach ($core_functions as $func => $description) {
        $exists = function_exists($func);
        echo "<div class='test-card'>
            <h6>$description</h6>
            <code>$func()</code><br>
            " . testResult($exists, "Función disponible", "Función no encontrada") . "
        </div>";
    }
    echo "</div></div>";
}

// =================================
// 7. TEST DE OPERACIONES CRUD
// =================================
if ($db_connection_ok && $database) {
    echo "<div class='test-section'>
    <h3><i class='fas fa-tools'></i> 7. Test de Operaciones CRUD</h3>";
    
    echo "<div class='test-grid'>";
    
    // Test SELECT
    echo "<div class='test-card'>
        <h6>Test SELECT</h6>";
    try {
        $test_select = $database->select("SELECT 1 as test_column");
        $select_ok = $test_select && $test_select[0]['test_column'] == 1;
        echo testResult($select_ok, "SELECT funciona correctamente", "SELECT tiene problemas");
    } catch (Exception $e) {
        echo testResult(false, "", "Error en SELECT: " . $e->getMessage());
    }
    echo "</div>";
    
    // Test INSERT/UPDATE/DELETE (si hay tabla de prueba)
    echo "<div class='test-card'>
        <h6>Test CRUD Básico</h6>";
    try {
        // Intentar crear tabla temporal
        $database->execute("CREATE TEMPORARY TABLE test_crud (id INT AUTO_INCREMENT PRIMARY KEY, test_data VARCHAR(50))");
        
        // INSERT
        $insert_ok = $database->execute("INSERT INTO test_crud (test_data) VALUES (?)", ['test_value']);
        echo testResult($insert_ok, "INSERT funciona", "INSERT falló") . "<br>";
        
        // UPDATE
        $update_ok = $database->execute("UPDATE test_crud SET test_data = ? WHERE test_data = ?", ['updated_value', 'test_value']);
        echo testResult($update_ok, "UPDATE funciona", "UPDATE falló") . "<br>";
        
        // DELETE
        $delete_ok = $database->execute("DELETE FROM test_crud WHERE test_data = ?", ['updated_value']);
        echo testResult($delete_ok, "DELETE funciona", "DELETE falló") . "<br>";
        
    } catch (Exception $e) {
        echo testResult(false, "", "Error en CRUD: " . $e->getMessage());
    }
    echo "</div>";
    
    echo "</div></div>";
}

// =================================
// 8. RESUMEN FINAL
// =================================
echo "<div class='test-section'>
<h3><i class='fas fa-chart-pie'></i> 8. Resumen Final</h3>";

$success_rate = $total_tests > 0 ? round(($passed_tests / $total_tests) * 100, 1) : 0;

echo "<div class='test-grid'>
    <div class='test-card text-center'>
        <h4 class='text-success'>$passed_tests</h4>
        <p>Tests Exitosos</p>
    </div>
    <div class='test-card text-center'>
        <h4 class='text-danger'>$failed_tests</h4>
        <p>Tests Fallidos</p>
    </div>
    <div class='test-card text-center'>
        <h4 class='text-warning'>$warnings</h4>
        <p>Advertencias</p>
    </div>
    <div class='test-card text-center'>
        <h4 class='text-info'>$success_rate%</h4>
        <p>Tasa de Éxito</p>
    </div>
</div>";

echo "<div class='progress progress-custom'>
    <div class='progress-bar bg-success' style='width: {$success_rate}%'></div>
</div>";

// Diagnóstico y recomendaciones
echo "<div class='test-card mt-3'>
    <h5>🎯 Diagnóstico General:</h5>";

if ($success_rate >= 90) {
    echo "<div class='alert alert-success'>
        <i class='fas fa-check-circle'></i> <strong>¡Excelente!</strong> El sistema está funcionando correctamente. Puedes usar admin.php sin problemas.
    </div>";
} elseif ($success_rate >= 70) {
    echo "<div class='alert alert-warning'>
        <i class='fas fa-exclamation-triangle'></i> <strong>Funcionamiento parcial.</strong> Hay algunos problemas menores que deberían solucionarse.
    </div>";
} else {
    echo "<div class='alert alert-danger'>
        <i class='fas fa-times-circle'></i> <strong>Problemas críticos detectados.</strong> Es necesario revisar la configuración antes de usar el sistema.
    </div>";
}

echo "<h6>📋 Recomendaciones:</h6><ul>";

if ($failed_tests > 0) {
    echo "<li>Revisar los tests fallidos marcados en rojo</li>";
}
if (!$db_connection_ok) {
    echo "<li>Verificar que MySQL esté corriendo en el puerto configurado</li>";
    echo "<li>Confirmar credenciales de base de datos</li>";
}
if ($warnings > 0) {
    echo "<li>Atender las advertencias para optimizar el funcionamiento</li>";
}

echo "<li>Si todo está verde, eliminar este archivo por seguridad</li>";
echo "<li>Hacer backup de la base de datos regularmente</li>";
echo "</ul></div>";

echo "</div>";

// Footer
echo "<div class='text-center mt-4 pt-4 border-top'>
    <p class='text-muted'>
        <i class='fas fa-code'></i> Test realizado para FarmaPlus | 
        <i class='fas fa-clock'></i> " . date('d/m/Y H:i:s') . " | 
        <i class='fas fa-server'></i> PHP " . phpversion() . "
    </p>
    <p class='text-muted'><small>
        <strong>Nota de seguridad:</strong> Elimina este archivo después de verificar que todo funciona correctamente.
    </small></p>
</div>";

echo "</div></div></body></html>";
?>