-- Crear base de datos
CREATE DATABASE IF NOT EXISTS farmacia_db;
USE farmacia_db;

-- Tabla roles
CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL
);

-- Tabla usuarios
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL,
    rol_id INT DEFAULT 2,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (rol_id) REFERENCES roles(id)
);

-- Tabla categorías
CREATE TABLE categorias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT
);

-- Tabla productos
CREATE TABLE productos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    categoria_id INT,
    imagen VARCHAR(255),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

-- Tabla pedidos
CREATE TABLE pedidos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    estado VARCHAR(50) DEFAULT 'pendiente',
    fecha_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabla detalle de pedidos
CREATE TABLE detalle_pedidos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    pedido_id INT NOT NULL,
    producto_id INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- Insertar datos iniciales
INSERT INTO roles (nombre) VALUES 
('administrador'), 
('cliente');

-- 7 Categorías
INSERT INTO categorias (nombre, descripcion) VALUES 
('Medicamentos', 'Medicamentos generales y de venta libre'),
('Belleza y Cuidado', 'Productos de cuidado personal y belleza'),
('Bebés y Niños', 'Productos para el cuidado de bebés y niños'),
('Vitaminas y Suplementos', 'Suplementos vitamínicos y nutricionales'),
('Higiene Personal', 'Productos de higiene y cuidado diario'),
('Primeros Auxilios', 'Productos para emergencias y primeros auxilios'),
('Cuidado del Hogar', 'Productos de limpieza y desinfección');

-- Usuario administrador por defecto
INSERT INTO usuarios (nombre, email, telefono, password, rol_id) VALUES 
('Administrador', 'admin@farmacia.com', '999888777', MD5('admin123'), 1);

-- 28 Productos (4 por categoría)
INSERT INTO productos (nombre, descripcion, precio, stock, categoria_id, imagen) VALUES 

-- Medicamentos (Categoría 1)
('Paracetamol 500mg', 'Analgésico y antipirético de uso general', 5.50, 100, 1, 'paracetamol.jpg'),
('Ibuprofeno 400mg', 'Antiinflamatorio y analgésico', 8.90, 80, 1, 'ibuprofeno.jpg'),
('Aspirina 100mg', 'Antiagregante plaquetario', 12.00, 60, 1, 'aspirina.jpg'),
('Omeprazol 20mg', 'Protector gástrico', 15.50, 70, 1, 'omeprazol.jpg'),

-- Belleza y Cuidado (Categoría 2)
('Crema Hidratante Nivea', 'Crema para piel seca y sensible', 25.00, 50, 2, 'crema_nivea.jpg'),
('Protector Solar FPS 50', 'Protección solar de amplio espectro', 35.00, 40, 2, 'protector_solar.jpg'),
('Shampoo Anticaspa', 'Shampoo medicado para caspa', 18.50, 45, 2, 'shampoo_anticaspa.jpg'),
('Sérum Facial Vitamina C', 'Sérum antioxidante para el rostro', 42.00, 30, 2, 'serum_vitamina_c.jpg'),

-- Bebés y Niños (Categoría 3)
('Pañales Huggies Talla M', 'Pañales ultra absorbentes', 28.00, 35, 3, 'panales_huggies.jpg'),
('Leche Nan Pro 1', 'Fórmula infantil para bebés', 45.00, 25, 3, 'leche_nan.jpg'),
('Crema para Pañalitis', 'Crema protectora contra irritaciones', 16.00, 55, 3, 'crema_panalitis.jpg'),
('Termómetro Digital', 'Termómetro infrarrojo para bebés', 65.00, 20, 3, 'termometro_digital.jpg'),

-- Vitaminas y Suplementos (Categoría 4)
('Vitamina C 1000mg', 'Suplemento vitamínico antioxidante', 35.00, 60, 4, 'vitamina_c.jpg'),
('Multivitamínico Centrum', 'Complejo vitamínico completo', 55.00, 40, 4, 'centrum.jpg'),
('Omega 3', 'Suplemento de ácidos grasos esenciales', 48.00, 35, 4, 'omega_3.jpg'),
('Calcio + Vitamina D', 'Suplemento para huesos fuertes', 32.00, 45, 4, 'calcio_vitamina_d.jpg'),

-- Higiene Personal (Categoría 5)
('Pasta Dental Colgate', 'Pasta dental con flúor', 8.50, 80, 5, 'pasta_colgate.jpg'),
('Jabón Antibacterial', 'Jabón líquido para manos', 12.00, 70, 5, 'jabon_antibacterial.jpg'),
('Desodorante Rexona', 'Desodorante antitranspirante', 15.00, 60, 5, 'desodorante_rexona.jpg'),
('Enjuague Bucal Listerine', 'Enjuague bucal antiséptico', 18.00, 50, 5, 'listerine.jpg'),

-- Primeros Auxilios (Categoría 6)
('Vendas Elásticas', 'Vendas para inmovilización', 8.00, 90, 6, 'vendas_elasticas.jpg'),
('Alcohol 70°', 'Alcohol antiséptico', 6.50, 100, 6, 'alcohol_70.jpg'),
('Gasas Estériles', 'Gasas para curación', 5.00, 120, 6, 'gasas_esteriles.jpg'),
('Agua Oxigenada', 'Antiséptico para heridas', 4.50, 85, 6, 'agua_oxigenada.jpg'),

-- Cuidado del Hogar (Categoría 7)
('Lysol Desinfectante', 'Spray desinfectante multiusos', 22.00, 40, 7, 'lysol.jpg'),
('Alcohol en Gel', 'Gel antibacterial para manos', 8.00, 75, 7, 'alcohol_gel.jpg'),
('Toallas Húmedas', 'Toallas desinfectantes', 12.50, 65, 7, 'toallas_humedas.jpg'),
('Jabón Líquido Sapolio', 'Jabón líquido para manos', 9.50, 55, 7, 'sapolio.jpg');