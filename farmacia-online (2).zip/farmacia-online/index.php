<?php
$titulo_pagina = "Inicio";
include 'includes/header.php';

// Obtener productos destacados y promociones
$productos_destacados = obtenerProductos(null, null, 8); // 8 productos destacados
$promociones = json_decode(file_get_contents('data/promociones.json'), true);
$categorias = obtenerCategorias();
?>

<!-- Hero Section (Fijo) -->
<section class="hero-section bg-gradient-success text-white py-5">
    <div class="container">
        <div class="row align-items-center min-vh-50">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">
                    Bienvenido a <span class="text-warning"><?php echo $farmacia['nombre']; ?></span>
                </h1>
                <p class="lead mb-4"><?php echo $farmacia['slogan']; ?></p>
                <p class="mb-4">
                    Encuentra los mejores medicamentos, productos de belleza y cuidado personal. 
                    Calidad y confianza para toda tu familia.
                </p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="catalogo.php" class="btn btn-light btn-lg">
                        <i class="fas fa-pills me-2"></i>Ver Productos
                    </a>
                    <?php if (!estaLogueado()): ?>
                    <a href="login_viejo.php" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-user-plus me-2"></i>Crear Cuenta
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6 text-center">
                <div class="hero-image">
                    <img src="assets/images/logo.png" alt="<?php echo $farmacia['nombre']; ?>" 
                         class="img-fluid hero-logo" style="max-height: 300px;">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contenido después del hero (todo lo que viene después del hero) -->
<div class="content-after-hero">

    <!-- Banners de Promociones -->
    <?php if ($promociones['ofertas_especiales']): ?>
    <section class="promociones-section py-4 bg-light">
        <div class="container">
            <div class="row">
                <?php foreach (array_slice($promociones['ofertas_especiales'], 0, 3) as $promo): ?>
                <div class="col-md-4 mb-3">
                    <div class="card promo-card border-0 h-100" style="background-color: <?php echo $promo['color']; ?>20;">
                        <div class="card-body text-center">
                            <i class="fas fa-gift fa-2x mb-3" style="color: <?php echo $promo['color']; ?>;"></i>
                            <h5 class="card-title" style="color: <?php echo $promo['color']; ?>;">
                                <?php echo $promo['titulo']; ?>
                            </h5>
                            <p class="card-text text-muted"><?php echo $promo['descripcion']; ?></p>
                            <a href="catalogo.php" class="btn btn-sm" style="background-color: <?php echo $promo['color']; ?>; color: white;">
                                Ver Más
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Categorías Destacadas -->
    <section class="categorias-section py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold text-dark">Nuestras Categorías</h2>
                <p class="text-muted">Encuentra todo lo que necesitas para tu salud y bienestar</p>
            </div>
            
            <div class="row g-4">
                <?php foreach ($categorias as $categoria): ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="card categoria-card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="categoria-icon mb-3">
                                <i class="fas fa-pills fa-3x text-success"></i>
                            </div>
                            <h5 class="card-title fw-bold"><?php echo $categoria['nombre']; ?></h5>
                            <p class="card-text text-muted small"><?php echo $categoria['descripcion']; ?></p>
                            <a href="catalogo.php?categoria=<?php echo $categoria['id']; ?>" 
                               class="btn btn-outline-success btn-sm">
                                Ver Productos
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Productos Destacados -->
    <section class="productos-destacados py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold text-dark">Productos Destacados</h2>
                <p class="text-muted">Los productos más populares de nuestra farmacia</p>
            </div>

            <div class="row g-4">
                <?php foreach ($productos_destacados as $producto): ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="card producto-card h-100 border-0 shadow-sm">
                        <div class="position-relative">
                            <img src="<?php echo obtenerImagenProducto($producto['imagen']); ?>" 
                                 class="card-img-top" alt="<?php echo $producto['nombre']; ?>"
                                 style="height: 200px; object-fit: cover;">
                            
                            <?php if ($producto['stock'] < 10): ?>
                            <span class="position-absolute top-0 end-0 badge bg-warning m-2">
                                Últimas unidades
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="card-body d-flex flex-column">
                            <h6 class="card-title fw-bold"><?php echo $producto['nombre']; ?></h6>
                            <p class="card-text text-muted small flex-grow-1">
                                <?php echo substr($producto['descripcion'], 0, 80) . '...'; ?>
                            </p>
                            
                            <div class="precio-section mb-3">
                                <span class="h5 text-success fw-bold">
                                    <?php echo formatearPrecio($producto['precio']); ?>
                                </span>
                            </div>

                            <div class="d-flex gap-2">
                                <button class="btn btn-success btn-sm flex-grow-1" 
                                        onclick="agregarAlCarrito(<?php echo $producto['id']; ?>)">
                                    <i class="fas fa-cart-plus me-1"></i>Agregar
                                </button>
                                <a href="catalogo.php?producto=<?php echo $producto['id']; ?>" 
                                   class="btn btn-outline-success btn-sm">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="text-center mt-4">
                <a href="catalogo.php" class="btn btn-success btn-lg">
                    <i class="fas fa-pills me-2"></i>Ver Todos los Productos
                </a>
            </div>
        </div>
    </section>

    <!-- Sección de Servicios -->
    <section class="servicios-section py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold text-dark">¿Por qué elegir <?php echo $farmacia['nombre']; ?>?</h2>
                <p class="text-muted">Ofrecemos el mejor servicio para cuidar tu salud</p>
            </div>

            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <div class="card servicio-card h-100 border-0 text-center">
                        <div class="card-body p-4">
                            <div class="servicio-icon mb-3">
                                <i class="fas fa-clock fa-3x text-success"></i>
                            </div>
                            <h5 class="fw-bold">Atención Extendida</h5>
                            <p class="text-muted">Abierto hasta las 11 PM todos los días</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="card servicio-card h-100 border-0 text-center">
                        <div class="card-body p-4">
                            <div class="servicio-icon mb-3">
                                <i class="fas fa-user-md fa-3x text-success"></i>
                            </div>
                            <h5 class="fw-bold">Farmacéutico Disponible</h5>
                            <p class="text-muted">Consultas gratuitas con profesionales</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="card servicio-card h-100 border-0 text-center">
                        <div class="card-body p-4">
                            <div class="servicio-icon mb-3">
                                <i class="fas fa-shield-alt fa-3x text-success"></i>
                            </div>
                            <h5 class="fw-bold">Productos Garantizados</h5>
                            <p class="text-muted">Medicamentos certificados y originales</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="card servicio-card h-100 border-0 text-center">
                        <div class="card-body p-4">
                            <div class="servicio-icon mb-3">
                                <i class="fas fa-credit-card fa-3x text-success"></i>
                            </div>
                            <h5 class="fw-bold">Múltiples Pagos</h5>
                            <p class="text-muted">Efectivo, tarjetas, Yape y Plin</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Sección de Contacto Rápido -->
    <section class="contacto-rapido py-5 bg-dark text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h3 class="fw-bold mb-2">¿Necesitas ayuda o tienes dudas?</h3>
                    <p class="mb-0">Nuestro equipo está disponible para atenderte</p>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <div class="d-flex flex-wrap gap-2 justify-content-lg-end">
                        <a href="tel:<?php echo $farmacia['telefono']; ?>" class="btn btn-success">
                            <i class="fas fa-phone me-2"></i>Llamar
                        </a>
                        <a href="https://wa.me/<?php echo str_replace(['+', ' '], '', $farmacia['whatsapp']); ?>" 
                           class="btn btn-outline-light" target="_blank">
                            <i class="fab fa-whatsapp me-2"></i>WhatsApp
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div> 

<?php include 'includes/footer.php'; ?>