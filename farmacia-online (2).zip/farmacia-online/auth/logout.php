<?php
session_start();

$_SESSION = array();

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cerrando Sesión - FarmaPlus</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #28a745, #1e7e34);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logout-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
            padding: 2rem;
            max-width: 400px;
        }
        .spinner {
            width: 3rem;
            height: 3rem;
            border: 0.3rem solid #28a745;
            border-top: 0.3rem solid transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="logout-card">
        <div class="mb-4">
            <div class="spinner mx-auto mb-3"></div>
            <h4 class="text-success">Cerrando Sesión...</h4>
            <p class="text-muted">Gracias por usar FarmaPlus</p>
        </div>
        
        <div class="d-flex align-items-center justify-content-center">
            <i class="fas fa-check-circle text-success me-2"></i>
            <span>Sesión cerrada correctamente</span>
        </div>
    </div>

    <script>
        localStorage.removeItem('farmacia_carrito');
        localStorage.removeItem('chatbot_stats');
        
        setTimeout(function() {
            window.location.href = '../index.php';
        }, 2000);
    </script>
</body>
</html>