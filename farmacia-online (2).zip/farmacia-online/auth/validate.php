<?php
require_once '../includes/functions.php';

function validarSesionActiva() {
    iniciarSesion();
    return estaLogueado();
}

function validarPermisoAdmin() {
    iniciarSesion();
    return esAdmin();
}

function redirigirSinPermiso() {
    header('Location: ../login.php?error=sin_permiso');
    exit();
}

function limpiarDatosLogout() {
    // Limpiar cookies relacionadas
    if (isset($_COOKIE['recordar_usuario'])) {
        setcookie('recordar_usuario', '', time() - 3600, '/');
    }
    
    unset($_SESSION['carrito_temporal']);
    unset($_SESSION['ultima_actividad']);
}

if (basename($_SERVER['PHP_SELF']) === 'logout.php') {
    limpiarDatosLogout();
}
?>