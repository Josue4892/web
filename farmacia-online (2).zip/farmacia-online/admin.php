<?php
session_start();
require_once 'includes/functions.php';

if (!esAdmin()) {
    redirigirConMensaje('index.php', 'No tienes permisos para acceder al panel de administración', 'danger');
    exit;
}

$mensaje = '';
$tipo_mensaje = '';

if ($_POST) {
    if (isset($_POST['accion'])) {
        switch ($_POST['accion']) {
            case 'crear_categoria':
                if (crearCategoria($_POST['nombre'], $_POST['descripcion'] ?? '')) {
                    $mensaje = 'Categoría creada exitosamente';
                    $tipo_mensaje = 'success';
                } else {
                    $mensaje = 'Error al crear la categoría';
                    $tipo_mensaje = 'danger';
                }
                break;

            case 'editar_categoria':
                if (editarCategoriaPost($_POST['categoria_id'], $_POST['nombre'], $_POST['descripcion'] ?? '')) {
                    $mensaje = 'Categoría actualizada exitosamente';
                    $tipo_mensaje = 'success';
                } else {
                    $mensaje = 'Error al actualizar la categoría';
                    $tipo_mensaje = 'danger';
                }
                break;

            case 'eliminar_categoria':
                if (eliminarCategoriaPost($_POST['categoria_id'])) {
                    $mensaje = 'Categoría eliminada exitosamente';
                    $tipo_mensaje = 'success';
                } else {
                    $mensaje = 'Error al eliminar la categoría - puede tener productos asociados';
                    $tipo_mensaje = 'danger';
                }
                break;

            case 'cambiar_estado_pedido':
                if (cambiarEstadoPedido($_POST['pedido_id'], $_POST['nuevo_estado'])) {
                    $mensaje = 'Estado del pedido actualizado exitosamente';
                    $tipo_mensaje = 'success';
                } else {
                    $mensaje = 'Error al actualizar el estado del pedido';
                    $tipo_mensaje = 'danger';
                }
                break;
        }

        if ($mensaje) {
            header("Location: admin.php?mensaje=" . urlencode($mensaje) . "&tipo=" . $tipo_mensaje);
            exit;
        }
    }
}

if (isset($_GET['mensaje'])) {
    $mensaje = $_GET['mensaje'];
    $tipo_mensaje = $_GET['tipo'] ?? 'info';
}


function crearCategoria($nombre, $descripcion = '')
{
    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            error_log("Error: No se pudo obtener conexión a la BD");
            return false;
        }

        $query = "INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)";
        return $db->execute($query, [$nombre, $descripcion]);

    } catch (Exception $e) {
        error_log("Error creando categoría: " . $e->getMessage());
        return false;
    }
}

function editarCategoriaPost($id, $nombre, $descripcion = '')
{
    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            error_log("Error: No se pudo obtener conexión a la BD");
            return false;
        }

        $query = "UPDATE categorias SET nombre = ?, descripcion = ? WHERE id = ?";
        return $db->execute($query, [$nombre, $descripcion, $id]);

    } catch (Exception $e) {
        error_log("Error editando categoría: " . $e->getMessage());
        return false;
    }
}

function eliminarCategoriaPost($id)
{
    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            error_log("Error: No se pudo obtener conexión a la BD");
            return false;
        }

        // Verificar si tiene productos asociados
        $check_query = "SELECT COUNT(*) as total FROM productos WHERE categoria_id = ?";
        $result = $db->select($check_query, [$id]);

        if ($result && $result[0]['total'] > 0) {
            error_log("No se puede eliminar categoría - tiene productos asociados");
            return false; // No se puede eliminar si tiene productos
        }

        // Eliminar categoría
        $query = "DELETE FROM categorias WHERE id = ?";
        return $db->execute($query, [$id]);

    } catch (Exception $e) {
        error_log("Error eliminando categoría: " . $e->getMessage());
        return false;
    }
}

function cambiarEstadoPedido($pedido_id, $nuevo_estado)
{
    try {
        $db = new Database();
        $conn = $db->getConnection();

        if (!$conn) {
            error_log("Error: No se pudo obtener conexión a la BD");
            return false;
        }

        $query = "UPDATE pedidos SET estado = ? WHERE id = ?";
        return $db->execute($query, [$nuevo_estado, $pedido_id]);

    } catch (Exception $e) {
        error_log("Error cambiando estado pedido: " . $e->getMessage());
        return false;
    }
}

$titulo_pagina = "Panel de Administración";
include 'includes/header.php';

$usuario = obtenerUsuarioActual();

try {
    $db = new Database();
    $conn = $db->getConnection();

    // Verificar que la conexión esté funcionando
    if (!$conn) {
        throw new Exception("No se pudo establecer conexión con la base de datos");
    }

    // 1. Ventas de hoy - CORREGIDO
    $ventas_hoy_query = "SELECT COALESCE(SUM(total), 0) as ventas_hoy 
                         FROM pedidos 
                         WHERE DATE(fecha_pedido) = CURDATE() 
                         AND estado IN ('pagado', 'entregado')";
    $ventas_result = $db->select($ventas_hoy_query, []);
    $ventas_hoy = $ventas_result ? $ventas_result[0]['ventas_hoy'] : 0;

    // 2. Ventas del mes
    $ventas_mes_query = "SELECT COALESCE(SUM(total), 0) as ventas_mes 
                         FROM pedidos 
                         WHERE MONTH(fecha_pedido) = MONTH(CURDATE()) 
                         AND YEAR(fecha_pedido) = YEAR(CURDATE())
                         AND estado IN ('pagado', 'entregado')";
    $ventas_mes_result = $db->select($ventas_mes_query, []);
    $ventas_mes = $ventas_mes_result ? $ventas_mes_result[0]['ventas_mes'] : 0;

    // 3. Pedidos por estado
    $pedidos_pendientes_query = "SELECT COUNT(*) as total FROM pedidos WHERE estado = 'pendiente'";
    $pedidos_pendientes_result = $db->select($pedidos_pendientes_query, []);
    $pedidos_pendientes = $pedidos_pendientes_result ? $pedidos_pendientes_result[0]['total'] : 0;

    $pedidos_procesando_query = "SELECT COUNT(*) as total FROM pedidos WHERE estado = 'pagado'";
    $pedidos_procesando_result = $db->select($pedidos_procesando_query, []);
    $pedidos_procesando = $pedidos_procesando_result ? $pedidos_procesando_result[0]['total'] : 0;

    // 4. Usuarios
    $total_usuarios_query = "SELECT COUNT(*) as total FROM usuarios";
    $usuarios_result = $db->select($total_usuarios_query, []);
    $total_usuarios = $usuarios_result ? $usuarios_result[0]['total'] : 0;

    $usuarios_hoy_query = "SELECT COUNT(*) as total FROM usuarios WHERE DATE(fecha_registro) = CURDATE()";
    $usuarios_hoy_result = $db->select($usuarios_hoy_query, []);
    $usuarios_hoy = $usuarios_hoy_result ? $usuarios_hoy_result[0]['total'] : 0;

    // 5. Productos
    $total_productos_query = "SELECT COUNT(*) as total FROM productos";
    $productos_result = $db->select($total_productos_query, []);
    $total_productos_real = $productos_result ? $productos_result[0]['total'] : 0;

    $productos_agotados_query = "SELECT COUNT(*) as total FROM productos WHERE stock = 0";
    $agotados_result = $db->select($productos_agotados_query, []);
    $productos_agotados = $agotados_result ? $agotados_result[0]['total'] : 0;

    $productos_bajo_stock_query = "SELECT COUNT(*) as total FROM productos WHERE stock > 0 AND stock < 10";
    $bajo_stock_result = $db->select($productos_bajo_stock_query, []);
    $productos_bajo_stock = $bajo_stock_result ? $bajo_stock_result[0]['total'] : 0;

    // 6. Obtener listas completas para las tabs

    // Usuarios completos
    $usuarios_lista_query = "SELECT u.*, r.nombre as rol_nombre 
                            FROM usuarios u 
                            LEFT JOIN roles r ON u.rol_id = r.id 
                            ORDER BY u.fecha_registro DESC";
    $usuarios_lista = $db->select($usuarios_lista_query, []) ?: [];

    // Pedidos completos
    $pedidos_lista_query = "SELECT p.*, u.nombre as usuario_nombre, u.email as usuario_email,
                            COUNT(dp.id) as total_productos
                            FROM pedidos p 
                            INNER JOIN usuarios u ON p.usuario_id = u.id 
                            LEFT JOIN detalle_pedidos dp ON p.id = dp.pedido_id
                            GROUP BY p.id
                            ORDER BY p.fecha_pedido DESC 
                            LIMIT 100";
    $pedidos_lista = $db->select($pedidos_lista_query, []) ?: [];

    // Productos con stock bajo
    $productos_stock_bajo_query = "SELECT p.*, c.nombre as categoria_nombre 
                                   FROM productos p 
                                   LEFT JOIN categorias c ON p.categoria_id = c.id 
                                   WHERE p.stock < 10 
                                   ORDER BY p.stock ASC";
    $productos_stock_bajo = $db->select($productos_stock_bajo_query, []) ?: [];

    // Top productos vendidos
    $productos_top_query = "SELECT p.*, c.nombre as categoria_nombre,
                            COALESCE(SUM(dp.cantidad), 0) as total_vendido
                            FROM productos p 
                            LEFT JOIN categorias c ON p.categoria_id = c.id
                            LEFT JOIN detalle_pedidos dp ON p.id = dp.producto_id
                            LEFT JOIN pedidos ped ON dp.pedido_id = ped.id AND ped.estado IN ('pagado', 'entregado')
                            GROUP BY p.id
                            ORDER BY total_vendido DESC
                            LIMIT 10";
    $productos_top = $db->select($productos_top_query, []) ?: [];

    // 7. Categorías completas
    $categorias_lista = obtenerCategorias();
    $total_categorias = count($categorias_lista);

    // 8. Reportes de ventas por día (últimos 7 días)
    $ventas_7_dias_query = "SELECT DATE(fecha_pedido) as fecha, 
                           COALESCE(SUM(total), 0) as total_dia,
                           COUNT(*) as pedidos_dia
                           FROM pedidos 
                           WHERE fecha_pedido >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                           AND estado IN ('pagado', 'entregado')
                           GROUP BY DATE(fecha_pedido)
                           ORDER BY fecha DESC";
    $ventas_7_dias = $db->select($ventas_7_dias_query, []) ?: [];

    // 9. Reportes por categoría
    $ventas_categoria_query = "SELECT c.nombre as categoria, 
                              COALESCE(SUM(dp.cantidad * dp.precio_unitario), 0) as total_categoria,
                              COALESCE(SUM(dp.cantidad), 0) as productos_vendidos
                              FROM categorias c
                              LEFT JOIN productos p ON c.id = p.categoria_id
                              LEFT JOIN detalle_pedidos dp ON p.id = dp.producto_id
                              LEFT JOIN pedidos ped ON dp.pedido_id = ped.id AND ped.estado IN ('pagado', 'entregado')
                              GROUP BY c.id, c.nombre
                              ORDER BY total_categoria DESC";
    $ventas_por_categoria = $db->select($ventas_categoria_query, []) ?: [];

    $estadisticas = [
        'ventas_hoy' => (float) $ventas_hoy,
        'ventas_mes' => (float) $ventas_mes,
        'pedidos_pendientes' => (int) $pedidos_pendientes,
        'pedidos_procesando' => (int) $pedidos_procesando,
        'usuarios_registrados' => (int) $total_usuarios,
        'usuarios_hoy' => (int) $usuarios_hoy,
        'productos_total' => (int) $total_productos_real,
        'productos_agotados' => (int) $productos_agotados,
        'productos_bajo_stock' => (int) $productos_bajo_stock,
        'categorias_total' => (int) $total_categorias
    ];

} catch (Exception $e) {
    error_log("Error calculando estadísticas: " . $e->getMessage());
    $estadisticas = [
        'ventas_hoy' => 0.00,
        'ventas_mes' => 0.00,
        'pedidos_pendientes' => 0,
        'pedidos_procesando' => 0,
        'usuarios_registrados' => 0,
        'usuarios_hoy' => 0,
        'productos_total' => 0,
        'productos_agotados' => 0,
        'productos_bajo_stock' => 0,
        'categorias_total' => 0
    ];
    $usuarios_lista = [];
    $pedidos_lista = [];
    $productos_stock_bajo = [];
    $productos_top = [];
    $categorias_lista = [];
    $ventas_7_dias = [];
    $ventas_por_categoria = [];
}
?>

<style>
    .admin-sidebar {
        background: linear-gradient(180deg, #343a40 0%, #495057 100%);
        min-height: calc(100vh - 120px);
        box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .admin-card {
        border-left: 4px solid #28a745;
        transition: all 0.3s ease;
    }

    .admin-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(40, 167, 69, 0.15);
    }

    .stat-card {
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        border-radius: 15px;
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .admin-table th {
        background-color: #28a745;
        color: white;
        border: none;
    }

    .admin-nav .nav-link {
        color: #adb5bd;
        transition: all 0.3s ease;
        border-radius: 8px;
        margin: 5px 10px;
    }

    .admin-nav .nav-link:hover,
    .admin-nav .nav-link.active {
        background: #28a745;
        color: white;
        transform: translateX(5px);
    }

    .progress-custom {
        height: 8px;
        border-radius: 4px;
    }
</style>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-lg-3 col-xl-2">
            <div class="admin-sidebar rounded shadow-sm p-0">
                <div class="p-4 border-bottom border-secondary">
                    <div class="text-center">
                        <div class="avatar-circle bg-success text-white mb-2 mx-auto"
                            style="width: 60px; height: 60px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-user-tie fa-lg"></i>
                        </div>
                        <h6 class="text-white mb-1"><?php echo htmlspecialchars($usuario['nombre']); ?></h6>
                        <small class="text-muted">Administrador</small>
                    </div>
                </div>

                <nav class="admin-nav">
                    <ul class="nav flex-column py-3" id="admin-tabs" role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active" id="dashboard-tab" data-bs-toggle="pill"
                                data-bs-target="#dashboard" type="button" role="tab">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="productos-tab" data-bs-toggle="pill"
                                data-bs-target="#productos" type="button" role="tab">
                                <i class="fas fa-pills me-2"></i>Productos
                                <span
                                    class="badge bg-primary ms-2"><?php echo $estadisticas['productos_total']; ?></span>
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="categorias-tab" data-bs-toggle="pill"
                                data-bs-target="#categorias" type="button" role="tab">
                                <i class="fas fa-tags me-2"></i>Categorías
                                <span
                                    class="badge bg-primary ms-2"><?php echo $estadisticas['categorias_total']; ?></span>
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="usuarios-tab" data-bs-toggle="pill" data-bs-target="#usuarios"
                                type="button" role="tab">
                                <i class="fas fa-users me-2"></i>Usuarios
                                <span
                                    class="badge bg-primary ms-2"><?php echo $estadisticas['usuarios_registrados']; ?></span>
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="pedidos-tab" data-bs-toggle="pill" data-bs-target="#pedidos"
                                type="button" role="tab">
                                <i class="fas fa-shopping-cart me-2"></i>Pedidos
                                <?php if ($estadisticas['pedidos_pendientes'] > 0): ?>
                                    <span
                                        class="badge bg-warning ms-2"><?php echo $estadisticas['pedidos_pendientes']; ?></span>
                                <?php endif; ?>
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="reportes-tab" data-bs-toggle="pill" data-bs-target="#reportes"
                                type="button" role="tab">
                                <i class="fas fa-chart-bar me-2"></i>Reportes
                            </button>
                        </li>
                        <li class="nav-item mt-3 pt-3 border-top border-secondary">
                            <a href="index.php" class="nav-link">
                                <i class="fas fa-home me-2"></i>Volver al Sitio
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="auth/logout.php" class="nav-link text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

        <div class="col-lg-9 col-xl-10">
            <!-- Mensajes -->
            <?php if ($mensaje): ?>
                <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show">
                    <i
                        class="fas fa-<?php echo $tipo_mensaje === 'success' ? 'check-circle' : ($tipo_mensaje === 'danger' ? 'exclamation-triangle' : 'info-circle'); ?> me-2"></i><?php echo htmlspecialchars($mensaje); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Tabs content -->
            <div class="tab-content" id="admin-content">

                <!-- DASHBOARD REAL -->
                <div class="tab-pane fade show active" id="dashboard" role="tabpanel">
                    <!-- Header del dashboard -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="fw-bold text-dark">Dashboard Administrativo</h2>
                            <p class="text-muted mb-0">Datos en tiempo real de FarmaPlus</p>
                        </div>
                        <div>
                            <span class="text-muted">Última actualización: </span>
                            <strong><?php echo date('d/m/Y H:i'); ?></strong>
                        </div>
                    </div>

                    <!-- Estadísticas principales REALES -->
                    <div class="row g-4 mb-5">
                        <div class="col-xl-3 col-md-6">
                            <div class="card stat-card border-0 h-100">
                                <div class="card-body text-center p-4">
                                    <div class="stat-icon bg-success bg-opacity-10 text-success rounded-circle mx-auto mb-3"
                                        style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-dollar-sign fa-lg"></i>
                                    </div>
                                    <h3 class="fw-bold text-success">
                                        <?php echo formatearPrecio($estadisticas['ventas_hoy']); ?></h3>
                                    <p class="text-muted mb-0">Ventas de Hoy</p>
                                    <small class="text-success">
                                        <i class="fas fa-chart-line me-1"></i>Mes:
                                        <?php echo formatearPrecio($estadisticas['ventas_mes']); ?>
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6">
                            <div class="card stat-card border-0 h-100">
                                <div class="card-body text-center p-4">
                                    <div class="stat-icon bg-warning bg-opacity-10 text-warning rounded-circle mx-auto mb-3"
                                        style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-shopping-cart fa-lg"></i>
                                    </div>
                                    <h3 class="fw-bold text-warning"><?php echo $estadisticas['pedidos_pendientes']; ?>
                                    </h3>
                                    <p class="text-muted mb-0">Pedidos Pendientes</p>
                                    <small class="text-info">
                                        <i class="fas fa-clock me-1"></i>Procesando:
                                        <?php echo $estadisticas['pedidos_procesando']; ?>
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6">
                            <div class="card stat-card border-0 h-100">
                                <div class="card-body text-center p-4">
                                    <div class="stat-icon bg-info bg-opacity-10 text-info rounded-circle mx-auto mb-3"
                                        style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-users fa-lg"></i>
                                    </div>
                                    <h3 class="fw-bold text-info"><?php echo $estadisticas['usuarios_registrados']; ?>
                                    </h3>
                                    <p class="text-muted mb-0">Usuarios Registrados</p>
                                    <small class="text-success">
                                        <i class="fas fa-user-plus me-1"></i>Hoy:
                                        <?php echo $estadisticas['usuarios_hoy']; ?>
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6">
                            <div class="card stat-card border-0 h-100">
                                <div class="card-body text-center p-4">
                                    <div class="stat-icon bg-danger bg-opacity-10 text-danger rounded-circle mx-auto mb-3"
                                        style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-exclamation-triangle fa-lg"></i>
                                    </div>
                                    <h3 class="fw-bold text-danger"><?php echo $estadisticas['productos_agotados']; ?>
                                    </h3>
                                    <p class="text-muted mb-0">Productos Agotados</p>
                                    <small class="text-warning">
                                        <i class="fas fa-low-vision me-1"></i>Stock bajo:
                                        <?php echo $estadisticas['productos_bajo_stock']; ?>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row g-4">
                        <div class="col-lg-6">
                            <div class="card admin-card border-0 h-100">
                                <div class="card-header bg-white border-bottom">
                                    <h5 class="mb-0 text-warning">
                                        <i class="fas fa-exclamation-triangle me-2"></i>
                                        Stock Bajo (<?php echo count($productos_stock_bajo); ?>)
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <?php if (empty($productos_stock_bajo)): ?>
                                        <div class="text-center py-4">
                                            <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                            <p class="text-muted">Todos los productos tienen stock suficiente</p>
                                        </div>
                                    <?php else: ?>
                                        <div class="table-responsive">
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr>
                                                        <th>Producto</th>
                                                        <th>Stock</th>
                                                        <th>Acción</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach (array_slice($productos_stock_bajo, 0, 8) as $producto): ?>
                                                        <tr>
                                                            <td>
                                                                <div class="fw-bold">
                                                                    <?php echo htmlspecialchars($producto['nombre']); ?></div>
                                                                <small
                                                                    class="text-muted"><?php echo htmlspecialchars($producto['categoria_nombre'] ?? 'Sin categoría'); ?></small>
                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="badge bg-<?php echo $producto['stock'] === 0 ? 'danger' : 'warning'; ?>">
                                                                    <?php echo $producto['stock']; ?> unidades
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <button class="btn btn-sm btn-outline-success"
                                                                    onclick="reabastecer(<?php echo $producto['id']; ?>)">
                                                                    <i class="fas fa-plus"></i>
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="card admin-card border-0 h-100">
                                <div class="card-header bg-white border-bottom">
                                    <h5 class="mb-0 text-success">
                                        <i class="fas fa-star me-2"></i>
                                        Top Productos Vendidos
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <?php if (empty($productos_top)): ?>
                                        <div class="text-center py-4">
                                            <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                                            <p class="text-muted">Aún no hay ventas registradas</p>
                                        </div>
                                    <?php else: ?>
                                        <div class="table-responsive">
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr>
                                                        <th>Producto</th>
                                                        <th>Vendido</th>
                                                        <th>Stock</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach (array_slice($productos_top, 0, 8) as $producto): ?>
                                                        <tr>
                                                            <td>
                                                                <div class="fw-bold">
                                                                    <?php echo htmlspecialchars($producto['nombre']); ?></div>
                                                                <small
                                                                    class="text-success"><?php echo formatearPrecio($producto['precio']); ?></small>
                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="badge bg-primary"><?php echo $producto['total_vendido']; ?>
                                                                    und</span>
                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="badge bg-<?php echo $producto['stock'] > 20 ? 'success' : ($producto['stock'] > 5 ? 'warning' : 'danger'); ?>">
                                                                    <?php echo $producto['stock']; ?>
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- PRODUCTOS -->
                <div class="tab-pane fade" id="productos" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="fw-bold text-dark">Gestión de Productos</h2>
                            <p class="text-muted mb-0">Total: <?php echo $estadisticas['productos_total']; ?> |
                                Agotados: <?php echo $estadisticas['productos_agotados']; ?> | Stock bajo:
                                <?php echo $estadisticas['productos_bajo_stock']; ?></p>
                        </div>
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalProducto">
                            <i class="fas fa-plus me-2"></i>Nuevo Producto
                        </button>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="admin-table">
                                        <tr>
                                            <th>Imagen</th>
                                            <th>Producto</th>
                                            <th>Categoría</th>
                                            <th>Precio</th>
                                            <th>Stock</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $productos_lista = obtenerProductos();
                                        foreach ($productos_lista as $producto):
                                            ?>
                                            <tr>
                                                <td>
                                                    <img src="<?php echo obtenerImagenProducto($producto['imagen']); ?>"
                                                        alt="<?php echo htmlspecialchars($producto['nombre']); ?>"
                                                        class="img-fluid rounded"
                                                        style="width: 50px; height: 50px; object-fit: cover;"
                                                        onerror="this.src='assets/images/productos/producto_default.jpg'">
                                                </td>
                                                <td>
                                                    <div class="fw-bold">
                                                        <?php echo htmlspecialchars($producto['nombre']); ?></div>
                                                    <small
                                                        class="text-muted"><?php echo htmlspecialchars(substr($producto['descripcion'], 0, 30)) . '...'; ?></small>
                                                </td>
                                                <td><?php echo htmlspecialchars($producto['categoria_nombre'] ?? 'Sin categoría'); ?>
                                                </td>
                                                <td class="text-success fw-bold">
                                                    <?php echo formatearPrecio($producto['precio']); ?></td>
                                                <td>
                                                    <span
                                                        class="badge bg-<?php echo $producto['stock'] > 20 ? 'success' : ($producto['stock'] > 5 ? 'warning' : 'danger'); ?>">
                                                        <?php echo $producto['stock']; ?> unidades
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <button class="btn btn-outline-primary"
                                                            onclick="editarProducto(<?php echo $producto['id']; ?>)"
                                                            title="Editar">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <button class="btn btn-outline-success"
                                                            onclick="ajustarStock(<?php echo $producto['id']; ?>)"
                                                            title="Ajustar Stock">
                                                            <i class="fas fa-boxes"></i>
                                                        </button>
                                                        <button class="btn btn-outline-danger"
                                                            onclick="eliminarProducto(<?php echo $producto['id']; ?>)"
                                                            title="Eliminar">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="categorias" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="fw-bold text-dark">Gestión de Categorías</h2>
                            <p class="text-muted mb-0">Total: <?php echo count($categorias_lista); ?> categorías</p>
                        </div>
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCategoria">
                            <i class="fas fa-plus me-2"></i>Nueva Categoría
                        </button>
                    </div>

                    <div class="row g-4">
                        <?php foreach ($categorias_lista as $categoria): ?>
                            <div class="col-lg-4 col-md-6">
                                <div class="card admin-card border-0 h-100">
                                    <div class="card-body text-center p-4">
                                        <div class="bg-success bg-opacity-10 text-success rounded-circle mx-auto mb-3"
                                            style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                                            <i class="fas fa-tags fa-lg"></i>
                                        </div>
                                        <h5 class="fw-bold"><?php echo htmlspecialchars($categoria['nombre']); ?></h5>
                                        <p class="text-muted">
                                            <?php echo htmlspecialchars($categoria['descripcion'] ?: 'Sin descripción'); ?>
                                        </p>

                                        <?php
                                        $productos_categoria = array_filter(obtenerProductos(), function ($p) use ($categoria) {
                                            return $p['categoria_id'] == $categoria['id'];
                                        });
                                        ?>
                                        <div class="mb-3">
                                            <span class="badge bg-primary"><?php echo count($productos_categoria); ?>
                                                productos</span>
                                        </div>

                                        <div class="btn-group btn-group-sm w-100">
                                            <button class="btn btn-outline-primary"
                                                onclick="editarCategoriaModal(<?php echo $categoria['id']; ?>, '<?php echo addslashes($categoria['nombre']); ?>', '<?php echo addslashes($categoria['descripcion'] ?? ''); ?>')">
                                                <i class="fas fa-edit me-1"></i>Editar
                                            </button>
                                            <button class="btn btn-outline-danger"
                                                onclick="eliminarCategoriaConfirm(<?php echo $categoria['id']; ?>, '<?php echo addslashes($categoria['nombre']); ?>', <?php echo count($productos_categoria); ?>)">
                                                <i class="fas fa-trash me-1"></i>Eliminar
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="tab-pane fade" id="usuarios" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="fw-bold text-dark">Gestión de Usuarios</h2>
                            <p class="text-muted mb-0">Total: <?php echo count($usuarios_lista); ?> usuarios</p>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="admin-table">
                                        <tr>
                                            <th>ID</th>
                                            <th>Usuario</th>
                                            <th>Email</th>
                                            <th>Teléfono</th>
                                            <th>Rol</th>
                                            <th>Fecha Registro</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($usuarios_lista as $user): ?>
                                            <tr>
                                                <td class="fw-bold"><?php echo $user['id']; ?></td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="bg-<?php echo $user['rol_id'] == 1 ? 'danger' : 'primary'; ?> text-white me-3 rounded-circle"
                                                            style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;">
                                                            <i
                                                                class="fas fa-<?php echo $user['rol_id'] == 1 ? 'user-shield' : 'user'; ?>"></i>
                                                        </div>
                                                        <div class="fw-bold">
                                                            <?php echo htmlspecialchars($user['nombre']); ?></div>
                                                    </div>
                                                </td>
                                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                                <td><?php echo htmlspecialchars($user['telefono'] ?: 'No especificado'); ?>
                                                </td>
                                                <td>
                                                    <span
                                                        class="badge bg-<?php echo $user['rol_id'] == 1 ? 'danger' : 'primary'; ?>">
                                                        <?php echo htmlspecialchars($user['rol_nombre'] ?: ($user['rol_id'] == 1 ? 'Administrador' : 'Cliente')); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('d/m/Y', strtotime($user['fecha_registro'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="pedidos" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="fw-bold text-dark">Gestión de Pedidos</h2>
                            <p class="text-muted mb-0">Total: <?php echo count($pedidos_lista); ?> | Pendientes:
                                <?php echo $estadisticas['pedidos_pendientes']; ?></p>
                        </div>
                    </div>

                    <?php if (empty($pedidos_lista)): ?>
                        <div class="card border-0 shadow-sm">
                            <div class="card-body text-center py-5">
                                <i class="fas fa-shopping-cart fa-4x text-muted mb-3"></i>
                                <h5 class="text-muted">No hay pedidos registrados</h5>
                                <p class="text-muted">Los pedidos aparecerán aquí cuando los clientes realicen compras</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="card border-0 shadow-sm">
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead class="admin-table">
                                            <tr>
                                                <th>Pedido #</th>
                                                <th>Cliente</th>
                                                <th>Fecha</th>
                                                <th>Total</th>
                                                <th>Estado</th>
                                                <th>Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($pedidos_lista as $pedido): ?>
                                                <tr>
                                                    <td class="fw-bold">
                                                        #<?php echo str_pad($pedido['id'], 6, '0', STR_PAD_LEFT); ?></td>
                                                    <td>
                                                        <div class="fw-bold">
                                                            <?php echo htmlspecialchars($pedido['usuario_nombre']); ?></div>
                                                        <small
                                                            class="text-muted"><?php echo htmlspecialchars($pedido['usuario_email']); ?></small>
                                                    </td>
                                                    <td><?php echo date('d/m/Y H:i', strtotime($pedido['fecha_pedido'])); ?>
                                                    </td>
                                                    <td class="fw-bold text-success">
                                                        <?php echo formatearPrecio($pedido['total']); ?></td>
                                                    <td>
                                                        <?php
                                                        $estado_class = '';
                                                        switch ($pedido['estado']) {
                                                            case 'pendiente':
                                                                $estado_class = 'warning';
                                                                break;
                                                            case 'pagado':
                                                                $estado_class = 'info';
                                                                break;
                                                            case 'entregado':
                                                                $estado_class = 'success';
                                                                break;
                                                            case 'cancelado':
                                                                $estado_class = 'danger';
                                                                break;
                                                            default:
                                                                $estado_class = 'secondary';
                                                        }
                                                        ?>
                                                        <span
                                                            class="badge bg-<?php echo $estado_class; ?>"><?php echo ucfirst($pedido['estado']); ?></span>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <button class="btn btn-outline-primary"
                                                                onclick="verDetallePedido(<?php echo $pedido['id']; ?>)"
                                                                title="Ver detalle">
                                                                <i class="fas fa-eye"></i>
                                                            </button>
                                                            <div class="btn-group btn-group-sm">
                                                                <button class="btn btn-outline-secondary dropdown-toggle"
                                                                    data-bs-toggle="dropdown" title="Cambiar estado">
                                                                    <i class="fas fa-exchange-alt"></i>
                                                                </button>
                                                                <ul class="dropdown-menu">
                                                                    <li><a class="dropdown-item" href="#"
                                                                            onclick="cambiarEstado(<?php echo $pedido['id']; ?>, 'pagado')">Marcar
                                                                            como Pagado</a></li>
                                                                    <li><a class="dropdown-item" href="#"
                                                                            onclick="cambiarEstado(<?php echo $pedido['id']; ?>, 'entregado')">Marcar
                                                                            como Entregado</a></li>
                                                                    <li>
                                                                        <hr class="dropdown-divider">
                                                                    </li>
                                                                    <li><a class="dropdown-item text-danger" href="#"
                                                                            onclick="cambiarEstado(<?php echo $pedido['id']; ?>, 'cancelado')">Cancelar</a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="tab-pane fade" id="reportes" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="fw-bold text-dark">Reportes y Estadísticas</h2>
                            <p class="text-muted mb-0">Análisis de ventas en tiempo real</p>
                        </div>
                    </div>

                    <div class="row g-4 mb-4">
                        <div class="col-md-3">
                            <div class="card bg-primary text-white">
                                <div class="card-body text-center">
                                    <h4><?php echo formatearPrecio($estadisticas['ventas_hoy']); ?></h4>
                                    <p class="mb-0">Ventas Hoy</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-success text-white">
                                <div class="card-body text-center">
                                    <h4><?php echo formatearPrecio($estadisticas['ventas_mes']); ?></h4>
                                    <p class="mb-0">Ventas del Mes</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-warning text-white">
                                <div class="card-body text-center">
                                    <h4><?php echo count($pedidos_lista); ?></h4>
                                    <p class="mb-0">Total Pedidos</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-info text-white">
                                <div class="card-body text-center">
                                    <h4><?php echo $estadisticas['productos_total']; ?></h4>
                                    <p class="mb-0">Productos Activos</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card admin-card border-0">
                        <div class="card-header bg-white border-bottom">
                            <h5 class="mb-0">
                                <i class="fas fa-chart-pie me-2"></i>
                                Ventas por Categoría
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($ventas_por_categoria)): ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-chart-pie fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">No hay ventas registradas aún</p>
                                </div>
                            <?php else: ?>
                                <?php
                                $total_todas_categorias = array_sum(array_column($ventas_por_categoria, 'total_categoria'));
                                foreach ($ventas_por_categoria as $cat):
                                    $porcentaje = $total_todas_categorias > 0 ? ($cat['total_categoria'] / $total_todas_categorias) * 100 : 0;
                                    ?>
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between mb-1">
                                            <span class="fw-bold"><?php echo htmlspecialchars($cat['categoria']); ?></span>
                                            <span
                                                class="text-success"><?php echo formatearPrecio($cat['total_categoria']); ?></span>
                                        </div>
                                        <div class="progress progress-custom">
                                            <div class="progress-bar bg-success" style="width: <?php echo $porcentaje; ?>%">
                                            </div>
                                        </div>
                                        <small class="text-muted"><?php echo number_format($porcentaje, 1); ?>% -
                                            <?php echo $cat['productos_vendidos']; ?> productos vendidos</small>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalProducto" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="fas fa-pills me-2"></i>Gestión de Producto
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="form-producto" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="accion" value="crear_producto">
                    <input type="hidden" name="producto_id" id="producto_id_edit">

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Nombre del Producto</label>
                                <input type="text" class="form-control" name="nombre" id="producto_nombre" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Categoría</label>
                                <select class="form-control" name="categoria_id" id="producto_categoria" required>
                                    <option value="">Seleccionar categoría</option>
                                    <?php foreach ($categorias_lista as $cat): ?>
                                        <option value="<?php echo $cat['id']; ?>"><?php echo $cat['nombre']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Precio (S/)</label>
                                <input type="number" step="0.01" class="form-control" name="precio" id="producto_precio"
                                    required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Stock</label>
                                <input type="number" class="form-control" name="stock" id="producto_stock" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Descripción</label>
                        <textarea class="form-control" name="descripcion" id="producto_descripcion" rows="3"></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Imagen del Producto</label>
                        <input type="file" class="form-control" name="imagen" id="producto_imagen" accept="image/*">
                        <small class="text-muted">Formatos: JPG, PNG, WEBP. Máximo 2MB</small>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-success" onclick="guardarProducto()">
                    <i class="fas fa-save me-2"></i>Guardar Producto
                </button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="modalCategoria" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="fas fa-tags me-2"></i>Gestión de Categoría
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="form-categoria" method="POST">
                    <input type="hidden" name="accion" value="crear_categoria">
                    <input type="hidden" name="categoria_id" id="categoria_id_edit">
                    <div class="mb-3">
                        <label class="form-label">Nombre de la Categoría</label>
                        <input type="text" class="form-control" name="nombre" id="categoria_nombre" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Descripción</label>
                        <textarea class="form-control" name="descripcion" id="categoria_descripcion"
                            rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-success" onclick="guardarCategoria()">
                    <i class="fas fa-save me-2"></i>Guardar
                </button>
            </div>
        </div>
    </div>
</div>

<script>
   
    (function () {
        'use strict';

        let adminProductosData = <?php echo json_encode(obtenerProductos()); ?>;
        let isAdminPanelLoaded = false;

      

        function editarProducto(id) {
            const producto = adminProductosData.find(p => p.id == id);
            if (!producto) {
                alert('Producto no encontrado');
                return;
            }

            document.getElementById('producto_nombre').value = producto.nombre;
            document.getElementById('producto_categoria').value = producto.categoria_id || '';
            document.getElementById('producto_precio').value = producto.precio;
            document.getElementById('producto_stock').value = producto.stock;
            document.getElementById('producto_descripcion').value = producto.descripcion || '';
            document.getElementById('producto_id_edit').value = id;
            document.querySelector('#form-producto input[name="accion"]').value = 'editar_producto';
            document.querySelector('#modalProducto .modal-title').innerHTML = '<i class="fas fa-edit me-2"></i>Editar Producto';

            const modal = new bootstrap.Modal(document.getElementById('modalProducto'));
            modal.show();
        }

        function guardarProducto() {
            const nombre = document.getElementById('producto_nombre').value.trim();
            const precio = document.getElementById('producto_precio').value;
            const stock = document.getElementById('producto_stock').value;
            const categoria_id = document.getElementById('producto_categoria').value;

            if (!nombre || !precio || !stock || !categoria_id) {
                alert('Los campos nombre, precio, stock y categoría son obligatorios');
                return;
            }

            const form = document.getElementById('form-producto');
            const formData = new FormData(form);

            if (!formData.get('descripcion')) {
                formData.set('descripcion', '');
            }

            mostrarCargandoAdmin('Guardando producto...');

            fetch('api/productos.php', {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    ocultarCargandoAdmin();
                    if (data.success) {
                        alert('Producto guardado exitosamente');
                        // Cerrar modal
                        const modal = bootstrap.Modal.getInstance(document.getElementById('modalProducto'));
                        if (modal) modal.hide();
                        location.reload();
                    } else {
                        alert('Error: ' + (data.message || 'Error desconocido'));
                    }
                })
                .catch(error => {
                    ocultarCargandoAdmin();
                    console.error('Error:', error);
                    alert('Error de conexión: ' + error.message);
                });
        }

        function ajustarStock(id) {
            const producto = adminProductosData.find(p => p.id == id);
            if (!producto) {
                alert('Producto no encontrado');
                return;
            }

            const nuevoStock = prompt(`Stock actual: ${producto.stock}\n\n¿Nuevo stock para "${producto.nombre}"?`, producto.stock);

            if (nuevoStock !== null && !isNaN(nuevoStock) && nuevoStock >= 0) {
                mostrarCargandoAdmin('Actualizando stock...');

                fetch('api/productos.php', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        id: parseInt(id),
                        stock: parseInt(nuevoStock)
                    })
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        ocultarCargandoAdmin();
                        if (data.success) {
                            alert('Stock actualizado exitosamente');
                            location.reload();
                        } else {
                            alert('Error: ' + (data.message || 'Error desconocido'));
                        }
                    })
                    .catch(error => {
                        ocultarCargandoAdmin();
                        console.error('Error:', error);
                        alert('Error de conexión: ' + error.message);
                    });
            }
        }

        function eliminarProducto(id) {
            const producto = adminProductosData.find(p => p.id == id);
            if (!producto) {
                alert('Producto no encontrado');
                return;
            }

            if (!confirm(`¿Eliminar "${producto.nombre}"?\n\nEsta acción no se puede deshacer.`)) return;

            fetch(`api/productos.php`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ id: parseInt(id) })
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        alert('Producto eliminado exitosamente');
                        location.reload();
                    } else {
                        alert('Error: ' + (data.message || 'Error desconocido'));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error de conexión: ' + error.message);
                });
        }

        function reabastecer(id) {
            ajustarStock(id);
        }


        function editarCategoriaModal(id, nombre, descripcion) {
            document.getElementById('categoria_nombre').value = nombre;
            document.getElementById('categoria_descripcion').value = descripcion;
            document.getElementById('categoria_id_edit').value = id;
            document.querySelector('#form-categoria input[name="accion"]').value = 'editar_categoria';
            document.querySelector('#modalCategoria .modal-title').innerHTML = '<i class="fas fa-edit me-2"></i>Editar Categoría';

            const modal = new bootstrap.Modal(document.getElementById('modalCategoria'));
            modal.show();
        }

        function guardarCategoria() {
            const nombre = document.getElementById('categoria_nombre').value.trim();
            if (!nombre) {
                alert('El nombre es obligatorio');
                return;
            }

            const form = document.getElementById('form-categoria');
            form.noValidate = true;
            form.submit();
        }

        function eliminarCategoriaConfirm(id, nombre, totalProductos) {
            if (totalProductos > 0) {
                alert(`No se puede eliminar "${nombre}" porque tiene ${totalProductos} productos asociados.\n\nPrimero debe reasignar o eliminar los productos de esta categoría.`);
                return;
            }

            if (!confirm(`¿Eliminar la categoría "${nombre}"?\n\nEsta acción no se puede deshacer.`)) return;

            const form = document.createElement('form');
            form.method = 'POST';
            form.noValidate = true; // Evitar validación de main.js
            form.innerHTML = `
            <input type="hidden" name="accion" value="eliminar_categoria">
            <input type="hidden" name="categoria_id" value="${id}">
        `;
            document.body.appendChild(form);
            form.submit();
        }


        function verDetallePedido(id) {
            window.open(`api/pedidos.php?action=detalle&id=${id}`, '_blank', 'width=800,height=600');
        }

        function cambiarEstado(pedidoId, nuevoEstado) {
            if (!confirm(`¿Cambiar estado del pedido #${pedidoId} a "${nuevoEstado}"?`)) return;

            const form = document.createElement('form');
            form.method = 'POST';
            form.noValidate = true; // Evitar validación de main.js
            form.innerHTML = `
            <input type="hidden" name="accion" value="cambiar_estado_pedido">
            <input type="hidden" name="pedido_id" value="${pedidoId}">
            <input type="hidden" name="nuevo_estado" value="${nuevoEstado}">
        `;
            document.body.appendChild(form);
            form.submit();
        }

        function inicializarAdminPanel() {
            if (isAdminPanelLoaded) return;

            // Resetear modales
            const modalCategoria = document.getElementById('modalCategoria');
            if (modalCategoria) {
                modalCategoria.addEventListener('hidden.bs.modal', function () {
                    const form = this.querySelector('form');
                    if (form) form.reset();

                    document.querySelector('#modalCategoria .modal-title').innerHTML = '<i class="fas fa-tags me-2"></i>Nueva Categoría';
                    document.querySelector('#form-categoria input[name="accion"]').value = 'crear_categoria';
                    document.getElementById('categoria_id_edit').value = '';
                });
            }

            const modalProducto = document.getElementById('modalProducto');
            if (modalProducto) {
                modalProducto.addEventListener('hidden.bs.modal', function () {
                    const form = this.querySelector('form');
                    if (form) form.reset();

                    document.querySelector('#modalProducto .modal-title').innerHTML = '<i class="fas fa-pills me-2"></i>Nuevo Producto';
                    document.querySelector('#form-producto input[name="accion"]').value = 'crear_producto';
                    document.getElementById('producto_id_edit').value = '';
                });
            }

            // Verificar APIs disponibles
            fetch('api/productos.php?action=test')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        console.log('✅ API de productos disponible');
                    }
                })
                .catch(error => {
                    console.warn('⚠️ API de productos no disponible:', error);
                });

            // Deshabilitar validaciones de main.js en formularios de admin
            const adminForms = document.querySelectorAll('#modalCategoria form, form[id^="form-"]');
            adminForms.forEach(form => {
                form.noValidate = true;

                // Remover event listeners de main.js
                const newForm = form.cloneNode(true);
                form.parentNode.replaceChild(newForm, form);
            });

            isAdminPanelLoaded = true;
            console.log('✅ Admin panel inicializado sin interferencias');
            console.log('📊 Estadísticas:', <?php echo json_encode($estadisticas); ?>);
        }

        window.editarProducto = editarProducto;
        window.guardarProducto = guardarProducto;
        window.ajustarStock = ajustarStock;
        window.eliminarProducto = eliminarProducto;
        window.reabastecer = reabastecer;
        window.editarCategoriaModal = editarCategoriaModal;
        window.guardarCategoria = guardarCategoria;
        window.eliminarCategoriaConfirm = eliminarCategoriaConfirm;
        window.verDetallePedido = verDetallePedido;
        window.cambiarEstado = cambiarEstado;



        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', inicializarAdminPanel);
        } else {
            setTimeout(inicializarAdminPanel, 100);
        }

        window.addEventListener('load', function () {
            setTimeout(inicializarAdminPanel, 200);
        });

        console.log('🔧 Admin.js cargado - Funciones disponibles globalmente');

    })(); 


    function formatearMonedaAdmin(cantidad) {
        return new Intl.NumberFormat('es-PE', {
            style: 'currency',
            currency: 'PEN'
        }).format(cantidad);
    }

    function mostrarCargandoAdmin(mensaje = 'Procesando...') {
        const overlay = document.createElement('div');
        overlay.id = 'loading-overlay-admin';
        overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    `;

        overlay.innerHTML = `
        <div class="bg-white p-4 rounded shadow">
            <div class="d-flex align-items-center">
                <div class="spinner-border text-success me-3" role="status"></div>
                <span>${mensaje}</span>
            </div>
        </div>
    `;

        document.body.appendChild(overlay);
    }

    function ocultarCargandoAdmin() {
        const overlay = document.getElementById('loading-overlay-admin');
        if (overlay) {
            overlay.remove();
        }
    }

    // Prevenir errores de main.js que puedan afectar admin
    window.addEventListener('error', function (e) {
        if (e.filename && e.filename.includes('main.js')) {
            e.preventDefault();
            console.warn('Error de main.js bloqueado para proteger admin panel');
            return false;
        }
    });

    console.log('🚀 Admin panel script completamente cargado y protegido');
</script>

<?php include 'includes/footer.php'; ?>