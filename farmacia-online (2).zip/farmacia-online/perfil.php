<?php
$titulo_pagina = "Mi Perfil";
include 'includes/header.php';

if (!estaLogueado()) {
    redirigirConMensaje('login_viejo.php', 'Debes iniciar sesión para ver tu perfil', 'warning');
}

$usuario = obtenerUsuarioActual();
$error = '';
$exito = '';

function obtenerDatosCompletos($usuario_id) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return null;
        }
        
        $query = "SELECT u.*, r.nombre as rol_nombre 
                  FROM usuarios u 
                  LEFT JOIN roles r ON u.rol_id = r.id 
                  WHERE u.id = ?";
        $resultado = $db->select($query, [$usuario_id]);
        return $resultado ? $resultado[0] : null;
        
    } catch (Exception $e) {
        error_log("Error obteniendo datos usuario: " . $e->getMessage());
        return null;
    }
}

function obtenerHistorialPedidos($usuario_id) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return [];
        }
        
        $query = "SELECT p.*, 
                         COUNT(dp.id) as total_productos,
                         GROUP_CONCAT(
                             CONCAT(pr.nombre, ' (', dp.cantidad, 'x', dp.precio_unitario, ')')
                             SEPARATOR '|'
                         ) as productos_detalle
                  FROM pedidos p
                  LEFT JOIN detalle_pedidos dp ON p.id = dp.pedido_id
                  LEFT JOIN productos pr ON dp.producto_id = pr.id
                  WHERE p.usuario_id = ?
                  GROUP BY p.id
                  ORDER BY p.fecha_pedido DESC";
        
        $pedidos = $db->select($query, [$usuario_id]);
        
        // Procesar productos para cada pedido
        foreach ($pedidos as &$pedido) {
            $pedido['productos'] = [];
            if (!empty($pedido['productos_detalle'])) {
                $productos_raw = explode('|', $pedido['productos_detalle']);
                foreach ($productos_raw as $producto_raw) {
                    if (preg_match('/^(.+) \((\d+)x(\d+\.?\d*)\)$/', $producto_raw, $matches)) {
                        $pedido['productos'][] = [
                            'nombre' => $matches[1],
                            'cantidad' => (int)$matches[2],
                            'precio' => (float)$matches[3]
                        ];
                    }
                }
            }
        }
        
        return $pedidos;
        
    } catch (Exception $e) {
        error_log("Error obteniendo historial: " . $e->getMessage());
        return [];
    }
}

function actualizarPerfil($usuario_id, $datos) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return false;
        }
        
        $query = "UPDATE usuarios SET 
                  nombre = ?, 
                  email = ?, 
                  telefono = ?
                  WHERE id = ?";
        
        $resultado = $db->execute($query, [
            $datos['nombre'],
            $datos['email'], 
            $datos['telefono'],
            $usuario_id
        ]);
        
        if ($resultado) {
            // Actualizar sesión
            $_SESSION['usuario_nombre'] = $datos['nombre'];
            $_SESSION['usuario_email'] = $datos['email'];
        }
        
        return $resultado;
        
    } catch (Exception $e) {
        error_log("Error actualizando perfil: " . $e->getMessage());
        return false;
    }
}

function cambiarPassword($usuario_id, $password_actual, $password_nuevo) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        if (!$conn) {
            return false;
        }
        
        $query = "SELECT id FROM usuarios WHERE id = ? AND password = MD5(?)";
        $resultado = $db->select($query, [$usuario_id, $password_actual]);
        
        if (!$resultado || count($resultado) === 0) {
            return false; // Contraseña actual incorrecta
        }
        
        // Actualizar contraseña
        $query = "UPDATE usuarios SET password = MD5(?) WHERE id = ?";
        return $db->execute($query, [$password_nuevo, $usuario_id]);
        
    } catch (Exception $e) {
        error_log("Error cambiando contraseña: " . $e->getMessage());
        return false;
    }
}

$usuario_completo = obtenerDatosCompletos($usuario['id']);
if (!$usuario_completo) {
    $usuario_completo = $usuario; 
}

if ($_POST && isset($_POST['actualizar_perfil'])) {
    $nombre = sanitizar($_POST['nombre']);
    $email = sanitizar($_POST['email']);
    $telefono = sanitizar($_POST['telefono']);
    
    if (empty($nombre) || empty($email) || empty($telefono)) {
        $error = 'Los campos nombre, email y teléfono son obligatorios';
    } elseif (!validarEmail($email)) {
        $error = 'El email no es válido';
    } elseif (!validarTelefono($telefono)) {
        $error = 'El teléfono debe tener 9 dígitos';
    } else {
        $datos = [
            'nombre' => $nombre,
            'email' => $email,
            'telefono' => $telefono
        ];
        
        if (actualizarPerfil($usuario['id'], $datos)) {
            $exito = 'Perfil actualizado correctamente';
            // Recargar datos
            $usuario_completo = obtenerDatosCompletos($usuario['id']);
        } else {
            $error = 'Error al actualizar el perfil';
        }
    }
}

if ($_POST && isset($_POST['cambiar_password'])) {
    $password_actual = $_POST['password_actual'];
    $password_nuevo = $_POST['password_nuevo'];
    $password_confirmar = $_POST['password_confirmar'];
    
    if (empty($password_actual) || empty($password_nuevo) || empty($password_confirmar)) {
        $error = 'Todos los campos de contraseña son obligatorios';
    } elseif (!validarPassword($password_nuevo)) {
        $error = 'La nueva contraseña debe tener al menos 6 caracteres';
    } elseif ($password_nuevo !== $password_confirmar) {
        $error = 'Las contraseñas nuevas no coinciden';
    } else {
        if (cambiarPassword($usuario['id'], $password_actual, $password_nuevo)) {
            $exito = 'Contraseña cambiada correctamente';
        } else {
            $error = 'Contraseña actual incorrecta o error en el sistema';
        }
    }
}

$historial_pedidos = obtenerHistorialPedidos($usuario['id']);
?>

<style>

.boleta-actions {
    display: flex;
    flex-direction: column;
    gap: 8px;
    min-width: 200px;
}

/* Botones individuales */
.boleta-actions .btn {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 8px;
    padding: 8px 12px;
    font-size: 12px;
    border-radius: 6px;
    transition: all 0.3s ease;
    white-space: nowrap;
}

/* Botón Ver Boleta */
.btn-ver-boleta {
    background-color: #6f42c1;
    border-color: #6f42c1;
    color: white;
}

.btn-ver-boleta:hover {
    background-color: #5a32a3;
    border-color: #5a32a3;
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(111, 66, 193, 0.3);
}

/* Botón Descargar PDF */
.btn-descargar-pdf {
    background-color: #dc3545;
    border-color: #dc3545;
    color: white;
}

.btn-descargar-pdf:hover {
    background-color: #c82333;
    border-color: #c82333;
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
}

/* Botón WhatsApp */
.btn-whatsapp {
    background-color: #25d366;
    border-color: #25d366;
    color: white;
}

.btn-whatsapp:hover {
    background-color: #128c7e;
    border-color: #128c7e;
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(37, 211, 102, 0.3);
}

/* Botón Volver a Comprar */
.btn-recomprar {
    background-color: #fd7e14;
    border-color: #fd7e14;
    color: white;
}

.btn-recomprar:hover {
    background-color: #e55a00;
    border-color: #e55a00;
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(253, 126, 20, 0.3);
}

/* Estado de carga */
.btn-loading {
    position: relative;
    pointer-events: none;
    opacity: 0.7;
}

.btn-loading .fas {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Responsive para móviles */
@media (max-width: 768px) {
    .boleta-actions {
        min-width: 100%;
    }
    
    .boleta-actions .btn {
        justify-content: center;
        font-size: 11px;
        padding: 6px 8px;
    }
}

/* Mejorar la tarjeta del pedido */
.pedido-card {
    border: 1px solid #e9ecef;
    border-radius: 12px;
    overflow: hidden;
    transition: all 0.3s ease;
    margin-bottom: 20px;
}

.pedido-card:hover {
    box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    transform: translateY(-2px);
}

.pedido-card .card-header {
    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
    border-bottom: 1px solid #dee2e6;
    padding: 15px 20px;
}

.pedido-card .card-body {
    padding: 20px;
}

/* Mejorar badges de estado */
.estado-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.estado-entregado {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.estado-proceso {
    background-color: #fff3cd;
    color: #856404;
    border: 1px solid #ffeaa7;
}

.estado-pendiente {
    background-color: #cce5ff;
    color: #004085;
    border: 1px solid #99d1ff;
}

/* Mejorar lista de productos */
.productos-lista {
    background-color: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    margin-top: 10px;
}

.producto-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid #e9ecef;
}

.producto-item:last-child {
    border-bottom: none;
}

.producto-nombre {
    font-weight: 600;
    color: #333;
}

.producto-cantidad {
    background-color: #28a745;
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: bold;
    margin-right: 8px;
}

.producto-precio {
    color: #6c757d;
    font-size: 12px;
}

/* Animaciones */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.pedido-card {
    animation: fadeInUp 0.5s ease-out;
}

/* Notificaciones mejoradas */
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    min-width: 300px;
    max-width: 400px;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    animation: slideInRight 0.3s ease-out;
}

.notification-success {
    background-color: #d4edda;
    color: #155724;
    border-left: 4px solid #28a745;
}

.notification-error {
    background-color: #f8d7da;
    color: #721c24;
    border-left: 4px solid #dc3545;
}

.notification-info {
    background-color: #d1ecf1;
    color: #0c5460;
    border-left: 4px solid #17a2b8;
}

@keyframes slideInRight {
    from {
        opacity: 0;
        transform: translateX(100%);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}
</style>

<!-- Contenido principal -->
<div class="container py-5">
    <div class="row">
        <!-- Breadcrumb -->
        <div class="col-12 mb-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                    <li class="breadcrumb-item active">Mi Perfil</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Mensajes -->
    <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
        </div>
    <?php endif; ?>

    <?php if ($exito): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle me-2"></i><?php echo $exito; ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Sidebar de navegación -->
        <div class="col-lg-3 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center">
                    <div class="avatar-circle bg-success text-white mb-3 mx-auto" style="width: 80px; height: 80px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-user fa-2x"></i>
                    </div>
                    <h5 class="fw-bold"><?php echo $usuario_completo['nombre']; ?></h5>
                    <p class="text-muted mb-0"><?php echo $usuario_completo['email']; ?></p>
                    <span class="badge bg-success mt-2">
                        <?php echo $usuario_completo['rol_nombre'] ?? (esAdmin() ? 'Administrador' : 'Cliente'); ?>
                    </span>
                    <div class="mt-2">
                        <small class="text-muted">
                            Miembro desde: <?php echo date('M Y', strtotime($usuario_completo['fecha_registro'])); ?>
                        </small>
                    </div>
                </div>
            </div>

            <!-- Navegación del perfil -->
            <div class="card border-0 shadow-sm mt-3">
                <div class="card-body p-0">
                    <ul class="nav nav-pills flex-column" id="perfil-tabs" role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active border-0 text-start w-100" id="info-tab" 
                                    data-bs-toggle="pill" data-bs-target="#info" type="button" role="tab">
                                <i class="fas fa-user me-2"></i>Información Personal
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link border-0 text-start w-100" id="historial-tab" 
                                    data-bs-toggle="pill" data-bs-target="#historial" type="button" role="tab">
                                <i class="fas fa-history me-2"></i>Historial de Compras
                                <span class="badge bg-secondary ms-2"><?php echo count($historial_pedidos); ?></span>
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link border-0 text-start w-100" id="seguridad-tab" 
                                    data-bs-toggle="pill" data-bs-target="#seguridad" type="button" role="tab">
                                <i class="fas fa-shield-alt me-2"></i>Seguridad
                            </button>
                        </li>
                        <?php if (esAdmin()): ?>
                        <li class="nav-item">
                            <a href="admin.php" class="nav-link border-0 text-start w-100 text-primary">
                                <i class="fas fa-cog me-2"></i>Panel Admin
                            </a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a href="auth/logout.php" class="nav-link border-0 text-start w-100 text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Contenido principal -->
        <div class="col-lg-9">
            <div class="tab-content" id="perfil-content">
                
                <!-- Información Personal -->
                <div class="tab-pane fade show active" id="info" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white border-bottom">
                            <h5 class="mb-0">
                                <i class="fas fa-user text-success me-2"></i>
                                Información Personal
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <input type="hidden" name="actualizar_perfil" value="1">
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Nombre Completo *</label>
                                        <input type="text" class="form-control" name="nombre" 
                                               value="<?php echo $usuario_completo['nombre']; ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Email *</label>
                                        <input type="email" class="form-control" name="email" 
                                               value="<?php echo $usuario_completo['email']; ?>" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Teléfono *</label>
                                        <input type="tel" class="form-control" name="telefono" 
                                               value="<?php echo $usuario_completo['telefono']; ?>"
                                               placeholder="999888777" maxlength="9" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Fecha de Registro</label>
                                        <input type="text" class="form-control" 
                                               value="<?php echo date('d/m/Y H:i', strtotime($usuario_completo['fecha_registro'])); ?>" 
                                               readonly>
                                    </div>
                                </div>

                                <div class="text-end">
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-save me-2"></i>Actualizar Información
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Historial de Compras -->
                <div class="tab-pane fade" id="historial" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white border-bottom">
                            <h5 class="mb-0">
                                <i class="fas fa-history text-success me-2"></i>
                                Historial de Compras
                                <span class="badge bg-success ms-2"><?php echo count($historial_pedidos); ?></span>
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($historial_pedidos)): ?>
                                <div class="text-center py-5">
                                    <i class="fas fa-shopping-bag fa-4x text-muted mb-3"></i>
                                    <h5 class="text-muted">No tienes compras aún</h5>
                                    <p class="text-muted mb-4">Explora nuestros productos y realiza tu primera compra</p>
                                    <a href="catalogo.php" class="btn btn-success">
                                        <i class="fas fa-pills me-2"></i>Ver Productos
                                    </a>
                                </div>
                            <?php else: ?>
                                <?php foreach ($historial_pedidos as $pedido): ?>
                                <div class="pedido-card">
                                    <div class="card-header">
                                        <div class="row align-items-center">
                                            <div class="col-md-3">
                                                <strong>Pedido #<?php echo str_pad($pedido['id'], 6, '0', STR_PAD_LEFT); ?></strong>
                                            </div>
                                            <div class="col-md-3">
                                                <small class="text-muted">
                                                    <i class="fas fa-calendar me-1"></i>
                                                    <?php echo date('d/m/Y H:i', strtotime($pedido['fecha_pedido'])); ?>
                                                </small>
                                            </div>
                                            <div class="col-md-3">
                                                <?php 
                                                $estado_class = '';
                                                switch($pedido['estado']) {
                                                    case 'entregado':
                                                        $estado_class = 'estado-entregado';
                                                        break;
                                                    case 'en_proceso':
                                                        $estado_class = 'estado-proceso';
                                                        break;
                                                    default:
                                                        $estado_class = 'estado-pendiente';
                                                }
                                                ?>
                                                <span class="estado-badge <?php echo $estado_class; ?>">
                                                    <?php echo ucfirst(str_replace('_', ' ', $pedido['estado'])); ?>
                                                </span>
                                            </div>
                                            <div class="col-md-3 text-end">
                                                <strong class="text-success h5">
                                                    <?php echo formatearPrecio($pedido['total']); ?>
                                                </strong>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <h6 class="mb-3">
                                                    <i class="fas fa-shopping-cart me-1"></i>
                                                    Productos (<?php echo $pedido['total_productos']; ?>):
                                                </h6>
                                                <div class="productos-lista">
                                                    <?php foreach ($pedido['productos'] as $producto): ?>
                                                    <div class="producto-item">
                                                        <div>
                                                            <span class="producto-cantidad"><?php echo $producto['cantidad']; ?>x</span>
                                                            <span class="producto-nombre"><?php echo $producto['nombre']; ?></span>
                                                        </div>
                                                        <div class="producto-precio">
                                                            <?php echo formatearPrecio($producto['precio']); ?> c/u
                                                        </div>
                                                    </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="boleta-actions">
                                                    <button class="btn btn-ver-boleta" onclick="verBoleta(<?php echo $pedido['id']; ?>)">
                                                        <i class="fas fa-eye"></i>Ver Boleta
                                                    </button>
                                                    <button class="btn btn-descargar-pdf" onclick="descargarBoleta(<?php echo $pedido['id']; ?>)">
                                                        <i class="fas fa-download"></i>Descargar PDF
                                                    </button>
                                                    <button class="btn btn-whatsapp" onclick="enviarBoletaWhatsApp(<?php echo $pedido['id']; ?>)">
                                                        <i class="fab fa-whatsapp"></i>Enviar por WhatsApp
                                                    </button>
                                                    <button class="btn btn-recomprar" onclick="volverAComprar(<?php echo $pedido['id']; ?>)">
                                                        <i class="fas fa-redo"></i>Volver a Comprar
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>

                                <!-- Estadísticas reales -->
                                <div class="row mt-4">
                                    <div class="col-md-4">
                                        <div class="card bg-light border-0 text-center">
                                            <div class="card-body">
                                                <i class="fas fa-shopping-cart fa-2x text-success mb-2"></i>
                                                <h4 class="text-success mb-1"><?php echo count($historial_pedidos); ?></h4>
                                                <small class="text-muted">Pedidos Realizados</small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card bg-light border-0 text-center">
                                            <div class="card-body">
                                                <i class="fas fa-dollar-sign fa-2x text-success mb-2"></i>
                                                <h4 class="text-success mb-1">
                                                    <?php 
                                                    $total_gastado = array_sum(array_column($historial_pedidos, 'total'));
                                                    echo formatearPrecio($total_gastado); 
                                                    ?>
                                                </h4>
                                                <small class="text-muted">Total Gastado</small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card bg-light border-0 text-center">
                                            <div class="card-body">
                                                <i class="fas fa-chart-line fa-2x text-success mb-2"></i>
                                                <h4 class="text-success mb-1">
                                                    <?php 
                                                    $promedio = count($historial_pedidos) > 0 ? $total_gastado / count($historial_pedidos) : 0;
                                                    echo formatearPrecio($promedio); 
                                                    ?>
                                                </h4>
                                                <small class="text-muted">Promedio por Pedido</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Seguridad -->
                <div class="tab-pane fade" id="seguridad" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white border-bottom">
                            <h5 class="mb-0">
                                <i class="fas fa-shield-alt text-success me-2"></i>
                                Seguridad de la Cuenta
                            </h5>
                        </div>
                        <div class="card-body">
                            <!-- Cambiar contraseña -->
                            <div class="mb-4">
                                <h6 class="fw-bold mb-3">Cambiar Contraseña</h6>
                                <form method="POST" action="">
                                    <input type="hidden" name="cambiar_password" value="1">
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Contraseña Actual</label>
                                        <input type="password" class="form-control" name="password_actual" required>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Nueva Contraseña</label>
                                            <input type="password" class="form-control" name="password_nuevo" 
                                                   minlength="6" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Confirmar Nueva Contraseña</label>
                                            <input type="password" class="form-control" name="password_confirmar" 
                                                   minlength="6" required>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-warning">
                                        <i class="fas fa-key me-2"></i>Cambiar Contraseña
                                    </button>
                                </form>
                            </div>

                            <hr>

                            <!-- Información de sesión -->
                            <div class="mb-4">
                                <h6 class="fw-bold mb-3">Información de Sesión</h6>
                                <div class="bg-light p-3 rounded">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <small class="text-muted">Último acceso:</small>
                                            <div><?php echo date('d/m/Y H:i'); ?></div>
                                        </div>
                                        <div class="col-md-6">
                                            <small class="text-muted">Tipo de cuenta:</small>
                                            <div><?php echo $usuario_completo['rol_nombre'] ?? (esAdmin() ? 'Administrador' : 'Cliente'); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Opciones adicionales -->
                            <div class="mb-4">
                                <h6 class="fw-bold mb-3">Opciones de Cuenta</h6>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-primary" onclick="descargarDatos()">
                                        <i class="fas fa-download me-2"></i>Descargar mis Datos
                                    </button>
                                    <button class="btn btn-outline-danger" onclick="confirmarEliminacion()">
                                        <i class="fas fa-user-times me-2"></i>Eliminar Cuenta
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function verBoleta(pedidoId) {
    const url = `generar_pdf.php?pedido_id=${pedidoId}&accion=ver`;
    window.open(url, '_blank', 'width=900,height=700,scrollbars=yes,resizable=yes');
}

function descargarBoleta(pedidoId) {
    const url = `generar_pdf.php?pedido_id=${pedidoId}&accion=descargar`;
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `boleta_pedido_${pedidoId}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    mostrarNotificacion('📄 Boleta descargada correctamente', 'success');
}

async function enviarBoletaWhatsApp(pedidoId) {
    const boton = event ? event.target : document.querySelector(`[onclick="enviarBoletaWhatsApp(${pedidoId})"]`);
    
    if (!boton) {
        console.error('No se pudo encontrar el botón');
        return;
    }

    const textoOriginal = boton.innerHTML;
    
    try {
        boton.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Preparando mensaje...';
        boton.disabled = true;
        boton.classList.add('btn-loading');
        
        console.log('Enviando solicitud para pedido:', pedidoId);
        
        const response = await fetch(`generar_pdf.php?pedido_id=${pedidoId}&accion=whatsapp`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status} - ${response.statusText}`);
        }
        
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const textResponse = await response.text();
            console.error('Respuesta no es JSON:', textResponse);
            throw new Error('La respuesta del servidor no es JSON válido. Verifique los logs del servidor.');
        }
        
        const resultado = await response.json();
        console.log('Respuesta recibida:', resultado);
        
        if (resultado.success) {
            const mensaje = `✅ Mensaje preparado para WhatsApp!\n\n` +
                          `📱 Número: ${resultado.telefono}\n` +
                          `🧾 Boleta PDF: ${resultado.pdf_generado ? 'Generada correctamente' : 'Enlace directo'}\n\n` +
                          `¿Abrir WhatsApp ahora?`;
            
            if (confirm(mensaje)) {
                // Abrir WhatsApp
                window.open(resultado.whatsapp_url, '_blank');
                
                // Mostrar mensaje de éxito
                mostrarNotificacion('📱 WhatsApp abierto con la boleta del pedido #' + pedidoId, 'success');
            }
            
        } else {
            throw new Error(resultado.mensaje || 'Error desconocido al generar mensaje');
        }
        
    } catch (error) {
        console.error('Error completo:', error);
        
        let mensajeError = 'Error de conexión';
        if (error.message.includes('JSON')) {
            mensajeError = 'Error en el servidor. Verifique que el pedido existe.';
        } else if (error.message.includes('HTTP')) {
            mensajeError = 'Error de servidor: ' + error.message;
        } else {
            mensajeError = error.message;
        }
        
        mostrarNotificacion('❌ ' + mensajeError, 'error');
    } finally {
        // Restaurar botón
        if (boton) {
            boton.innerHTML = textoOriginal;
            boton.disabled = false;
            boton.classList.remove('btn-loading');
        }
    }
}

function verDetallePedido(pedidoId) {
    const url = `generar_pdf.php?pedido_id=${pedidoId}&accion=ver`;
    window.open(url, '_blank', 'width=800,height=600');
}

function volverAComprar(pedidoId) {
    if (confirm('¿Quieres agregar los productos de este pedido al carrito?')) {
        mostrarNotificacion('🛒 Función en desarrollo: Volver a comprar pedido #' + pedidoId, 'info');
    }
}

function descargarDatos() {
    mostrarNotificacion('📄 Preparando descarga de datos del perfil...', 'info');
}

function confirmarEliminacion() {
    if (confirm('¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.')) {
        if (confirm('Esta acción eliminará permanentemente todos tus datos. ¿Continuar?')) {
            mostrarNotificacion('🗑️ Solicitud de eliminación de cuenta enviada', 'info');
        }
    }
}

function mostrarNotificacion(mensaje, tipo) {
    const existentes = document.querySelectorAll('.notification');
    existentes.forEach(n => n.remove());
    
    const notificacion = document.createElement('div');
    notificacion.className = `notification notification-${tipo}`;
    notificacion.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span>${mensaje}</span>
            <button type="button" class="btn-close btn-close-white ms-2" onclick="this.parentElement.parentElement.remove()"></button>
        </div>
    `;
    
    document.body.appendChild(notificacion);
    
    setTimeout(() => {
        if (notificacion.parentNode) {
            notificacion.style.opacity = '0';
            setTimeout(() => {
                if (notificacion.parentNode) {
                    notificacion.parentNode.removeChild(notificacion);
                }
            }, 300);
        }
    }, 5000);
}

// Validación de contraseñas en tiempo real
document.addEventListener('DOMContentLoaded', function() {
    const passwordNuevo = document.querySelector('input[name="password_nuevo"]');
    const passwordConfirmar = document.querySelector('input[name="password_confirmar"]');
    
    if (passwordConfirmar && passwordNuevo) {
        passwordConfirmar.addEventListener('input', function() {
            if (passwordNuevo.value !== this.value) {
                this.setCustomValidity('Las contraseñas no coinciden');
                this.classList.add('is-invalid');
            } else {
                this.setCustomValidity('');
                this.classList.remove('is-invalid');
            }
        });
        
        passwordNuevo.addEventListener('input', function() {
            if (passwordConfirmar.value && passwordNuevo.value !== passwordConfirmar.value) {
                passwordConfirmar.classList.add('is-invalid');
            } else {
                passwordConfirmar.classList.remove('is-invalid');
            }
        });
    }
    
    // Mensaje de bienvenida
    console.log('✅ Perfil de usuario cargado correctamente');
    
    // Manejar alertas automáticas
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            if (alert.classList.contains('alert-success') || alert.classList.contains('alert-info')) {
                setTimeout(function() {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(function() {
                        if (alert.parentNode) {
                            alert.parentNode.removeChild(alert);
                        }
                    }, 500);
                }, 3000);
            }
        });
    }, 1000);
});
</script>

<?php include 'includes/footer.php'; ?>